
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { MessageSquare, X, Send, Sparkles, HelpCircle } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

const faqs = [
  { question: "How can I earn?", answer: "You can earn by becoming an Editor and completing projects, or by joining as a Student and completing micro-tasks. Referring friends also earns you rewards!" },
  { question: "What is EditFusion?", answer: "EditFusion is a premium marketplace connecting elite creators with the top 1% of video editors, VFX artists, and cinematic storytellers. We also offer earning opportunities for students." },
  { question: "How to become an editor?", answer: "Sign up as an Editor through our portal. You'll need to submit a portfolio for review. Once approved, you can start browsing and bidding on projects." },
  { question: "What are micro-tasks for students?", answer: "Micro-tasks are small, manageable jobs like caption writing, reel breakdowns, or sourcing stock footage, designed for students to earn rewards and gain experience." },
  { question: "How do referrals work?", answer: "Share your unique referral link. When a friend joins as an editor and completes a job, you get 2000 Coins + 2% lifetime commission on their earnings." },
];

const Chatbot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([
    { text: "Hi there! I'm EditFusion AI. How can I help you today? You can ask a question or pick one below.", sender: 'bot' }
  ]);
  const [inputValue, setInputValue] = useState('');

  const toggleChat = () => setIsOpen(!isOpen);

  const handleSend = () => {
    if (!inputValue.trim()) return;
    const userMessage = { text: inputValue, sender: 'user' };
    setMessages(prev => [...prev, userMessage]);
    
    // Simple FAQ matching
    const matchedFAQ = faqs.find(faq => inputValue.toLowerCase().includes(faq.question.toLowerCase().split(' ')[0])); // Match first word of question
    let botResponse;
    if (matchedFAQ) {
      botResponse = { text: matchedFAQ.answer, sender: 'bot' };
    } else if (inputValue.toLowerCase().includes("hello") || inputValue.toLowerCase().includes("hi")) {
      botResponse = { text: "Hello! How can I assist you?", sender: 'bot' };
    }
    else {
      botResponse = { text: "I'm still learning! For complex queries, please contact support. Here are some common questions:", sender: 'bot', isSuggestion: true };
    }
    
    setTimeout(() => {
      setMessages(prev => [...prev, botResponse]);
    }, 600);
    setInputValue('');
  };

  const handleFaqClick = (question) => {
    const userMessage = { text: question, sender: 'user' };
    setMessages(prev => [...prev, userMessage]);
    const matchedFAQ = faqs.find(faq => faq.question === question);
    if (matchedFAQ) {
      setTimeout(() => {
         setMessages(prev => [...prev, { text: matchedFAQ.answer, sender: 'bot' }]);
      }, 600);
    }
  };


  return (
    <>
      <motion.div
        className="fixed bottom-6 right-6 z-[100]"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 1, type: 'spring', stiffness: 200, damping: 15 }}
      >
        <Button
          size="icon"
          className="rounded-full w-16 h-16 bg-gradient-to-tr from-purple-600 to-blue-600 text-white shadow-2xl hover:scale-110 transition-transform duration-200"
          onClick={toggleChat}
        >
          {isOpen ? <X size={28} /> : <MessageSquare size={28} />}
        </Button>
      </motion.div>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 30, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 30, scale: 0.9 }}
            transition={{ type: 'spring', stiffness: 300, damping: 25 }}
            className="fixed bottom-24 right-6 w-80 md:w-96 h-[500px] glass-effect shadow-2xl rounded-2xl flex flex-col overflow-hidden border border-purple-500/30 z-[99]"
          >
            {/* Header */}
            <div className="p-4 bg-black/40 border-b border-purple-500/20 flex items-center space-x-2">
              <Sparkles size={24} className="text-purple-400" />
              <h3 className="font-bold text-lg text-white">EditFusion AI Assistant</h3>
            </div>

            {/* Messages */}
            <div className="flex-grow p-4 space-y-3 overflow-y-auto scrollbar-thin scrollbar-thumb-purple-600 scrollbar-track-black/30">
              {messages.map((msg, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`flex ${msg.sender === 'bot' ? 'justify-start' : 'justify-end'}`}
                >
                  <div
                    className={`max-w-[80%] p-3 rounded-2xl text-sm ${
                      msg.sender === 'bot'
                        ? 'bg-purple-600/70 text-white rounded-bl-none'
                        : 'bg-blue-600/70 text-white rounded-br-none'
                    }`}
                  >
                    {msg.text}
                    {msg.isSuggestion && (
                        <div className="mt-2 space-y-1">
                            {faqs.slice(0,3).map(faq => (
                                <Button key={faq.question} variant="link" size="sm" className="text-xs p-0 h-auto text-blue-200 hover:text-white block text-left" onClick={() => handleFaqClick(faq.question)}>
                                    <HelpCircle size={12} className="inline mr-1"/>{faq.question}
                                </Button>
                            ))}
                        </div>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Input */}
            <div className="p-4 border-t border-purple-500/20 bg-black/40">
              <div className="flex items-center space-x-2">
                <Input
                  type="text"
                  placeholder="Ask a question..."
                  className="flex-1 input-glow bg-gray-800/50 border-purple-500/30 text-white"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                />
                <Button size="icon" className="bg-purple-600 hover:bg-purple-700 text-white" onClick={handleSend}>
                  <Send size={18} />
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default Chatbot;
