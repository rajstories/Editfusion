import React from 'react';
import { motion } from 'framer-motion';
import { Instagram, Mail } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="py-16 border-t border-gray-800">
      <div className="container mx-auto px-6">
        <div className="text-center">
          <motion.div
            whileHover={{ scale: 1.05 }}
            className="inline-block mb-8"
          >
            <span className="text-3xl font-black gradient-text">EditFusion</span>
          </motion.div>
          
          <p className="text-gray-400 mb-8 max-w-md mx-auto">
            The future of content creation. Where vision meets fusion.
          </p>

          <div className="flex justify-center space-x-6 mb-8">
            <motion.a
              whileHover={{ scale: 1.1, y: -2 }}
              href="https://instagram.com/editfusion.in"
              target="_blank"
              rel="noopener noreferrer"
              className="w-12 h-12 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full flex items-center justify-center hover:shadow-lg transition-all duration-300"
            >
              <Instagram className="h-6 w-6 text-white" />
            </motion.a>
            <motion.a
              whileHover={{ scale: 1.1, y: -2 }}
              href="mailto:hello@editfusion.in"
              className="w-12 h-12 bg-gradient-to-r from-blue-600 to-cyan-600 rounded-full flex items-center justify-center hover:shadow-lg transition-all duration-300"
            >
              <Mail className="h-6 w-6 text-white" />
            </motion.a>
          </div>

          <div className="border-t border-gray-800 pt-8">
            <p className="text-gray-500 text-sm">
              © {new Date().getFullYear()} EditFusion. All rights reserved. | editfusion.in
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;