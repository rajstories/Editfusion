
import React from 'react';
import { motion } from 'framer-motion';
import { Film, UserPlus, LogIn, Gift, Users, Home, Search, MessageSquare, UserCircle, Bell, LogOut, Briefcase, GraduationCap, FolderKanban, Scissors } from 'lucide-react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';


const NavLink = ({ to, children, icon, onClick, isMobile = false, className = "" }) => {
  const location = useLocation();
  const isActive = location.pathname === to;

  const baseClasses = `flex items-center space-x-2 transition-all duration-300 ${className}`;
  const mobileClasses = `flex-col text-xs py-2 ${isActive && !onClick ? 'text-primary' : 'text-loom-nav-text hover:text-primary/80'}`;
  const desktopClasses = `loom-nav-link ${isActive && !onClick ? 'text-primary' : 'text-loom-nav-text'}`;


  const content = (
    <motion.div
      className={`${baseClasses} ${isMobile ? mobileClasses : desktopClasses}`}
      whileHover={isMobile ? {} : { y: -1 }}
      whileTap={isMobile ? { scale: 0.95 } : { scale: 0.95 }}
      onClick={onClick}
    >
      {icon && React.cloneElement(icon, { size: isMobile ? 20 : 16, className: `mr-1 ${isMobile ? 'mb-0.5' : ''}` })}
      <span>{children}</span>
    </motion.div>
  );

  return to ? <Link to={to}>{content}</Link> : <div className="cursor-pointer">{content}</div>;
};


const Header = ({ user, onLoginClick, onSignupClick, onLogout }) => {
  const navigate = useNavigate();
  const location = useLocation(); 

  const scrollToHero = () => {
    if (location.pathname !== '/') {
      navigate('/');
      setTimeout(() => {
        const heroSection = document.getElementById('hero-section');
        if (heroSection) {
          heroSection.scrollIntoView({ behavior: 'smooth' });
        }
      }, 100); 
    } else {
      const heroSection = document.getElementById('hero-section');
      if (heroSection) {
        heroSection.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };
  
  const getInitials = (name) => {
    if (!name) return "?";
    const names = name.split(' ');
    if (names.length === 1) return names[0].charAt(0).toUpperCase();
    return names[0].charAt(0).toUpperCase() + names[names.length - 1].charAt(0).toUpperCase();
  };


  return (
    <motion.header
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.8, delay: 0.1 }}
      className="fixed top-0 left-0 right-0 z-50 loom-nav"
    >
      <div className="container mx-auto flex items-center justify-between h-16 px-4 md:px-6">
        <Link to="/" className="flex items-center space-x-2 group" onClick={(e) => { e.preventDefault(); scrollToHero();}}>
          <motion.div
            whileHover={{ rotate: [0, -10, 10, -10, 0], scale: 1.1 }}
            transition={{ duration: 0.5 }}
            className="w-8 h-8 bg-gradient-to-r from-primary to-secondary rounded-md flex items-center justify-center shadow-md"
          >
            <Film className="h-5 w-5 text-white" />
          </motion.div>
          <span className="text-xl md:text-2xl font-bold text-loom-nav-text group-hover:text-primary transition-all duration-300">
            EditFusion
          </span>
        </Link>

        <nav className="hidden md:flex items-center space-x-1 lg:space-x-2">
          <NavLink onClick={scrollToHero} className="px-3 lg:px-4">Home</NavLink>
          <NavLink to="/find-editors" className="px-3 lg:px-4">Find Editors</NavLink>
          <NavLink to="/editor" className="px-3 lg:px-4">Video Editor</NavLink>
          {user && user.role === 'editor' && <NavLink to="/tasks" className="px-3 lg:px-4">My Tasks</NavLink>}
          {user && user.role === 'editor' && <NavLink to="/open-projects" className="px-3 lg:px-4">Open Projects</NavLink>}
          <NavLink to="/rewards" className="px-3 lg:px-4">Rewards</NavLink>
          <NavLink to="/refer-earn" className="px-3 lg:px-4">Refer & Earn</NavLink>
          <NavLink to="/student-earn" className="px-3 lg:px-4">Earning Center</NavLink>
        </nav>

        <div className="flex items-center space-x-3">
          {user ? (
             <div className="flex items-center space-x-3">
              <Link to="/notifications">
                <Button variant="ghost" size="icon" className="text-loom-nav-text hover:text-primary relative">
                  <Bell size={20} />
                  <span className="absolute top-1 right-1.5 flex h-2.5 w-2.5">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
                  </span>
                </Button>
              </Link>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative h-10 w-10 rounded-full p-0">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={user.avatar || `https://avatar.vercel.sh/${user.email}.png`} alt={user.name} />
                      <AvatarFallback className="bg-primary text-primary-foreground">{getInitials(user.name)}</AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56 glass-effect mt-2 border-purple-500/30" align="end" forceMount>
                  <DropdownMenuLabel className="font-normal">
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-medium leading-none text-white">{user.name}</p>
                      <p className="text-xs leading-none text-gray-400">{user.email}</p>
                      <p className="text-xs leading-none text-purple-300 capitalize">{user.role}</p>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator className="bg-purple-500/20"/>
                  <DropdownMenuItem asChild className="cursor-pointer hover:!bg-purple-500/20 focus:!bg-purple-500/20">
                    <Link to="/profile" className="flex items-center text-gray-200">
                      <UserCircle className="mr-2 h-4 w-4 text-purple-300" /> Profile
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild className="cursor-pointer hover:!bg-purple-500/20 focus:!bg-purple-500/20">
                    <Link to="/inbox" className="flex items-center text-gray-200">
                     <MessageSquare className="mr-2 h-4 w-4 text-purple-300" /> Inbox
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator className="bg-purple-500/20"/>
                  <DropdownMenuItem onClick={onLogout} className="cursor-pointer hover:!bg-red-500/20 focus:!bg-red-500/20 flex items-center text-red-400">
                    <LogOut className="mr-2 h-4 w-4" /> Log out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          ) : (
            <>
              <Button
                variant="ghost"
                size="sm"
                className="loom-nav-button loom-nav-button-secondary hidden sm:inline-flex"
                onClick={() => onLoginClick()}
              >
                <LogIn size={16} className="mr-2" /> Login
              </Button>
              <Button
                size="sm"
                className="loom-nav-button loom-nav-button-primary"
                onClick={() => onSignupClick()}
              >
                <UserPlus size={16} className="mr-2 sm:hidden" /> 
                <span className="hidden sm:inline">Sign Up</span>
                <span className="sm:hidden">Up</span>
              </Button>
            </>
          )}
        </div>
      </div>
      {/* Mobile Nav */}
      <div className="md:hidden grid grid-cols-5 gap-1 p-1 border-t border-gray-200 bg-white">
          <NavLink onClick={scrollToHero} icon={<Home />} isMobile={true}>Home</NavLink>
          <NavLink to="/find-editors" icon={<Search />} isMobile={true}>Find</NavLink>
          <NavLink to="/editor" icon={<Scissors />} isMobile={true}>Editor</NavLink>
          <NavLink to="/refer-earn" icon={<Users />} isMobile={true}>Refer</NavLink>
          {user ? (
             <NavLink to="/profile" icon={<UserCircle />} isMobile={true}>Profile</NavLink>
          ) : (
             <NavLink onClick={() => onLoginClick()} icon={<LogIn />} isMobile={true}>Login</NavLink>
          )}
      </div>
    </motion.header>
  );
};

export default Header;