import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';

const CustomCursor = () => {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [cursorVariant, setCursorVariant] = useState("default");

  useEffect(() => {
    const updateMousePosition = (e) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };

    const handleMouseEnter = (e) => {
      if (e.target.closest('.magnetic-hover, .card-hover, button, a')) {
        setCursorVariant("pointer");
      }
    };

    const handleMouseLeave = (e) => {
      if (e.target.closest('.magnetic-hover, .card-hover, button, a')) {
        setCursorVariant("default");
      }
    };

    window.addEventListener('mousemove', updateMousePosition);
    document.addEventListener('mouseover', handleMouseEnter);
    document.addEventListener('mouseout', handleMouseLeave);

    return () => {
      window.removeEventListener('mousemove', updateMousePosition);
      document.removeEventListener('mouseover', handleMouseEnter);
      document.removeEventListener('mouseout', handleMouseLeave);
    };
  }, []);

  const variants = {
    default: {
      x: mousePosition.x - 12,
      y: mousePosition.y - 12,
      width: 24,
      height: 24,
      backgroundColor: "hsla(var(--primary), 0.6)",
      mixBlendMode: "lighten",
    },
    pointer: {
      x: mousePosition.x - 18,
      y: mousePosition.y - 18,
      width: 36,
      height: 36,
      backgroundColor: "hsla(var(--secondary), 0.8)",
      mixBlendMode: "difference", 
      border: "2px solid hsla(var(--primary), 0.8)"
    }
  };

  return (
    <motion.div
      className="cursor-glow hidden lg:block fixed top-0 left-0 rounded-full pointer-events-none z-[9999]"
      variants={variants}
      animate={cursorVariant}
      transition={{ type: "spring", stiffness: 500, damping: 30, mass:0.2 }}
    />
  );
};

export default CustomCursor;