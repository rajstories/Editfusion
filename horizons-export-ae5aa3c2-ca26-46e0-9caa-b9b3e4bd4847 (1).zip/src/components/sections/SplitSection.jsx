
import React, { useState, useEffect, useRef } from 'react';
import { motion, useAnimation } from 'framer-motion';
import { ArrowRight, Video, Edit3 } from 'lucide-react';
import { Button } from '@/components/ui/button';

const FloatingImage = ({ src, alt, mousePosition, parentRef, isVisible }) => {
  const [imagePosition, setImagePosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    if (parentRef.current && mousePosition.x !== null) {
      const parentRect = parentRef.current.getBoundingClientRect();
      let x = mousePosition.x - parentRect.left + 20;
      let y = mousePosition.y - parentRect.top - 20;

      x = Math.max(0, Math.min(x, parentRect.width - 128)); // 128 is md:w-32
      y = Math.max(0, Math.min(y, parentRect.height - 128)); // 128 is md:h-32
      
      setImagePosition({ x, y });
    }
  }, [mousePosition, parentRef]);

  if (!isVisible) return null;

  return (
    <motion.div
      className="absolute w-24 h-24 md:w-32 md:h-32 rounded-lg shadow-2xl overflow-hidden pointer-events-none z-10 border-2 border-purple-500/50"
      style={{
        left: imagePosition.x,
        top: imagePosition.y,
      }}
      initial={{ opacity: 0, scale: 0.8, rotate: -5 }}
      animate={{ opacity: 1, scale: 1, rotate: 0 }}
      exit={{ opacity: 0, scale: 0.8, rotate: 5 }}
      transition={{ type: 'spring', stiffness: 300, damping: 20 }}
    >
      <img-replace src={src} alt={alt} class="w-full h-full object-cover" />
    </motion.div>
  );
};

const cardStyles = {
  creator: {
    border: 'hover:border-purple-500/70',
    iconBg: 'from-purple-500 to-pink-500',
    text: 'text-purple-400',
    buttonBg: 'bg-purple-600 hover:bg-purple-700',
    glow: 'hsla(258, 70%, 60%, 0.4)'
  },
  editor: {
    border: 'hover:border-blue-500/70',
    iconBg: 'from-blue-500 to-cyan-500',
    text: 'text-blue-400',
    buttonBg: 'bg-blue-600 hover:bg-blue-700',
    glow: 'hsla(220, 80%, 60%, 0.4)'
  }
};

const SplitCard = ({ icon: Icon, title, description, buttonText, type, imageSrc, imageAlt, onApplyClick, onMouseEnter, onMouseLeave, onMouseMove, mousePosition, isHovered }) => {
  const cardRef = useRef(null);
  const controls = useAnimation();
  const styles = cardStyles[type];

  const handleHoverStart = () => {
    controls.start({ scale: 1.03, y: -10 });
    onMouseEnter();
  };
  const handleHoverEnd = () => {
    controls.start({ scale: 1, y: 0 });
    onMouseLeave();
  };
  
  return (
    <motion.div
      ref={cardRef}
      className={`relative p-8 md:p-12 rounded-3xl overflow-hidden glass-effect flex flex-col items-center text-center cursor-pointer card-hover border-2 border-transparent ${styles.border}`}
      onMouseEnter={handleHoverStart}
      onMouseLeave={handleHoverEnd}
      onMouseMove={(e) => onMouseMove({ x: e.clientX, y: e.clientY })}
      onClick={onApplyClick}
      animate={controls}
      transition={{ type: 'spring', stiffness: 200, damping: 15 }}
      whileHover={{ boxShadow: `0 0 25px ${styles.glow}, 0 0 40px ${styles.glow.replace('0.4', '0.2')}`}}
    >
      <FloatingImage 
        src={imageSrc} 
        alt={imageAlt} 
        mousePosition={mousePosition} 
        parentRef={cardRef}
        isVisible={isHovered}
      />
      <motion.div 
        className={`mb-6 p-4 bg-gradient-to-br ${styles.iconBg} rounded-full inline-block shadow-lg`}
        animate={{ scale: isHovered ? 1.15 : 1, rotate: isHovered ? [0, 15, -15, 0] : 0 }}
        transition={{ duration: 0.7, repeat: isHovered ? Infinity : 0, repeatType: "mirror" }}
      >
        <Icon className="w-8 h-8 text-white" />
      </motion.div>
      <h3 className={`text-3xl font-bold mb-4 ${styles.text}`}>{title}</h3>
      <p className="text-gray-300 mb-8 leading-relaxed">{description}</p>
      <Button 
        size="lg" 
        className={`magnetic-hover ${styles.buttonBg} text-white px-8 py-3 text-base font-semibold glow-effect w-full group`}
        onClick={(e) => { e.stopPropagation(); onApplyClick(); }}
      >
        {buttonText} <ArrowRight className="ml-2 h-5 w-5 transform transition-transform duration-300 group-hover:translate-x-1" />
      </Button>
    </motion.div>
  );
};


const SplitSection = ({ onOpenCreatorApplyModal, onOpenEditorApplyModal }) => {
  const [mousePosition, setMousePosition] = useState({ x: null, y: null });
  const [hoveredCard, setHoveredCard] = useState(null); // 'creator' or 'editor'

  const handleMouseMove = (pos) => {
    setMousePosition(pos);
  };

  return (
    <section className="py-20 md:py-32 bg-black relative overflow-hidden">
      <div className="absolute inset-0 opacity-10">
        <img-replace src="https://images.unsplash.com/photo-1517245386807-bb43f82c33c4" alt="Abstract tech background" class="w-full h-full object-cover filter blur-sm" />
      </div>
      <div className="container mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-black mb-4">
            <span className="gradient-text">Join the Revolution</span>
          </h2>
          <p className="text-lg md:text-xl text-gray-400 max-w-2xl mx-auto">
            Whether you're a visionary creator seeking top-tier talent or an elite editor ready for impactful projects, EditFusion is your platform.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8 md:gap-12">
          <SplitCard
            icon={Video}
            title="For Creators"
            description="Bring your vision to life. Connect with the world's best editors, manage projects seamlessly, and achieve cinematic quality for your content."
            buttonText="Apply as Creator"
            type="creator"
            imageSrc="https://images.unsplash.com/photo-1558507652-2986c36a8750" 
            imageAlt="Creator recording video"
            onApplyClick={onOpenCreatorApplyModal}
            onMouseEnter={() => setHoveredCard('creator')}
            onMouseLeave={() => setHoveredCard(null)}
            onMouseMove={handleMouseMove}
            mousePosition={mousePosition}
            isHovered={hoveredCard === 'creator'}
          />
          <SplitCard
            icon={Edit3}
            title="For Editors"
            description="Showcase your skills, find exciting projects, and collaborate with passionate creators. Elevate your career and earn with EditFusion."
            buttonText="Apply as Editor"
            type="editor"
            imageSrc="https://images.unsplash.com/photo-1603380353725-8a740d96316a"
            imageAlt="Editor working on timeline"
            onApplyClick={onOpenEditorApplyModal}
            onMouseEnter={() => setHoveredCard('editor')}
            onMouseLeave={() => setHoveredCard(null)}
            onMouseMove={handleMouseMove}
            mousePosition={mousePosition}
            isHovered={hoveredCard === 'editor'}
          />
        </div>
      </div>
    </section>
  );
};

export default SplitSection;
