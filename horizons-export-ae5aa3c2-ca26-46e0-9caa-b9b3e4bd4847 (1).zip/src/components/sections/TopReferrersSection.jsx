
import React from 'react';
import { motion } from 'framer-motion';
import { Award, User, TrendingUp, Coins } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

const topReferrersData = [
  { rank: 1, name: 'Alex Chen', referrals: 45, earnings: 89000, avatarSeed: 'alex' },
  { rank: 2, name: 'Mia Wong', referrals: 38, earnings: 72000, avatarSeed: 'mia' },
  { rank: 3, name: 'Samuel Green', referrals: 32, earnings: 61000, avatarSeed: 'samuel' },
  { rank: 4, name: 'Olivia Blue', referrals: 25, earnings: 45000, avatarSeed: 'olivia' },
  { rank: 5, name: 'Kenji Tanaka', referrals: 21, earnings: 38000, avatarSeed: 'kenji' },
];

const getMedalColor = (rank) => {
  if (rank === 1) return 'from-yellow-400 to-amber-500 border-yellow-500 text-yellow-800'; // Gold
  if (rank === 2) return 'from-gray-300 to-slate-400 border-gray-400 text-gray-700';   // Silver
  if (rank === 3) return 'from-orange-400 to-amber-600 border-orange-500 text-orange-800'; // Bronze
  return 'from-gray-600 to-slate-700 border-gray-500 text-gray-200'; // Dark gray
};

const getInitials = (name) => name.split(' ').map(n => n[0]).join('').toUpperCase();

const TopReferrersSection = () => {
  return (
    <section className="py-16 md:py-24 bg-gradient-to-b from-black via-purple-900/10 to-black">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12 md:mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-black mb-4">
            <span className="gradient-text">Top Referrers This Month</span>
          </h2>
          <p className="text-lg text-gray-300 max-w-xl mx-auto">
            See who's leading the charge and get inspired to climb the ranks!
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6 md:gap-8">
          {topReferrersData.map((referrer, index) => (
            <motion.div
              key={referrer.rank}
              className={`rounded-2xl p-6 shadow-xl transition-all duration-300 hover:scale-105 card-hover border-2 bg-gradient-to-br ${getMedalColor(referrer.rank)}`}
              initial={{ opacity: 0, y: 50, scale:0.9 }}
              whileInView={{ opacity: 1, y: 0, scale:1 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{ duration: 0.5, delay: index * 0.1, type: "spring", stiffness: 100 }}
            >
              <div className="flex items-center justify-between mb-4">
                <span className={`text-3xl font-bold ${referrer.rank <=3 ? 'text-black/70' : 'text-white'}`}>#{referrer.rank}</span>
                {referrer.rank <= 3 && <Award size={32} className={`${referrer.rank === 1 ? 'text-yellow-600': referrer.rank === 2 ? 'text-slate-600' : 'text-orange-700'}`} />}
              </div>
              
              <div className="flex items-center mb-4">
                <Avatar className="w-16 h-16 border-2 border-white/50 shadow-md mr-4">
                   <AvatarImage src={`https://avatar.vercel.sh/${referrer.avatarSeed}.png?size=64`} alt={referrer.name} />
                   <AvatarFallback className={`${referrer.rank <=3 ? 'bg-black/20' : 'bg-purple-500/50'}`}>{getInitials(referrer.name)}</AvatarFallback>
                </Avatar>
                <div>
                  <h3 className={`text-xl font-semibold truncate ${referrer.rank <=3 ? 'text-black/80' : 'text-white'}`}>{referrer.name}</h3>
                  <p className={`text-sm ${referrer.rank <=3 ? 'text-black/60' : 'text-gray-300'}`}>Team EditFusion</p>
                </div>
              </div>

              <div className="space-y-2 text-sm">
                <div className={`flex items-center justify-between p-2 rounded-md ${referrer.rank <=3 ? 'bg-white/20' : 'bg-black/20'}`}>
                  <span className="flex items-center font-medium"><TrendingUp size={16} className="mr-1.5 opacity-70"/> Referrals:</span>
                  <span className="font-bold">{referrer.referrals}</span>
                </div>
                <div className={`flex items-center justify-between p-2 rounded-md ${referrer.rank <=3 ? 'bg-white/20' : 'bg-black/20'}`}>
                  <span className="flex items-center font-medium"><Coins size={16} className="mr-1.5 opacity-70"/> Earnings:</span>
                  <span className="font-bold">${referrer.earnings.toLocaleString()}</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TopReferrersSection;
