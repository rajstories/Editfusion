import React from 'react';
import { motion } from 'framer-motion';
import { Users, Sparkles, Star } from 'lucide-react';

const AboutSection = () => {
  return (
    <section className="py-24 relative">
      <div className="container mx-auto px-6">
        <motion.div
          className="section-reveal text-center max-w-4xl mx-auto"
        >
          <h2 className="text-5xl md:text-6xl font-black mb-8">
            <span className="gradient-text">Not just an editing platform.</span>
            <br />
            <span className="text-white">A movement.</span>
          </h2>
          <p className="text-xl text-gray-300 leading-relaxed mb-12">
            EditFusion is where cinematic dreams meet technical mastery. We're building the future of content creation, 
            one frame at a time. Our curated network of elite editors doesn't just edit—they transform visions into 
            visual masterpieces that captivate audiences worldwide.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="glass-effect rounded-2xl p-8 text-center"
            >
              <div className="w-16 h-16 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold mb-2">500+</h3>
              <p className="text-gray-400">Elite Creators</p>
            </motion.div>
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="glass-effect rounded-2xl p-8 text-center"
            >
              <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-cyan-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Sparkles className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold mb-2">10M+</h3>
              <p className="text-gray-400">Views Generated</p>
            </motion.div>
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="glass-effect rounded-2xl p-8 text-center"
            >
              <div className="w-16 h-16 bg-gradient-to-r from-cyan-600 to-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold mb-2">98%</h3>
              <p className="text-gray-400">Satisfaction Rate</p>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default AboutSection;