import React from 'react';
import { motion } from 'framer-motion';
import { Users, MessageSquare, Cloud, Share2, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

const CollaborateSection = ({ onOpenModal }) => {
  const sectionVariants = {
    hidden: { opacity: 0, x: -100 },
    visible: { opacity: 1, x: 0, transition: { duration: 0.8, ease: "easeOut" } }
  };

  const iconHover = {
    scale: 1.1,
    boxShadow: "0px 0px 15px hsla(160, 60%, 50%, 0.5)", /* Teal/Green Glow */
    transition: { type: "spring", stiffness: 300 }
  };
  
  return (
    <section className="py-24 relative overflow-hidden">
      <div className="container mx-auto px-6">
        <motion.div 
          className="section-reveal grid grid-cols-1 md:grid-cols-2 gap-12 items-center"
          variants={sectionVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.3 }}
        >
          <motion.div 
            className="relative card-hover cursor-pointer"
            whileHover={iconHover}
            onClick={onOpenModal}
          >
             <motion.div 
              className="absolute -top-16 -left-16 w-36 h-36 bg-teal-600/30 rounded-full filter blur-3xl opacity-60 animate-pulse"
              animate={{ scale: [1, 1.15, 1], rotate: [0, 15, 0]}}
              transition={{ duration: 5.5, repeat: Infinity, ease: "easeInOut" }}
            />
            <motion.div 
              className="absolute -bottom-16 -right-16 w-28 h-28 bg-green-600/30 rounded-full filter blur-3xl opacity-60 animate-pulse"
              animate={{ scale: [1, 0.85, 1], rotate: [0, -15, 0]}}
              transition={{ duration: 6.5, repeat: Infinity, ease: "easeInOut", delay: 1.2 }}
            />
            <div className="glass-effect rounded-3xl p-8 aspect-video flex items-center justify-center relative overflow-hidden">
              <img  
                alt="Animation of a team collaborating remotely" 
                class="w-full h-full object-contain rounded-2xl"
               src="https://images.unsplash.com/photo-1558982423-f8e8a5c75426" />
              <motion.div 
                className="absolute inset-0 flex items-center justify-center"
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5, duration: 1 }}
              >
                <Users className="w-24 h-24 text-teal-400 opacity-50" />
              </motion.div>
              <motion.div 
                className="absolute top-6 left-6 w-10 h-10 bg-gradient-to-br from-teal-500 to-green-500 rounded-full opacity-80"
                animate={{ x: [0, 6, 0], y: [0, -6, 0] }}
                transition={{ duration: 3.2, repeat: Infinity, ease: "easeInOut" }}
              />
              <motion.div 
                className="absolute bottom-6 right-6 w-14 h-14 bg-gradient-to-tl from-green-500 to-lime-500 rounded-full opacity-80"
                animate={{ x: [0, -6, 0], y: [0, 6, 0] }}
                transition={{ duration: 4.2, repeat: Infinity, ease: "easeInOut", delay: 0.6 }}
              />
            </div>
          </motion.div>
          <div className="text-left md:pl-10">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.5 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <span className="inline-block px-4 py-1.5 rounded-full bg-gradient-to-r from-teal-600 to-green-600 text-xs font-semibold uppercase tracking-wider mb-4">
                Collaborate
              </span>
              <h2 className="text-4xl md:text-5xl font-black mb-6">
                <span className="gradient-text">Collaborate Seamlessly</span>
              </h2>
              <p className="text-lg text-gray-300 leading-relaxed mb-8">
                Work together from anywhere in the world. Our platform offers real-time review tools, synchronized timelines, and cloud-based asset management, ensuring your projects stay on track and your team stays in sync.
              </p>
              <div className="grid grid-cols-2 gap-4 text-sm mb-8">
                <div className="flex items-center text-teal-400">
                  <MessageSquare className="w-5 h-5 mr-2" />
                  Real-time Reviews
                </div>
                <div className="flex items-center text-green-400">
                  <Cloud className="w-5 h-5 mr-2" />
                  Cloud Storage
                </div>
                <div className="flex items-center text-lime-400">
                  <Share2 className="w-5 h-5 mr-2" />
                  Easy File Sharing
                </div>
                <div className="flex items-center text-emerald-400">
                  <Users className="w-5 h-5 mr-2" />
                  Team Sync
                </div>
              </div>
               <Button 
                size="lg" 
                className="magnetic-hover bg-gradient-to-r from-teal-600 to-green-600 hover:from-teal-700 hover:to-green-700 text-white px-8 py-3 text-base font-semibold glow-effect"
                onClick={onOpenModal}
              >
                Enter Workspace <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default CollaborateSection;