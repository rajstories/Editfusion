import React from 'react';
import { motion } from 'framer-motion';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { DollarSign, Users, CalendarCheck, ArrowRight } from 'lucide-react';

const CtaCard = ({ icon: Icon, title, description, buttonText, linkTo, color, delay, openAuthModal, isAuthAction }) => {
  const navigate = useNavigate();

  const handleClick = () => {
    if (isAuthAction) {
      openAuthModal('signup');
    } else {
      navigate(linkTo);
    }
  };
  
  return (
    <motion.div
      className={`relative p-8 rounded-2xl overflow-hidden glass-effect flex flex-col items-center text-center card-hover border-2 border-transparent hover:border-${color}-500/70`}
      initial={{ opacity: 0, y: 50, scale: 0.9 }}
      whileInView={{ opacity: 1, y: 0, scale: 1 }}
      viewport={{ once: true, amount: 0.3 }}
      transition={{ duration: 0.6, delay: delay * 0.15, ease: "easeOut" }}
      whileHover={{ y: -8, boxShadow: `0 0 25px hsla(var(--${color}-hsl, 0, 0%, 50%), 0.4), 0 0 40px hsla(var(--${color}-hsl, 0, 0%, 50%), 0.2)`}}
    >
      <motion.div
        className={`mb-6 p-5 bg-gradient-to-br from-${color}-500 to-${color}-700 rounded-full inline-block shadow-xl`}
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: delay * 0.15 + 0.3, type: 'spring', stiffness: 200, damping: 12 }}
      >
        <Icon className="w-10 h-10 text-white" />
      </motion.div>
      <h3 className={`text-3xl font-bold mb-3 text-${color}-300`}>{title}</h3>
      <p className="text-gray-400 mb-8 leading-relaxed text-sm flex-grow">{description}</p>
      <Button
        size="lg"
        className={`magnetic-hover bg-${color}-600 hover:bg-${color}-700 text-white px-8 py-3 text-base font-semibold glow-effect w-full group mt-auto`}
        style={{'--glow-color': `hsla(var(--${color}-hsl, 0, 0%, 50%), 0.6)`}}
        onClick={handleClick}
      >
        {buttonText} <ArrowRight className="ml-2 h-5 w-5 transform transition-transform duration-300 group-hover:translate-x-1" />
      </Button>
    </motion.div>
  );
};

const BottomCtaSection = ({ openAuthModal }) => {
  const ctas = [
    {
      icon: DollarSign,
      title: "Earn Extra",
      description: "Refer talented editors or creators to EditFusion and earn commissions. Grow your network, grow your income.",
      buttonText: "Refer & Earn",
      linkTo: "/refer-earn",
      color: "red", // Tailwind red-500 etc.
      delay: 0,
      isAuthAction: false,
    },
    {
      icon: Users,
      title: "Get Editors",
      description: "Are you a creator looking for top-tier video editing talent? Sign up and find your perfect match.",
      buttonText: "Sign Up as Creator",
      linkTo: "/#", // Handled by openAuthModal
      color: "blue",
      delay: 1,
      isAuthAction: true,
    },
    {
      icon: CalendarCheck,
      title: "Daily Tasks",
      description: "Engage with the platform daily, complete simple tasks, and earn rewards. Keep your streak alive!",
      buttonText: "Check Rewards",
      linkTo: "/rewards",
      color: "green",
      delay: 2,
      isAuthAction: false,
    }
  ];

  return (
    <section className="py-20 md:py-28 bg-black relative overflow-hidden">
       <div className="absolute inset-x-0 top-0 h-64 bg-gradient-to-b from-purple-900/20 to-transparent opacity-50 blur-3xl"></div>
      <div className="container mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-black mb-4">
            <span className="gradient-text">Ready to Elevate Your Content?</span>
          </h2>
          <p className="text-lg md:text-xl text-gray-400 max-w-3xl mx-auto">
            Join EditFusion today. Whether you're looking to earn, find talent, or get rewarded for your engagement, we've got you covered.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8 md:gap-10">
          {ctas.map((cta, index) => (
            <CtaCard 
              key={index} 
              {...cta} 
              openAuthModal={openAuthModal}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default BottomCtaSection;