
import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from '@/components/ui/use-toast';
import { Copy, Share2, Link as LinkIcon } from 'lucide-react';

const ReferralLinkSection = ({ user }) => {
  const referralLink = user ? `https://editfusion.com/signup?ref=${user.id}` : 'https://editfusion.com/signup?ref=LOGIN-TO-SEE';
  const referralCode = user ? `EDIT-${user.id}` : 'LOGIN-REQUIRED';

  const handleCopy = (textToCopy, type) => {
    if (!user) {
      toast({ title: "Login Required", description: "Please log in to get your referral details.", variant: "destructive" });
      return;
    }
    navigator.clipboard.writeText(textToCopy);
    toast({
      title: `✅ ${type} Copied!`,
      description: `Your referral ${type.toLowerCase()} is ready to be shared.`,
    });
  };

  const handleShare = async () => {
    if (!user) {
      toast({ title: "Login Required", description: "Please log in to share your referral link.", variant: "destructive" });
      return;
    }
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Join me on EditFusion!',
          text: 'Hey! I use EditFusion to connect with amazing creators and editors. Sign up with my link and let\'s collaborate!',
          url: referralLink,
        });
        toast({ title: '🚀 Shared Successfully!' });
      } catch (error) {
        toast({ title: 'Share Canceled', description: 'You canceled the share dialog.', variant: 'destructive' });
      }
    } else {
      toast({ title: 'Share Not Supported', description: 'Your browser does not support the Web Share API. Please copy the link manually.' });
    }
  };

  return (
    <motion.section
      className="py-16"
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      viewport={{ once: true, amount: 0.3 }}
      transition={{ duration: 0.8 }}
    >
      <div className="container mx-auto px-4 max-w-3xl">
        <div className="glass-effect rounded-2xl p-8 md:p-12 border border-purple-500/20 text-center">
          <LinkIcon className="w-12 h-12 mx-auto text-purple-400 mb-4" />
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white">Your Referral Link</h2>
          <p className="text-gray-400 mb-8 max-w-md mx-auto">
            Share your unique link and code. The more you share, the more you earn!
          </p>
          <div className="flex flex-col sm:flex-row items-center gap-2 bg-black/20 p-2 rounded-lg border border-gray-700">
            <Input
              readOnly
              value={referralLink}
              className="flex-grow bg-transparent border-none text-center sm:text-left text-gray-300 focus-visible:ring-0"
            />
            <div className="flex gap-2">
              <Button
                variant="outline"
                className="border-purple-500/50 hover:bg-purple-500/10 text-purple-300"
                onClick={() => handleCopy(referralLink, 'Link')}
              >
                <Copy size={16} className="mr-2" /> Copy
              </Button>
              <Button
                className="bg-purple-600 hover:bg-purple-700 text-white"
                onClick={handleShare}
              >
                <Share2 size={16} className="mr-2" /> Share
              </Button>
            </div>
          </div>
          <div className="mt-4 text-sm text-gray-400">
            Your referral code:
            <span
              className="ml-2 font-mono bg-gray-700/50 text-green-300 py-1 px-2 rounded-md cursor-pointer"
              onClick={() => handleCopy(referralCode, 'Code')}
            >
              {referralCode}
            </span>
          </div>
        </div>
      </div>
    </motion.section>
  );
};

export default ReferralLinkSection;
