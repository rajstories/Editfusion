import React from 'react';
import { motion } from 'framer-motion';
import { HeartHandshake as Handshake, Users, Link as LinkIcon, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

const ConnectSection = ({ onOpenModal }) => {
  const sectionVariants = {
    hidden: { opacity: 0, x: -100 },
    visible: { opacity: 1, x: 0, transition: { duration: 0.8, ease: "easeOut" } }
  };

  const iconHover = {
    scale: 1.1,
    boxShadow: "0px 0px 15px hsla(var(--primary), 0.5)",
    transition: { type: "spring", stiffness: 300 }
  };

  return (
    <section className="py-24 relative overflow-hidden">
      <div className="container mx-auto px-6">
        <motion.div 
          className="section-reveal grid grid-cols-1 md:grid-cols-2 gap-12 items-center"
          variants={sectionVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.3 }}
        >
          <motion.div 
            className="relative card-hover cursor-pointer"
            whileHover={iconHover}
            onClick={onOpenModal}
          >
            <motion.div 
              className="absolute -top-10 -left-10 w-32 h-32 bg-purple-600/30 rounded-full filter blur-2xl opacity-70 animate-pulse"
              animate={{ scale: [1, 1.1, 1], rotate: [0, 10, 0]}}
              transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
            />
            <motion.div 
              className="absolute -bottom-10 -right-10 w-24 h-24 bg-blue-600/30 rounded-full filter blur-2xl opacity-70 animate-pulse"
              animate={{ scale: [1, 0.9, 1], rotate: [0, -10, 0]}}
              transition={{ duration: 6, repeat: Infinity, ease: "easeInOut", delay: 1 }}
            />
            <div className="glass-effect rounded-3xl p-8 aspect-video flex items-center justify-center relative overflow-hidden">
              <img  
                alt="Animated illustration of creators connecting online" 
                class="w-full h-full object-contain rounded-2xl"
               src="https://images.unsplash.com/photo-1450504244133-da90f34e053f" />
              <motion.div 
                className="absolute inset-0 flex items-center justify-center"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5, duration: 1 }}
              >
                <Handshake className="w-24 h-24 text-purple-400 opacity-50" />
              </motion.div>
              <motion.div 
                className="absolute top-4 left-4 w-8 h-8 bg-gradient-to-br from-purple-500 to-blue-500 rounded-full opacity-80"
                animate={{ x: [0, 5, 0], y: [0, -5, 0] }}
                transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
              />
              <motion.div 
                className="absolute bottom-4 right-4 w-12 h-12 bg-gradient-to-tl from-blue-500 to-cyan-500 rounded-full opacity-80"
                animate={{ x: [0, -5, 0], y: [0, 5, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
              />
            </div>
          </motion.div>
          <div className="text-left md:pl-10">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.5 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <span className="inline-block px-4 py-1.5 rounded-full bg-gradient-to-r from-purple-600 to-blue-600 text-xs font-semibold uppercase tracking-wider mb-4">
                Connect
              </span>
              <h2 className="text-4xl md:text-5xl font-black mb-6">
                <span className="gradient-text">Connect with Visionaries</span>
              </h2>
              <p className="text-lg text-gray-300 leading-relaxed mb-8">
                Dive into a curated network of top-tier creators and elite editors. Forge powerful partnerships that bring ambitious visions to life. Experience seamless introductions and build lasting professional relationships.
              </p>
              <div className="flex items-center space-x-4 mb-8">
                <div className="flex items-center text-sm text-purple-400">
                  <Users className="w-5 h-5 mr-2" />
                  Elite Network
                </div>
                <div className="flex items-center text-sm text-blue-400">
                  <LinkIcon className="w-5 h-5 mr-2" />
                  Direct Collaboration
                </div>
              </div>
              <Button 
                size="lg" 
                className="magnetic-hover bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white px-8 py-3 text-base font-semibold glow-effect"
                onClick={onOpenModal}
              >
                Find Your Match <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default ConnectSection;