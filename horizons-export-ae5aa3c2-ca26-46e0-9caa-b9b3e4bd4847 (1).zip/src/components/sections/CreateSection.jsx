import React from 'react';
import { motion } from 'framer-motion';
import { Film, Layers, Music, Palette, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

const CreateSection = ({ onOpenModal }) => {
  const sectionVariants = {
    hidden: { opacity: 0, x: 100 },
    visible: { opacity: 1, x: 0, transition: { duration: 0.8, ease: "easeOut" } }
  };

  const iconHover = {
    scale: 1.1,
    boxShadow: "0px 0px 15px hsla(var(--secondary), 0.5)",
    transition: { type: "spring", stiffness: 300 }
  };

  return (
    <section className="py-24 relative overflow-hidden bg-black">
      <div className="container mx-auto px-6">
        <motion.div 
          className="section-reveal grid grid-cols-1 md:grid-cols-2 gap-12 items-center"
          variants={sectionVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.3 }}
        >
          <div className="text-left md:pr-10 order-2 md:order-1">
             <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.5 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <span className="inline-block px-4 py-1.5 rounded-full bg-gradient-to-r from-blue-600 to-cyan-600 text-xs font-semibold uppercase tracking-wider mb-4">
                Create
              </span>
              <h2 className="text-4xl md:text-5xl font-black mb-6">
                <span className="gradient-text">Craft Stunning Content</span>
              </h2>
              <p className="text-lg text-gray-300 leading-relaxed mb-8">
                Leverage industry-grade tools and the expertise of cinematic storytellers. From intricate VFX to flawless color grading, achieve unparalleled precision and bring your creative concepts to breathtaking reality.
              </p>
              <div className="grid grid-cols-2 gap-4 text-sm mb-8">
                <div className="flex items-center text-blue-400">
                  <Film className="w-5 h-5 mr-2" />
                  Cinematic Editing
                </div>
                <div className="flex items-center text-cyan-400">
                  <Layers className="w-5 h-5 mr-2" />
                  Advanced VFX
                </div>
                <div className="flex items-center text-teal-400">
                  <Music className="w-5 h-5 mr-2" />
                  Sound Design
                </div>
                <div className="flex items-center text-green-400">
                  <Palette className="w-5 h-5 mr-2" />
                  Color Grading
                </div>
              </div>
              <Button 
                size="lg" 
                className="magnetic-hover bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white px-8 py-3 text-base font-semibold glow-effect"
                onClick={onOpenModal}
              >
                Start Creating <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </motion.div>
          </div>
          <motion.div 
            className="relative order-1 md:order-2 card-hover cursor-pointer"
            whileHover={iconHover}
            onClick={onOpenModal}
          >
            <motion.div 
              className="absolute -top-10 -right-10 w-32 h-32 bg-blue-600/30 rounded-full filter blur-2xl opacity-70 animate-pulse"
              animate={{ scale: [1, 1.1, 1], rotate: [0, -10, 0]}}
              transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
            />
            <motion.div 
              className="absolute -bottom-10 -left-10 w-24 h-24 bg-cyan-600/30 rounded-full filter blur-2xl opacity-70 animate-pulse"
              animate={{ scale: [1, 0.9, 1], rotate: [0, 10, 0]}}
              transition={{ duration: 6, repeat: Infinity, ease: "easeInOut", delay: 1 }}
            />
            <div className="glass-effect rounded-3xl p-8 aspect-video flex items-center justify-center relative overflow-hidden">
              <img  
                alt="Animated video editor's workspace" 
                class="w-full h-full object-contain rounded-2xl"
               src="https://images.unsplash.com/photo-1579109652910-99b9be06aaec" />
              <motion.div 
                className="absolute inset-0 flex items-center justify-center"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.5, duration: 1 }}
              >
                <Layers className="w-24 h-24 text-blue-400 opacity-50" />
              </motion.div>
               <motion.div 
                className="absolute top-8 right-8 w-6 h-6 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-full opacity-80"
                animate={{ x: [0, -5, 0], y: [0, 5, 0] }}
                transition={{ duration: 3.5, repeat: Infinity, ease: "easeInOut" }}
              />
              <motion.div 
                className="absolute bottom-8 left-8 w-10 h-10 bg-gradient-to-tl from-cyan-500 to-teal-500 rounded-full opacity-80"
                animate={{ x: [0, 5, 0], y: [0, -5, 0] }}
                transition={{ duration: 4.5, repeat: Infinity, ease: "easeInOut", delay: 0.7 }}
              />
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default CreateSection;