import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { Send } from 'lucide-react';

const WaitlistSection = () => {
  const [email, setEmail] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (email) {
      toast({ 
        title: "🎉 You're on the list!", 
        description: "We'll notify you as soon as EditFusion launches!" 
      });
      setEmail('');
    } else {
      toast({ 
        title: "📧 Email required", 
        description: "Please enter your email to join the waitlist!" 
      });
    }
  };

  return (
    <section className="py-24 relative">
      <div className="container mx-auto px-6">
        <motion.div className="section-reveal text-center max-w-4xl mx-auto">
          <h2 className="text-5xl md:text-6xl font-black mb-6">
            <span className="gradient-text">Be Among the First</span>
            <br />
            <span className="text-white">to Experience It</span>
          </h2>
          <p className="text-xl text-gray-300 mb-12 leading-relaxed">
            EditFusion is launching soon. Join our exclusive waitlist and be the first to access the future of content creation.
          </p>

          <motion.div
            whileHover={{ scale: 1.02 }}
            className="glass-effect rounded-3xl p-12 max-w-2xl mx-auto"
          >
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <input
                  type="email"
                  placeholder="Enter your email address"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-6 py-4 bg-black/50 border border-purple-500/30 rounded-xl text-white placeholder-gray-400 focus:outline-none input-glow transition-all duration-300"
                />
              </div>
              <Button 
                type="submit"
                size="lg" 
                className="w-full magnetic-hover bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white py-4 text-lg font-semibold glow-effect"
              >
                <Send className="mr-2 h-5 w-5" />
                Join the Waitlist
              </Button>
            </form>
            <p className="text-sm text-gray-400 mt-6">
              No spam, ever. Just updates on our launch and exclusive early access.
            </p>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default WaitlistSection;