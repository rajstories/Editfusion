import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Users, Zap, Star, HeartHandshake as Handshake, Edit3, Award, TrendingUp, ArrowRight } from 'lucide-react';

const WhyEditFusionSection = ({ whyModalSetters }) => {
  const features = [
    {
      id: 'connect',
      icon: <Handshake className="h-8 w-8" />,
      title: "Connect",
      description: "Find the right talent or project with curated matchmaking.",
      modalText: "Find the right editors for your content with just one click.",
      buttonText: "Explore Editors",
      lottieUrl: "https://assets3.lottiefiles.com/packages/lf20_puciaact.json", 
      bgColor: "from-purple-600 to-blue-600",
      hoverImage: "https://images.unsplash.com/photo-1521791136064-7986c2920216?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8Y29ubmVjdGlvbnxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60"
    },
    {
      id: 'create',
      icon: <Edit3 className="h-8 w-8" />,
      title: "Create",
      description: "Leverage powerful tools and top-tier editors to craft stunning content.",
      modalText: "Use EditFusion tools to co-create stunning content.",
      buttonText: "Start Creating",
      lottieUrl: "https://assets1.lottiefiles.com/packages/lf20_cUG5w1.json", 
      bgColor: "from-blue-500 to-cyan-500",
      hoverImage: "https://images.unsplash.com/photo-1504384308090-c894fdcc538d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8Y3JlYXRlfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60"
    },
    {
      id: 'reward',
      icon: <Award className="h-8 w-8" />,
      title: "Reward",
      description: "Engage daily, complete tasks, and unlock exclusive rewards.",
      modalText: "Visit daily. Stack coins. Unlock rewards.",
      buttonText: "Claim Now",
      lottieUrl: "https://assets6.lottiefiles.com/packages/lf20_fityb0ts.json", 
      bgColor: "from-teal-500 to-green-500",
      hoverImage: "https://images.unsplash.com/photo-1578916171728-46686eac8d58?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cmV3YXJkfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60"
    },
    {
      id: 'earn',
      icon: <TrendingUp className="h-8 w-8" />,
      title: "Earn",
      description: "Grow your network, refer editors, and earn commissions.",
      modalText: "Refer editors, grow your network, earn commission.",
      buttonText: "Refer Now",
      lottieUrl: "https://assets9.lottiefiles.com/packages/lf20_yCjSOH.json", 
      bgColor: "from-amber-500 to-orange-600",
      hoverImage: "https://images.unsplash.com/photo-1553729459-efe14ef6055d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8ZWFybnxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60"
    }
  ];

  const [hoveredFeature, setHoveredFeature] = useState(null);

  return (
    <section className="py-24 relative bg-gradient-to-b from-black via-purple-900/20 to-black">
      <div className="container mx-auto px-6">
        <motion.div 
          className="section-reveal text-center mb-16"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.7 }}
        >
          <h2 className="text-5xl md:text-6xl font-black mb-6">
            Why <span className="gradient-text">EditFusion</span>?
          </h2>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            We're revolutionizing content creation with a platform built for excellence and collaboration.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={feature.id}
              className="relative section-reveal card-hover glass-effect rounded-2xl p-6 md:p-8 text-center group cursor-pointer overflow-hidden"
              initial={{ opacity: 0, y: 50, scale: 0.95 }}
              whileInView={{ opacity: 1, y: 0, scale: 1 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{ duration: 0.5, delay: index * 0.1, type: "spring", stiffness:100 }}
              onMouseEnter={() => setHoveredFeature(feature.id)}
              onMouseLeave={() => setHoveredFeature(null)}
              onClick={() => whyModalSetters[feature.id](true)}
              whileHover={{ y: -10, boxShadow: "0px 20px 40px rgba(var(--primary-rgb, 128, 0, 128), 0.3)"}}
            >
              <AnimatePresence>
              {hoveredFeature === feature.id && (
                <motion.div
                  className="absolute inset-0 z-0"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <img-replace src={feature.hoverImage} alt={`${feature.title} background`} class="w-full h-full object-cover opacity-30 group-hover:opacity-50 transition-opacity duration-300"/>
                  <div className={`absolute inset-0 bg-gradient-to-t ${feature.bgColor} opacity-20 group-hover:opacity-40 transition-opacity duration-300`}></div>
                </motion.div>
              )}
              </AnimatePresence>
              
              <div className="relative z-10">
                <motion.div 
                  className={`w-16 h-16 bg-gradient-to-br ${feature.bgColor} rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg`}
                  animate={{ scale: hoveredFeature === feature.id ? 1.15 : 1, rotate: hoveredFeature === feature.id ? 5 : 0 }}
                  transition={{ type: "spring", stiffness: 200, damping: 10 }}
                >
                  {feature.icon}
                </motion.div>
                <h3 className="text-2xl font-bold mb-3 text-white">{feature.title}</h3>
                <p className="text-gray-300 leading-relaxed text-sm mb-4">{feature.description}</p>
                <motion.div 
                  className={`inline-flex items-center text-sm font-semibold text-purple-300 group-hover:text-purple-200 transition-colors duration-300`}
                  animate={{ gap: hoveredFeature === feature.id ? "8px" : "4px" }}
                >
                  Learn More <ArrowRight size={16} />
                </motion.div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhyEditFusionSection;