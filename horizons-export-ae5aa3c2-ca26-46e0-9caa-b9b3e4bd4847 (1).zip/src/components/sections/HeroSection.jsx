import React from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { Play, ArrowRight } from 'lucide-react';

const HeroSection = () => {
  const { scrollY } = useScroll();
  const y = useTransform(scrollY, [0, 500], [0, 100]); // Reduced parallax for softer feel
  const opacity = useTransform(scrollY, [0, 300], [1, 0.5]); // Fade out slightly on scroll

  return (
    <section 
      id="hero-section" 
      className="relative min-h-screen flex items-center justify-center hero-bg overflow-hidden pt-20 md:pt-24" // Adjusted padding
    >
      <motion.div 
        style={{ y, opacity }} 
        className="absolute inset-0 z-0"
      >
        {/* Soft gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/5 to-black/40" />
      </motion.div>
      
      <div className="container mx-auto px-6 relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 40 }} 
          animate={{ opacity: 1, y: 0 }} 
          transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }} 
          className="text-center max-w-4xl mx-auto"
        >
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }} 
            animate={{ scale: 1, opacity: 1 }} 
            transition={{ duration: 0.7, delay: 0.4, type: "spring", stiffness: 100 }} 
            className="mb-6"
          >
            <span className="inline-block px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm text-sm font-medium text-gray-200 mb-8 border border-white/20 shadow-sm">
              🎬 Currently in Private Beta
            </span>
          </motion.div>

          <motion.h1 
            initial={{ opacity: 0, y: 25 }} 
            animate={{ opacity: 1, y: 0 }} 
            transition={{ duration: 0.9, delay: 0.6, ease: "easeOut" }} 
            className="text-6xl md:text-8xl font-extrabold mb-6 leading-tight hero-text-glow" // Increased size, added glow class
          >
            <span className="loom-gradient-text">Your Vision,</span>
            <br />
            <span className="loom-gradient-text opacity-90">Our Fusion.</span>
          </motion.h1>

          <motion.p 
            initial={{ opacity: 0, y: 20 }} 
            animate={{ opacity: 1, y: 0 }} 
            transition={{ duration: 0.8, delay: 0.8, ease: "easeOut" }} 
            className="text-2xl md:text-3xl font-medium text-gray-300 mb-8 tracking-normal" // Adjusted font weight and tracking
          >
            Connect. Create. Collaborate.
          </motion.p>

          <motion.p 
            initial={{ opacity: 0, y: 20 }} 
            animate={{ opacity: 1, y: 0 }} 
            transition={{ duration: 0.8, delay: 1.0, ease: "easeOut" }} 
            className="text-lg md:text-xl text-gray-400 mb-12 max-w-2xl mx-auto leading-relaxed"
          >
            The premium editing marketplace connecting elite creators with the top 1% of video editors, VFX artists, and cinematic storytellers.
          </motion.p>

          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }} 
            animate={{ opacity: 1, scale: 1 }} 
            transition={{ duration: 0.7, delay: 1.2, type: "spring", stiffness: 120 }} 
            className="flex flex-col sm:flex-row gap-4 justify-center items-center"
          >
            <Button 
              size="lg" 
              className="loom-cta-button bg-gradient-to-r from-primary to-secondary text-white" // Loom-style CTA
              onClick={() => toast({
                title: "🚀 Beta access coming soon!",
                description: "We'll notify you when EditFusion launches!"
              })}
            >
              <Play className="mr-2 h-5 w-5" />
              Join the Beta
            </Button>
            <Button 
              variant="outline" 
              size="lg" 
              className="loom-cta-button bg-white/10 border-white/20 text-white hover:bg-white/20 hover:border-white/30" // Loom-style secondary CTA
              onClick={() => {
                const aboutSection = document.getElementById('about-section');
                if (aboutSection) {
                  aboutSection.scrollIntoView({ behavior: 'smooth' });
                } else {
                  toast({
                    title: "🎬 Learn more about EditFusion",
                    description: "Scroll down to discover what makes us different!"
                  });
                }
              }}
            >
              Learn More
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </motion.div>
        </motion.div>
      </div>

      <motion.div 
        animate={{ y: [0, 8, 0] }} 
        transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }} 
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
      >
        <div className="w-5 h-9 border-2 border-gray-400/70 rounded-full flex justify-center items-start pt-1.5">
          <div className="w-1 h-2 bg-gray-400/70 rounded-full animate-pulse" />
        </div>
      </motion.div>
    </section>
  );
};
export default HeroSection;