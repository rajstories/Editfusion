
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogClose } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from '@/components/ui/use-toast';
import { User, Briefcase, X, Mail, Lock, UserPlus, Upload } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const modalVariants = {
  hidden: { opacity: 0, scale: 0.9, y: -50 },
  visible: { opacity: 1, scale: 1, y: 0, transition: { type: 'spring', stiffness: 300, damping: 25 } },
  exit: { opacity: 0, scale: 0.9, y: 50, transition: { duration: 0.2 } },
};

const AuthModal = ({ isOpen, setIsOpen, defaultTab = 'login', onLoginSuccess }) => {
  const [userType, setUserType] = useState(null); 
  const [portfolioFiles, setPortfolioFiles] = useState([]);
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();
    const email = e.target['login-email']?.value;
    // Simulate login - in a real app, this would be an API call
    const mockUser = { 
      id: 'user123', 
      email: email, 
      name: email.split('@')[0] || "Demo User", // simple name generation
      role: email.includes('editor') ? 'editor' : (email.includes('student') ? 'student' : 'creator') // simple role assignment
    };
    onLoginSuccess(mockUser);
    toast({ title: "🎉 Login Successful!", description: `Welcome back, ${mockUser.name}!` });
    setIsOpen(false);
    navigate('/profile');
  };

  const handleSignup = (e) => {
    e.preventDefault();
    if (!userType) {
      toast({ title: "🤔 User Type Required", description: "Please select if you are a Creator or an Editor.", variant: "destructive" });
      return;
    }
    if (userType === 'editor' && portfolioFiles.length === 0) {
        toast({ title: "🖼️ Portfolio Required", description: "Editors, please upload at least one piece of your best work.", variant: "destructive" });
        return;
    }
    
    const name = e.target['signup-name']?.value;
    const email = e.target['signup-email']?.value;
    
    const signupData = {
      id: `user${Date.now()}`, // simple id generation
      userType,
      name,
      email,
      role: userType,
      portfolio: userType === 'editor' ? portfolioFiles.map(f => ({name: f.name, type: f.type, size: f.size })) : []
    };
    onLoginSuccess(signupData); // Use onLoginSuccess to set user state
    toast({ title: "🎉 Signup Successful!", description: `Welcome, ${name}! Your ${userType} account is ready.` });
    setIsOpen(false); 
    navigate('/profile');
  };

  const handleFileChange = (e) => {
    const files = Array.from(e.target.files);
    if (files.length + portfolioFiles.length > 5) {
      toast({ title: "⚠️ File Limit Exceeded", description: "You can upload a maximum of 5 files.", variant: "destructive" });
      return;
    }
    setPortfolioFiles(prevFiles => [...prevFiles, ...files.slice(0, 5 - prevFiles.length)]);
  };

  const removePortfolioFile = (fileName) => {
    setPortfolioFiles(prevFiles => prevFiles.filter(file => file.name !== fileName));
  };

  const inputVariants = {
    initial: { opacity: 0, x: -20 },
    animate: { opacity: 1, x: 0 },
    exit: { opacity: 0, x: 20 }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => { setIsOpen(open); if(!open) setUserType(null); setPortfolioFiles([]); }}>
      <AnimatePresence>
        {isOpen && (
          <DialogContent
            className="glass-effect p-0 max-w-md w-full overflow-hidden"
          >
            <motion.div
              variants={modalVariants}
              initial="hidden"
              animate="visible"
              exit="exit"
            >
              <Tabs defaultValue={defaultTab} value={defaultTab} onValueChange={() => { setUserType(null); setPortfolioFiles([]);}} className="w-full">
                <DialogHeader className="p-6 pb-0">
                  <div className="flex justify-between items-center">
                     <DialogTitle className="text-2xl font-bold gradient-text">Welcome to EditFusion</DialogTitle>
                     <DialogClose asChild>
                        <Button variant="ghost" size="icon" className="rounded-full text-gray-400 hover:text-white hover:bg-gray-700/50">
                            <X className="h-5 w-5" />
                        </Button>
                     </DialogClose>
                  </div>
                  <DialogDescription className="text-gray-400">
                    Access your account or create a new one to join the movement.
                  </DialogDescription>
                  <TabsList className="grid w-full grid-cols-2 mt-4 bg-gray-800/50 p-1 h-auto">
                    <TabsTrigger value="login" className="py-2.5 data-[state=active]:bg-purple-600 data-[state=active]:text-white data-[state=active]:shadow-lg">Login</TabsTrigger>
                    <TabsTrigger value="signup" className="py-2.5 data-[state=active]:bg-blue-600 data-[state=active]:text-white data-[state=active]:shadow-lg">Sign Up</TabsTrigger>
                  </TabsList>
                </DialogHeader>

                <TabsContent value="login" className="p-6">
                  <motion.form onSubmit={handleLogin} className="space-y-6" initial="initial" animate="animate" variants={{ animate: { transition: { staggerChildren: 0.1 }}}}>
                    <motion.div variants={inputVariants} className="space-y-2">
                      <Label htmlFor="login-email">Email</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                        <Input id="login-email" type="email" placeholder="you@example.com" required className="pl-10 input-glow bg-black/30 border-purple-500/30" />
                      </div>
                    </motion.div>
                    <motion.div variants={inputVariants} className="space-y-2">
                      <Label htmlFor="login-password">Password</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                        <Input id="login-password" type="password" placeholder="••••••••" required className="pl-10 input-glow bg-black/30 border-purple-500/30" />
                      </div>
                    </motion.div>
                    <motion.div variants={inputVariants}>
                      <Button type="submit" className="w-full magnetic-hover bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white py-3 text-base glow-effect">
                        Login
                      </Button>
                    </motion.div>
                  </motion.form>
                </TabsContent>

                <TabsContent value="signup" className="p-6 max-h-[70vh] overflow-y-auto">
                  <motion.form onSubmit={handleSignup} className="space-y-6" initial="initial" animate="animate" variants={{ animate: { transition: { staggerChildren: 0.1 }}}}>
                    {!userType ? (
                      <motion.div variants={inputVariants} className="text-center space-y-4">
                        <p className="text-lg font-semibold text-white">Are you a Creator, Editor or Student?</p>
                        <div className="grid grid-cols-1 gap-3">
                          <Button
                            type="button"
                            variant="outline"
                            className={`py-4 text-md h-auto border-2 ${userType === 'creator' ? 'border-purple-500 bg-purple-500/20' : 'border-gray-600 hover:border-purple-500'}`}
                            onClick={() => setUserType('creator')}
                          >
                            <User className="mr-2 h-5 w-5" /> Creator
                          </Button>
                          <Button
                            type="button"
                            variant="outline"
                            className={`py-4 text-md h-auto border-2 ${userType === 'editor' ? 'border-blue-500 bg-blue-500/20' : 'border-gray-600 hover:border-blue-500'}`}
                            onClick={() => setUserType('editor')}
                          >
                            <Briefcase className="mr-2 h-5 w-5" /> Editor
                          </Button>
                           <Button
                            type="button"
                            variant="outline"
                            className={`py-4 text-md h-auto border-2 ${userType === 'student' ? 'border-green-500 bg-green-500/20' : 'border-gray-600 hover:border-green-500'}`}
                            onClick={() => setUserType('student')}
                          >
                            <UserPlus className="mr-2 h-5 w-5" /> Student
                          </Button>
                        </div>
                      </motion.div>
                    ) : (
                      <>
                        <motion.div variants={inputVariants} className="text-center">
                            <p className="text-lg font-semibold text-white">Signing up as <span 
                              className={userType === 'creator' ? 'text-purple-400' : (userType === 'editor' ? 'text-blue-400' : 'text-green-400')}
                            >
                              {userType.charAt(0).toUpperCase() + userType.slice(1)}
                            </span></p>
                            <Button variant="link" size="sm" onClick={() => {setUserType(null); setPortfolioFiles([]);}} className="text-xs text-gray-400 hover:text-purple-300">Change user type</Button>
                        </motion.div>
                        <motion.div variants={inputVariants} className="space-y-2">
                          <Label htmlFor="signup-name">Full Name</Label>
                          <div className="relative">
                            <UserPlus className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                            <Input id="signup-name" placeholder="Your Name" required className="pl-10 input-glow bg-black/30 border-blue-500/30" />
                          </div>
                        </motion.div>
                        <motion.div variants={inputVariants} className="space-y-2">
                          <Label htmlFor="signup-email">Email</Label>
                          <div className="relative">
                            <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                            <Input id="signup-email" type="email" placeholder="you@example.com" required className="pl-10 input-glow bg-black/30 border-blue-500/30" />
                          </div>
                        </motion.div>
                        <motion.div variants={inputVariants} className="space-y-2">
                          <Label htmlFor="signup-password">Password</Label>
                          <div className="relative">
                            <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                            <Input id="signup-password" type="password" placeholder="Create a strong password" required className="pl-10 input-glow bg-black/30 border-blue-500/30" />
                          </div>
                        </motion.div>

                        {userType === 'editor' && (
                          <motion.div variants={inputVariants} className="space-y-2">
                            <Label htmlFor="portfolio-upload">Upload Portfolio (up to 5 files)</Label>
                            <div className="relative flex items-center justify-center w-full">
                                <label htmlFor="portfolio-upload-input" className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed rounded-lg cursor-pointer bg-black/20 border-blue-500/50 hover:bg-black/30 hover:border-blue-400">
                                    <div className="flex flex-col items-center justify-center pt-5 pb-6">
                                        <Upload className="w-8 h-8 mb-2 text-blue-400" />
                                        <p className="mb-1 text-sm text-gray-400"><span className="font-semibold">Click to upload</span> or drag and drop</p>
                                        <p className="text-xs text-gray-500">Videos, thumbnails, reels (Max 5)</p>
                                    </div>
                                    <Input id="portfolio-upload-input" type="file" className="hidden" multiple onChange={handleFileChange} accept="video/*,image/*" />
                                </label>
                            </div>
                            {portfolioFiles.length > 0 && (
                                <div className="mt-2 space-y-1">
                                    <p className="text-xs text-gray-300">Selected files ({portfolioFiles.length}/5):</p>
                                    {portfolioFiles.map(file => (
                                        <div key={file.name} className="flex items-center justify-between text-xs bg-gray-700/50 p-1.5 rounded">
                                            <span className="truncate max-w-[80%]">{file.name}</span>
                                            <Button type="button" variant="ghost" size="icon" className="h-5 w-5 text-red-400 hover:text-red-300" onClick={() => removePortfolioFile(file.name)}>
                                                <X size={14} />
                                            </Button>
                                        </div>
                                    ))}
                                </div>
                            )}
                          </motion.div>
                        )}
                        <motion.div variants={inputVariants}>
                          <Button type="submit" className="w-full magnetic-hover bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white py-3 text-base glow-effect">
                            Create Account
                          </Button>
                        </motion.div>
                      </>
                    )}
                  </motion.form>
                </TabsContent>
              </Tabs>
            </motion.div>
          </DialogContent>
        )}
      </AnimatePresence>
    </Dialog>
  );
};

export default AuthModal;
