import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogClose } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { X, Award, Gift, ArrowRight } from 'lucide-react';

const modalVariants = {
  hidden: { opacity: 0, y: 20, scale: 0.95 },
  visible: { opacity: 1, y: 0, scale: 1, transition: { type: 'spring', stiffness: 250, damping: 20 } },
  exit: { opacity: 0, y: -20, scale: 0.95, transition: { duration: 0.2 } },
};

const WhyRewardModal = ({ isOpen, setIsOpen }) => {
  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <AnimatePresence>
        {isOpen && (
          <DialogContent className="glass-effect p-0 max-w-md w-full overflow-hidden border-teal-500/30 shadow-2xl shadow-teal-500/20">
            <motion.div variants={modalVariants} initial="hidden" animate="visible" exit="exit">
              <DialogHeader className="p-8 text-center relative">
                 <motion.div 
                    className="mx-auto mb-6 w-20 h-20 bg-gradient-to-br from-teal-500 to-green-500 rounded-full flex items-center justify-center shadow-lg"
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 0.1, type: 'spring', stiffness: 150 }}
                  >
                    <Award className="h-10 w-10 text-white" />
                </motion.div>
                <DialogTitle className="text-3xl font-black gradient-text mb-2" style={{'--tw-gradient-from': 'hsl(145, 63%, 49%)', '--tw-gradient-to': 'hsl(160, 100%, 35%)'}}>Unlock Rewards</DialogTitle>
                <DialogDescription className="text-gray-300 text-lg">
                  Visit daily. Stack coins. Unlock rewards.
                </DialogDescription>
                <DialogClose asChild>
                  <Button variant="ghost" size="icon" className="absolute top-4 right-4 rounded-full text-gray-400 hover:text-white hover:bg-gray-700/50">
                    <X className="h-5 w-5" />
                  </Button>
                </DialogClose>
              </DialogHeader>
              <motion.div 
                className="p-8 pt-0 text-center"
                initial={{ opacity:0, y:10 }}
                animate={{ opacity:1, y:0 }}
                transition={{ delay: 0.2 }}
              >
                <div className="w-full h-32 flex items-center justify-center my-4 rounded-lg bg-black/20">
                    <Gift size={64} className="text-teal-400 opacity-70 animate-pulse" />
                </div>
                <Button size="lg" asChild className="w-full bg-gradient-to-r from-teal-500 to-green-500 hover:opacity-90 text-white magnetic-hover glow-effect group" onClick={() => setIsOpen(false)}>
                  <Link to="/rewards">
                    Claim Now <ArrowRight className="ml-2 h-5 w-5 transform transition-transform duration-300 group-hover:translate-x-1" />
                  </Link>
                </Button>
              </motion.div>
            </motion.div>
          </DialogContent>
        )}
      </AnimatePresence>
    </Dialog>
  );
};

export default WhyRewardModal;