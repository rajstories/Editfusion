
import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogClose } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { toast } from '@/components/ui/use-toast';
import { X, UploadCloud, Briefcase, Award, ArrowRight, Link, Loader2, FileCheck2 } from 'lucide-react';

const modalVariants = {
  hidden: { opacity: 0, scale: 0.9, y: -20 },
  visible: { opacity: 1, scale: 1, y: 0, transition: { type: 'spring', stiffness: 260, damping: 20, delay: 0.1, staggerChildren: 0.07 } },
  exit: { opacity: 0, scale: 0.9, y: 20, transition: { duration: 0.2 } },
};

const itemVariants = {
  hidden: { opacity: 0, x: -15 },
  visible: { opacity: 1, x: 0, transition: { type: 'spring', stiffness: 300, damping: 15 } },
};

const EditorApplyModal = ({ isOpen, setIsOpen, openAuthModal }) => {
  const navigate = useNavigate();
  const fileInputRef = useRef(null);
  const [uploadProgress, setUploadProgress] = useState(null);
  const [uploadedFiles, setUploadedFiles] = useState([]);
  const [videoLink, setVideoLink] = useState('');

  const handleViewProjects = () => {
    setIsOpen(false);
    navigate('/open-projects');
  };

  const handleSignup = () => {
    setIsOpen(false);
    openAuthModal('signup');
    toast({
      title: "🚀 Let's Get You Signed Up!",
      description: "Please complete the signup process to continue as an Editor.",
    });
  };

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileSelect = (event) => {
    const files = Array.from(event.target.files);
    if (files.length > 0) {
      if (files.length + uploadedFiles.length > 5) {
        toast({ title: "Limit Exceeded", description: "You can upload a maximum of 5 portfolio items.", variant: "destructive" });
        return;
      }
      setUploadedFiles(prev => [...prev, ...files]);
      setUploadProgress(0);
      
      const interval = setInterval(() => {
        setUploadProgress(prev => {
          if (prev >= 100) {
            clearInterval(interval);
            toast({
              title: "✅ Upload Complete (Simulated)",
              description: `${files.length} file(s) added to your portfolio.`,
            });
            return 100;
          }
          return prev + 20;
        });
      }, 200);
    }
  };

  const handleAddLink = () => {
    if (!videoLink.trim() || !videoLink.includes('http')) {
        toast({ title: "Invalid Link", description: "Please enter a valid video URL.", variant: "destructive" });
        return;
    }
    setUploadedFiles(prev => [...prev, {name: videoLink, isLink: true}]);
    setVideoLink('');
    toast({ title: "Link Added", description: "Video link added to your portfolio." });
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <AnimatePresence>
        {isOpen && (
          <DialogContent className="glass-effect p-0 max-w-2xl w-full overflow-hidden border-blue-500/30 shadow-2xl shadow-blue-500/20">
            <motion.div variants={modalVariants} initial="hidden" animate="visible" exit="exit">
              <DialogHeader className="p-6 pb-4 text-left relative bg-gradient-to-br from-blue-800/30 via-black/30 to-black/30">
                <DialogTitle className="text-3xl font-black mb-2">
                  <span className="gradient-text" style={{'--tw-gradient-from': 'hsl(var(--secondary))', '--tw-gradient-to': 'hsl(180, 80%, 50%)'}}>⚡ Join as an Editor</span>
                </DialogTitle>
                <DialogDescription className="text-gray-300 text-base">
                  Showcase your talent, connect with creators, and earn on your terms.
                </DialogDescription>
                <DialogClose asChild>
                  <Button variant="ghost" size="icon" className="absolute top-4 right-4 rounded-full text-gray-400 hover:text-white hover:bg-gray-700/50">
                    <X className="h-5 w-5" />
                  </Button>
                </DialogClose>
              </DialogHeader>

              <motion.div className="p-6 grid md:grid-cols-2 gap-6 items-start">
                <motion.div variants={itemVariants} className="space-y-4">
                  <h4 className="text-xl font-semibold text-blue-300">1. Build Your Portfolio</h4>
                  <input type="file" ref={fileInputRef} style={{ display: 'none' }} onChange={handleFileSelect} multiple accept="video/*,image/*"/>
                  <Button
                    size="lg"
                    className="w-full py-3 text-base bg-blue-600 hover:bg-blue-700 text-white glow-effect magnetic-hover group"
                    onClick={handleUploadClick}
                  >
                    <UploadCloud className="mr-2 h-5 w-5" /> Upload 1-5 Works
                  </Button>
                  <div className="flex gap-2">
                    <Input 
                        placeholder="Or add YouTube/Vimeo link" 
                        className="bg-black/30 border-blue-500/30 input-glow"
                        value={videoLink}
                        onChange={(e) => setVideoLink(e.target.value)}
                    />
                    <Button onClick={handleAddLink}><Link className="h-5 w-5"/></Button>
                  </div>
                  {uploadProgress !== null && uploadProgress < 100 && (
                    <div className="w-full space-y-2">
                        <Progress value={uploadProgress} className="h-2 bg-blue-400/20" indicatorClassName="bg-blue-400" />
                        <div className="flex items-center justify-center text-sm text-blue-300">
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Uploading... {uploadProgress}%
                        </div>
                    </div>
                  )}
                  {uploadedFiles.length > 0 && (
                    <div className="space-y-1 pt-2">
                        <h5 className="text-sm font-semibold text-gray-300">Portfolio Items:</h5>
                        {uploadedFiles.map((file, index) => (
                            <div key={index} className="flex items-center text-xs p-1.5 bg-gray-800/50 rounded">
                                <FileCheck2 className="h-4 w-4 mr-2 text-green-400"/>
                                <span className="truncate text-gray-300">{file.name}</span>
                            </div>
                        ))}
                    </div>
                  )}
                </motion.div>

                <motion.div variants={itemVariants} className="space-y-4">
                  <h4 className="text-xl font-semibold text-blue-300">2. Find Work & Sign Up</h4>
                  <Button
                    size="lg"
                    variant="outline"
                    className="w-full py-3 text-base border-blue-500/70 hover:border-blue-400 hover:bg-blue-500/10 text-white magnetic-hover group"
                    onClick={handleViewProjects}
                  >
                    <Briefcase className="mr-2 h-5 w-5" /> View Open Projects
                    <ArrowRight className="ml-auto h-5 w-5 transform transition-transform duration-300 group-hover:translate-x-1" />
                  </Button>
                   <Button
                    size="lg"
                    className="w-full py-3 text-base bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 text-white glow-effect magnetic-hover mt-6 group"
                    onClick={handleSignup}
                  >
                    <Award className="mr-2 h-5 w-5" /> Continue → Signup as Editor
                    <ArrowRight className="ml-auto h-5 w-5 transform transition-transform duration-300 group-hover:translate-x-1" />
                  </Button>
                </motion.div>
              </motion.div>
            </motion.div>
          </DialogContent>
        )}
      </AnimatePresence>
    </Dialog>
  );
};

export default EditorApplyModal;
