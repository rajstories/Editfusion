import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogClose } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { X, Users2, MessageSquare as MessageSquareText, Clock, Share } from 'lucide-react';

const modalVariants = {
  hidden: { opacity: 0, y: 20, filter: "blur(5px)" },
  visible: { opacity: 1, y: 0, filter: "blur(0px)", transition: { type: 'spring', stiffness: 150, damping: 20, delay: 0.1, staggerChildren: 0.15 } },
  exit: { opacity: 0, y: -20, filter: "blur(5px)", transition: { duration: 0.2 } },
};

const itemVariants = {
  hidden: { opacity: 0, scale: 0.8 },
  visible: { opacity: 1, scale: 1, transition: { type: 'spring', stiffness: 300, damping: 15 } },
};


const CollaborateModal = ({ isOpen, setIsOpen }) => {
  const handleAction = (action) => {
    toast({
      title: `🚀 Action: ${action}`,
      description: "This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <AnimatePresence>
        {isOpen && (
          <DialogContent className="glass-effect p-0 max-w-lg w-full overflow-hidden border-teal-500/30 shadow-2xl shadow-teal-500/20">
            <motion.div variants={modalVariants} initial="hidden" animate="visible" exit="exit">
              <DialogHeader className="p-6 pb-4 text-left relative">
                <DialogTitle className="text-3xl font-black mb-2">
                  <span className="gradient-text" style={{'--tw-gradient-stops': 'var(--tw-gradient-from), var(--tw-gradient-to)', '--tw-gradient-from': 'hsl(var(--secondary))', '--tw-gradient-to': 'hsl(160, 70%, 50%)'}}>Real-time Collaboration</span>
                </DialogTitle>
                <DialogDescription className="text-gray-300 text-base">
                  Work together from anywhere. Leave comments, approve drafts, and build your story with your editor in real-time.
                </DialogDescription>
                <DialogClose asChild>
                  <Button variant="ghost" size="icon" className="absolute top-4 right-4 rounded-full text-gray-400 hover:text-white hover:bg-gray-700/50">
                    <X className="h-5 w-5" />
                  </Button>
                </DialogClose>
              </DialogHeader>

              <motion.div className="p-6 pt-2 space-y-6">
                 <motion.div variants={itemVariants} className="relative h-48 bg-black/20 rounded-lg overflow-hidden">
                    <img  
                      alt="Shared timeline and chat bubbles" 
                      class="w-full h-full object-cover opacity-25"
                     src="https://images.unsplash.com/photo-1516321497487-e288fb19713f" />
                    <div className="absolute inset-0 flex items-center justify-around p-4">
                        <motion.div 
                            className="p-3 bg-teal-500/30 rounded-full"
                            animate={{ scale: [1, 1.1, 1], y: [0, -5, 0] }}
                            transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
                        >
                            <MessageSquareText className="w-8 h-8 text-teal-200" />
                        </motion.div>
                        <motion.div 
                            className="p-3 bg-green-500/30 rounded-full"
                            animate={{ scale: [1, 1.1, 1], y: [0, 5, 0] }}
                            transition={{ duration: 2.5, repeat: Infinity, ease: 'easeInOut', delay: 0.5 }}
                        >
                            <Share className="w-8 h-8 text-green-200" />
                        </motion.div>
                         <motion.div 
                            className="p-3 bg-cyan-500/30 rounded-full"
                            animate={{ scale: [1, 1.1, 1], y: [0, -3, 0] }}
                            transition={{ duration: 1.8, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
                        >
                            <Clock className="w-8 h-8 text-cyan-200" />
                        </motion.div>
                    </div>
                 </motion.div>
                
                <motion.div variants={itemVariants}>
                  <Button
                    size="lg"
                    className="w-full py-4 text-lg bg-gradient-to-r from-teal-600 to-green-600 hover:from-teal-700 hover:to-green-700 text-white glow-effect magnetic-hover"
                    onClick={() => handleAction("Go to Workspace")}
                  >
                    <Users2 className="mr-3 h-6 w-6" />
                    Go to Workspace
                  </Button>
                </motion.div>

                <motion.div variants={itemVariants}>
                  <Button
                    variant="outline"
                    className="w-full text-teal-300 hover:text-teal-200 hover:bg-teal-500/10 border-teal-500/50"
                    onClick={() => handleAction("Try Feedback Flow")}
                  >
                    Try Feedback Flow
                  </Button>
                </motion.div>
              </motion.div>
            </motion.div>
          </DialogContent>
        )}
      </AnimatePresence>
    </Dialog>
  );
};

export default CollaborateModal;