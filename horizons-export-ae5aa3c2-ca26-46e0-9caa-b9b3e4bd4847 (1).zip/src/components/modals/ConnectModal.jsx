
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogClose } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { X, Users, Briefcase, Link2 } from 'lucide-react';

const modalVariants = {
  hidden: { opacity: 0, scale: 0.9, y: -20 },
  visible: { opacity: 1, scale: 1, y: 0, transition: { type: 'spring', stiffness: 260, damping: 20, delay: 0.1 } },
  exit: { opacity: 0, scale: 0.9, y: 20, transition: { duration: 0.2 } },
};

const contentVariants = {
  hidden: { opacity: 0, y: 10 },
  visible: (i) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.1 + 0.3, duration: 0.4 }
  }),
};

const ConnectModal = ({ isOpen, setIsOpen, onOpenCreatorApplyModal, onOpenEditorApplyModal }) => {

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <AnimatePresence>
        {isOpen && (
          <DialogContent className="glass-effect p-0 max-w-lg w-full overflow-hidden border-purple-500/30 shadow-2xl shadow-purple-500/20">
            <motion.div variants={modalVariants} initial="hidden" animate="visible" exit="exit">
              <DialogHeader className="p-6 pb-4 text-left relative">
                <DialogTitle className="text-3xl font-black mb-2">
                  <span className="gradient-text">Find Your Match</span>
                </DialogTitle>
                <DialogDescription className="text-gray-300 text-base">
                  Creators, meet editors who understand your vision. Editors, discover projects worth your craft.
                </DialogDescription>
                <DialogClose asChild>
                  <Button variant="ghost" size="icon" className="absolute top-4 right-4 rounded-full text-gray-400 hover:text-white hover:bg-gray-700/50">
                    <X className="h-5 w-5" />
                  </Button>
                </DialogClose>
              </DialogHeader>

              <motion.div className="p-6 pt-2 space-y-6">
                <motion.div custom={0} variants={contentVariants} className="relative">
                  <img  
                    alt="Abstract connection lines" 
                    class="w-full h-40 object-cover rounded-lg opacity-30"
                   src="https://images.unsplash.com/photo-1556139943-4bd562959046?w=500&h=400&fit=crop" />
                  <div className="absolute inset-0 flex items-center justify-center bg-black/30">
                    <Link2 className="w-16 h-16 text-purple-400 animate-pulse" />
                  </div>
                </motion.div>
                
                <motion.div custom={1} variants={contentVariants} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <Button
                    size="lg"
                    className="w-full py-6 text-base bg-purple-600 hover:bg-purple-700 text-white glow-effect magnetic-hover flex-col h-auto"
                    onClick={onOpenCreatorApplyModal}
                  >
                    <Users className="mb-2 h-6 w-6" />
                    I'm a Creator
                  </Button>
                  <Button
                    size="lg"
                    variant="outline"
                    className="w-full py-6 text-base border-blue-500 hover:border-blue-400 hover:bg-blue-500/10 text-white magnetic-hover flex-col h-auto"
                    onClick={onOpenEditorApplyModal}
                  >
                    <Briefcase className="mb-2 h-6 w-6" />
                    I'm an Editor
                  </Button>
                </motion.div>

              </motion.div>
            </motion.div>
          </DialogContent>
        )}
      </AnimatePresence>
    </Dialog>
  );
};

export default ConnectModal;