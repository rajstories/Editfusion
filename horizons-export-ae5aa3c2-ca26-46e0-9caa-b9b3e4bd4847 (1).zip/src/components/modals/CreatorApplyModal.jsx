
import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogClose } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Progress } from '@/components/ui/progress';
import { toast } from '@/components/ui/use-toast';
import { X, UploadCloud, UserCheck, Eye, ArrowRight, Video, Edit2, Users, FileCheck2, Loader2 } from 'lucide-react';

const modalVariants = {
  hidden: { opacity: 0, scale: 0.9, y: -20 },
  visible: { opacity: 1, scale: 1, y: 0, transition: { type: 'spring', stiffness: 260, damping: 20, delay: 0.1, staggerChildren: 0.07 } },
  exit: { opacity: 0, scale: 0.9, y: 20, transition: { duration: 0.2 } },
};

const itemVariants = {
  hidden: { opacity: 0, x: -15 },
  visible: { opacity: 1, x: 0, transition: { type: 'spring', stiffness: 300, damping: 15 } },
};

const CreatorApplyModal = ({ isOpen, setIsOpen, openAuthModal }) => {
  const navigate = useNavigate();
  const fileInputRef = useRef(null);
  const [uploadProgress, setUploadProgress] = useState(null);
  const [uploadedFile, setUploadedFile] = useState(null);
  const [brief, setBrief] = useState('');

  const handleViewPortfolios = () => {
    setIsOpen(false);
    navigate('/find-editors');
  };

  const handleSignup = () => {
    setIsOpen(false);
    openAuthModal('signup');
    toast({
      title: "🚀 Let's Get You Signed Up!",
      description: "Please complete the signup process to continue as a Creator.",
    });
  };

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileSelect = (event) => {
    const file = event.target.files[0];
    if (file) {
      setUploadedFile(file);
      setUploadProgress(0);
      
      // Simulate upload
      const interval = setInterval(() => {
        setUploadProgress(prev => {
          if (prev >= 100) {
            clearInterval(interval);
            toast({
              title: "✅ Upload Complete (Simulated)",
              description: `${file.name} is ready. Now, brief your vision!`,
            });
            return 100;
          }
          return prev + 10;
        });
      }, 200);
    }
  };
  
  const handleSaveBrief = () => {
    if (!uploadedFile) {
        toast({ title: "No file uploaded", description: "Please upload a sample file first.", variant: "destructive" });
        return;
    }
    if (!brief.trim()) {
        toast({ title: "Brief is empty", description: "Please write a brief for your vision.", variant: "destructive" });
        return;
    }
    
    // Simulate saving to localStorage
    const sampleUpload = {
        userId: 'guest-creator', // In a real app, this would be the logged-in user's ID
        fileName: uploadedFile.name,
        fileSize: uploadedFile.size,
        brief: brief,
        uploadedAt: new Date().toISOString(),
    };
    localStorage.setItem('creatorSampleUpload', JSON.stringify(sampleUpload));
    
    toast({
        title: "🎉 Project Brief Saved! (Simulated)",
        description: "Your sample and brief are saved. The next step is to sign up to get matched with an editor!",
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <AnimatePresence>
        {isOpen && (
          <DialogContent className="glass-effect p-0 max-w-2xl w-full overflow-hidden border-purple-500/30 shadow-2xl shadow-purple-500/20">
            <motion.div variants={modalVariants} initial="hidden" animate="visible" exit="exit">
              <DialogHeader className="p-6 pb-4 text-left relative bg-gradient-to-br from-purple-800/30 via-black/30 to-black/30">
                <DialogTitle className="text-3xl font-black mb-2">
                  <span className="gradient-text">🎬 Start Your Creator Journey</span>
                </DialogTitle>
                <DialogDescription className="text-gray-300 text-base">
                  Unleash your creative potential. Find elite editors and bring your vision to life.
                </DialogDescription>
                <DialogClose asChild>
                  <Button variant="ghost" size="icon" className="absolute top-4 right-4 rounded-full text-gray-400 hover:text-white hover:bg-gray-700/50">
                    <X className="h-5 w-5" />
                  </Button>
                </DialogClose>
              </DialogHeader>

              <motion.div className="p-6 grid md:grid-cols-2 gap-6 items-start">
                <motion.div variants={itemVariants} className="space-y-4">
                  <h4 className="text-xl font-semibold text-purple-300">1. Upload & Brief</h4>
                  <input type="file" ref={fileInputRef} style={{ display: 'none' }} onChange={handleFileSelect} accept="video/*,image/*,.zip,.rar,.7zip"/>
                  <Button
                    size="lg"
                    className="w-full py-3 text-base bg-purple-600 hover:bg-purple-700 text-white glow-effect magnetic-hover group"
                    onClick={handleUploadClick}
                    disabled={uploadProgress !== null && uploadProgress < 100}
                  >
                    <UploadCloud className="mr-2 h-5 w-5" /> Upload Sample
                  </Button>
                  {uploadProgress !== null && (
                    <div className="w-full space-y-2">
                        <Progress value={uploadProgress} className="h-2" />
                        <div className="flex items-center justify-center text-sm text-purple-300">
                            {uploadProgress < 100 ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <FileCheck2 className="mr-2 h-4 w-4 text-green-400" />}
                            {uploadProgress < 100 ? `Uploading ${uploadedFile?.name}... ${uploadProgress}%` : `Uploaded ${uploadedFile?.name}`}
                        </div>
                    </div>
                  )}
                  {uploadProgress === 100 && (
                    <motion.div initial={{opacity: 0, y:10}} animate={{opacity:1, y:0}} className="space-y-2">
                        <Textarea 
                            placeholder="Brief your vision... What's the story? What's the style?"
                            value={brief}
                            onChange={(e) => setBrief(e.target.value)}
                            className="bg-black/30 border-purple-500/30 input-glow"
                        />
                        <Button onClick={handleSaveBrief} className="w-full bg-green-600 hover:bg-green-700">Save Brief</Button>
                    </motion.div>
                  )}
                </motion.div>

                <motion.div variants={itemVariants} className="space-y-4">
                  <h4 className="text-xl font-semibold text-purple-300">2. Find Talent & Sign Up</h4>
                  <Button
                    size="lg"
                    variant="outline"
                    className="w-full py-3 text-base border-purple-500/70 hover:border-purple-400 hover:bg-purple-500/10 text-white magnetic-hover group"
                    onClick={handleViewPortfolios}
                  >
                    <Eye className="mr-2 h-5 w-5" /> View Editor Portfolios
                    <ArrowRight className="ml-auto h-5 w-5 transform transition-transform duration-300 group-hover:translate-x-1" />
                  </Button>
                  <Button
                    size="lg"
                    className="w-full py-3 text-base bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700 text-white glow-effect magnetic-hover mt-6 group"
                    onClick={handleSignup}
                  >
                    <UserCheck className="mr-2 h-5 w-5" /> Continue → Signup as Creator
                    <ArrowRight className="ml-auto h-5 w-5 transform transition-transform duration-300 group-hover:translate-x-1" />
                  </Button>
                </motion.div>
              </motion.div>
            </motion.div>
          </DialogContent>
        )}
      </AnimatePresence>
    </Dialog>
  );
};

export default CreatorApplyModal;
