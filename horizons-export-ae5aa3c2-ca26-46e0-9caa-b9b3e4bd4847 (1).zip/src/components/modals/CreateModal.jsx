
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogClose } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { X, Scissors, Wand2, ArrowRight } from 'lucide-react';

const modalVariants = {
  hidden: { opacity: 0, y: 50, scale: 0.95 },
  visible: { opacity: 1, y: 0, scale: 1, transition: { type: 'spring', stiffness: 200, damping: 22, delay: 0.1, staggerChildren: 0.1 } },
  exit: { opacity: 0, y: -30, scale: 0.95, transition: { duration: 0.2 } },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4, ease: "easeOut" } },
};

const CreateModal = ({ isOpen, setIsOpen }) => {
  const navigate = useNavigate();

  const handleFusionEdits = () => {
    setIsOpen(false);
    navigate('/editor/new');
  };
  
  const handleFusionAI = () => {
    toast({
      title: '🚀 Fusion AI is Coming Soon!',
      description: "AI-powered editing tools are in development. Stay tuned!",
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <AnimatePresence>
        {isOpen && (
          <DialogContent className="glass-effect p-0 max-w-lg w-full overflow-hidden border-blue-500/30 shadow-2xl shadow-blue-500/20">
            <motion.div variants={modalVariants} initial="hidden" animate="visible" exit="exit">
              <DialogHeader className="p-6 pb-4 text-left relative">
                <DialogTitle className="text-3xl font-black mb-2">
                  <span className="gradient-text">Start Creating</span>
                </DialogTitle>
                <DialogDescription className="text-gray-300 text-base">
                  Choose your editing experience. Start with our powerful manual editor or explore AI-assisted tools.
                </DialogDescription>
                <DialogClose asChild>
                  <Button variant="ghost" size="icon" className="absolute top-4 right-4 rounded-full text-gray-400 hover:text-white hover:bg-gray-700/50">
                    <X className="h-5 w-5" />
                  </Button>
                </DialogClose>
              </DialogHeader>

              <motion.div className="p-6 pt-2 grid grid-cols-1 gap-4">
                  <motion.div variants={itemVariants}>
                      <button 
                        onClick={handleFusionEdits}
                        className="w-full text-left p-4 rounded-lg bg-black/20 hover:bg-black/40 border border-purple-500/30 hover:border-purple-400 transition-all duration-300 group"
                      >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center">
                              <div className="p-3 bg-purple-600/30 rounded-lg mr-4">
                                <Scissors className="w-6 h-6 text-purple-300" />
                              </div>
                              <div>
                                <h4 className="font-bold text-lg text-white">Fusion Edits</h4>
                                <p className="text-sm text-gray-400">Full-featured manual video editor.</p>
                              </div>
                            </div>
                            <ArrowRight className="w-5 h-5 text-gray-500 group-hover:text-purple-300 transition-colors" />
                          </div>
                      </button>
                  </motion.div>
                  
                  <motion.div variants={itemVariants}>
                      <button 
                        onClick={handleFusionAI}
                        className="w-full text-left p-4 rounded-lg bg-black/20 hover:bg-black/40 border border-blue-500/30 hover:border-blue-400 transition-all duration-300 group"
                      >
                           <div className="flex items-center justify-between">
                            <div className="flex items-center">
                              <div className="p-3 bg-blue-600/30 rounded-lg mr-4">
                                <Wand2 className="w-6 h-6 text-blue-300" />
                              </div>
                              <div>
                                <h4 className="font-bold text-lg text-white">Fusion AI</h4>
                                <p className="text-sm text-gray-400">AI-powered tools (Limited Access).</p>
                              </div>
                            </div>
                            <ArrowRight className="w-5 h-5 text-gray-500 group-hover:text-blue-300 transition-colors" />
                          </div>
                      </button>
                  </motion.div>
              </motion.div>
            </motion.div>
          </DialogContent>
        )}
      </AnimatePresence>
    </Dialog>
  );
};

export default CreateModal;