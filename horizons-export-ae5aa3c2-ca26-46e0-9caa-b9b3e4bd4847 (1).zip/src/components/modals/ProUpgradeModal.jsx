
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogClose } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { X, CheckCircle2, XCircle, Star, Zap, Gem } from 'lucide-react';

const modalVariants = {
  hidden: { opacity: 0, scale: 0.9 },
  visible: { opacity: 1, scale: 1, transition: { type: 'spring', stiffness: 260, damping: 20, delay: 0.1 } },
  exit: { opacity: 0, scale: 0.9, transition: { duration: 0.2 } },
};

const PlanFeature = ({ included, children }) => (
  <li className="flex items-center space-x-3">
    {included ? (
      <CheckCircle2 className="h-5 w-5 text-green-400 flex-shrink-0" />
    ) : (
      <XCircle className="h-5 w-5 text-red-400/70 flex-shrink-0" />
    )}
    <span className={!included ? 'text-gray-500 line-through' : 'text-gray-200'}>
      {children}
    </span>
  </li>
);

const plans = [
  {
    icon: <Star className="h-8 w-8 text-gray-400" />,
    name: 'Starter',
    tagline: '₹1 for 1-day trial',
    price: '₹9',
    period: '/month',
    buttonText: 'Choose Starter',
    buttonClass: 'bg-gray-600 hover:bg-gray-700',
    features: {
      emoji: true,
      messaging: false,
      fileSharing: false,
      saveEditors: false,
      notifications: false,
      support: false,
    },
  },
  {
    icon: <Zap className="h-8 w-8 text-yellow-400" />,
    name: 'Premium',
    tagline: 'Most Popular',
    price: '₹49',
    period: '/month',
    yearly: 'or ₹499/year',
    buttonText: 'Get Premium',
    buttonClass: 'bg-gradient-to-r from-purple-600 to-blue-600 glow-effect',
    isPopular: true,
    features: {
      emoji: true,
      messaging: true,
      fileSharing: true,
      saveEditors: true,
      notifications: false,
      support: false,
    },
  },
  {
    icon: <Gem className="h-8 w-8 text-cyan-400" />,
    name: 'Pro',
    tagline: 'All Access',
    price: '₹99',
    period: '/month',
    yearly: 'or ₹999/year',
    buttonText: 'Unlock Pro',
    buttonClass: 'bg-cyan-600 hover:bg-cyan-700',
    features: {
      emoji: true,
      messaging: true,
      fileSharing: true,
      saveEditors: true,
      notifications: true,
      support: true,
    },
  },
];

const ProUpgradeModal = ({ isOpen, setIsOpen, openAuthModal }) => {
  const handleChoosePlan = (planName) => {
    setIsOpen(false);
    toast({
      title: `🚀 You've chosen the ${planName} plan!`,
      description: "Please sign up or log in to proceed with payment. (Payment integration is a demo).",
    });
    openAuthModal('signup');
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <AnimatePresence>
        {isOpen && (
          <DialogContent className="glass-effect p-0 max-w-4xl w-full overflow-hidden border-purple-500/30 shadow-2xl shadow-purple-500/20">
            <motion.div variants={modalVariants} initial="hidden" animate="visible" exit="exit">
              <DialogHeader className="p-6 text-center relative">
                <DialogTitle className="text-4xl font-black mb-2">
                  <span className="gradient-text">Pick Your Perfect Plan</span>
                </DialogTitle>
                <DialogDescription className="text-gray-300 text-lg max-w-2xl mx-auto">
                  Unlock the full power of EditFusion. Upgrade now and boost your workflow.
                </DialogDescription>
                <DialogClose asChild>
                  <Button variant="ghost" size="icon" className="absolute top-4 right-4 rounded-full text-gray-400 hover:text-white hover:bg-gray-700/50">
                    <X className="h-5 w-5" />
                  </Button>
                </DialogClose>
              </DialogHeader>

              <div className="p-6 md:p-8 grid grid-cols-1 md:grid-cols-3 gap-6">
                {plans.map((plan) => (
                  <motion.div
                    key={plan.name}
                    className={`relative flex flex-col rounded-2xl p-6 border transition-all duration-300 ${
                      plan.isPopular ? 'border-purple-500 shadow-2xl shadow-purple-500/20' : 'border-gray-700'
                    } bg-gray-900/50 hover:border-purple-400 hover:-translate-y-2`}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: plans.indexOf(plan) * 0.1 }}
                  >
                    {plan.isPopular && (
                      <div className="absolute top-0 -translate-y-1/2 left-1/2 -translate-x-1/2 bg-purple-600 text-white text-xs font-bold px-3 py-1 rounded-full">
                        {plan.tagline}
                      </div>
                    )}
                    <div className="flex items-center space-x-3 mb-4">
                      {plan.icon}
                      <h3 className="text-2xl font-bold text-white">{plan.name}</h3>
                    </div>
                    {!plan.isPopular && <p className="text-sm text-gray-400 mb-2 h-5">{plan.tagline}</p>}
                    {plan.isPopular && <div className="h-5 mb-2"></div>}
                    
                    <div className="mb-6">
                      <span className="text-4xl font-extrabold text-white">{plan.price}</span>
                      <span className="text-lg text-gray-400">{plan.period}</span>
                      {plan.yearly && <p className="text-sm text-gray-400">{plan.yearly}</p>}
                    </div>

                    <ul className="space-y-3 mb-8 flex-grow">
                      <PlanFeature included={plan.features.emoji}>Emoji Support</PlanFeature>
                      <PlanFeature included={plan.features.messaging}>Direct Messaging</PlanFeature>
                      <PlanFeature included={plan.features.fileSharing}>File Sharing</PlanFeature>
                      <PlanFeature included={plan.features.saveEditors}>Save Editors</PlanFeature>
                      <PlanFeature included={plan.features.notifications}>Real-Time Notifications</PlanFeature>
                      <PlanFeature included={plan.features.support}>Priority Support</PlanFeature>
                    </ul>

                    <Button
                      size="lg"
                      className={`w-full py-3 text-base font-semibold ${plan.buttonClass}`}
                      onClick={() => handleChoosePlan(plan.name)}
                    >
                      {plan.buttonText}
                    </Button>
                  </motion.div>
                ))}
              </div>
              <div className="text-center p-6 pt-0">
                <p className="text-gray-400">Work like a Boss. Unlock the full potential of EditFusion.</p>
              </div>
            </motion.div>
          </DialogContent>
        )}
      </AnimatePresence>
    </Dialog>
  );
};

export default ProUpgradeModal;