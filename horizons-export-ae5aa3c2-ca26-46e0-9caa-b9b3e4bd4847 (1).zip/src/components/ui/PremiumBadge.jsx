
import React from 'react';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

const badgeConfig = {
    Pro: {
        label: "FusionMaster",
        emoji: "🔥",
        className: "bg-gradient-to-r from-red-500 to-orange-500 text-white border-orange-400"
    },
    Premium: {
        label: "Elite",
        emoji: "💎",
        className: "bg-gradient-to-r from-blue-500 to-cyan-500 text-white border-cyan-400"
    },
    'Creator Top 10%': {
        label: "CreatorX",
        emoji: "🚀",
        className: "bg-gradient-to-r from-purple-500 to-pink-500 text-white border-pink-400"
    }
};

const PremiumBadge = ({ tier, className }) => {
    if (!tier || !badgeConfig[tier]) return null;

    const { label, emoji, className: badgeClassName } = badgeConfig[tier];

    return (
        <Badge className={cn("text-xs font-bold", badgeClassName, className)}>
            {emoji} <span className="ml-1">{label}</span>
        </Badge>
    );
};

export default PremiumBadge;
