
import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useEditorStore } from '@/store/editorStore';
import FusionAIPanel from './FusionAIPanel';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { toast } from '../ui/use-toast';

const TextOptions = () => {
  const { addTextOverlay } = useEditorStore();
  const [text, setText] = React.useState('Hello World');

  const handleAddText = () => {
    addTextOverlay({
      text: text,
      x: 50,
      y: 50,
    });
    toast({ title: "Text Added", description: "A new text layer was added to the timeline." });
  };
  return (
    <div className='p-4 space-y-4'>
      <h4 className="font-semibold">Text Options</h4>
      <div className="space-y-2">
        <Label htmlFor="text-content">Content</Label>
        <Input id="text-content" value={text} onChange={e => setText(e.target.value)} />
      </div>
      <div className="space-y-2">
        <Label>Font Size</Label>
        <Slider defaultValue={[40]} max={128} step={1} />
      </div>
      <Button onClick={handleAddText} className='w-full'>Add Text to Timeline</Button>
    </div>
  );
};

const FilterOptions = () => {
  return (
    <div className='p-4 space-y-4'>
      <h4 className="font-semibold">Filter Options</h4>
      <div className="space-y-2">
        <Label>Brightness</Label>
        <Slider defaultValue={[0]} min={-100} max={100} step={1} />
      </div>
      <div className="space-y-2">
        <Label>Contrast</Label>
        <Slider defaultValue={[0]} min={-100} max={100} step={1} />
      </div>
       <div className="space-y-2">
        <Label>Saturation</Label>
        <Slider defaultValue={[0]} min={-100} max={100} step={1} />
      </div>
    </div>
  );
};


const RightPanel = ({ openProUpgradeModal }) => {
  const { selectedTool } = useEditorStore();

  const renderToolOptions = () => {
    switch (selectedTool) {
      case 'text':
        return <TextOptions />;
      case 'filters':
        return <FilterOptions />;
      default:
        return (
          <div className="p-4 text-center text-gray-400">
            Select a tool from the left toolbar to see its options.
          </div>
        );
    }
  };

  return (
    <Tabs defaultValue="ai" className="w-80 bg-gray-900/50 border-l border-gray-800 flex flex-col h-full">
      <TabsList className="grid w-full grid-cols-2 bg-gray-900 rounded-none">
        <TabsTrigger value="options">Tool Options</TabsTrigger>
        <TabsTrigger value="ai">Fusion AI</TabsTrigger>
      </TabsList>
      <TabsContent value="options" className="flex-grow overflow-y-auto scrollbar-thin">
        {renderToolOptions()}
      </TabsContent>
      <TabsContent value="ai" className="m-0 p-0 flex-grow h-full">
        <FusionAIPanel openProUpgradeModal={openProUpgradeModal} />
      </TabsContent>
    </Tabs>
  );
};

export default RightPanel;
