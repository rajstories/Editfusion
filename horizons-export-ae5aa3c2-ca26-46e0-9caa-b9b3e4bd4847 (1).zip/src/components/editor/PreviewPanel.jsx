
import React, { useRef, useEffect, useState } from 'react';
import { Stage, Layer, Text, Transformer } from 'react-konva';
import { useEditorStore } from '@/store/editorStore';

const TextElement = ({ shapeProps, isSelected, onSelect, onChange }) => {
  const shapeRef = useRef();
  const trRef = useRef();

  useEffect(() => {
    if (isSelected) {
      trRef.current.nodes([shapeRef.current]);
      trRef.current.getLayer().batchDraw();
    }
  }, [isSelected]);

  return (
    <React.Fragment>
      <Text
        onClick={onSelect}
        onTap={onSelect}
        ref={shapeRef}
        {...shapeProps}
        draggable
        onDragEnd={(e) => {
          onChange({
            ...shapeProps,
            x: e.target.x(),
            y: e.target.y(),
          });
        }}
        onTransformEnd={(e) => {
          const node = shapeRef.current;
          const scaleX = node.scaleX();
          const scaleY = node.scaleY();
          node.scaleX(1);
          node.scaleY(1);
          onChange({
            ...shapeProps,
            x: node.x(),
            y: node.y(),
            fontSize: (shapeProps.fontSize || 20) * scaleX,
            width: node.width() * scaleX,
            height: node.height() * scaleY,
            rotation: node.rotation(),
          });
        }}
      />
      {isSelected && (
        <Transformer
          ref={trRef}
          boundBoxFunc={(oldBox, newBox) => {
            if (newBox.width < 5 || newBox.height < 5) {
              return oldBox;
            }
            return newBox;
          }}
        />
      )}
    </React.Fragment>
  );
};


const PreviewPanel = () => {
    const { textOverlays, updateTextOverlay } = useEditorStore();
    const [selectedId, selectShape] = useState(null);
    const [containerSize, setContainerSize] = useState({ width: 0, height: 0 });
    const containerRef = useRef(null);

    useEffect(() => {
        const checkSize = () => {
            if (containerRef.current) {
                setContainerSize({
                    width: containerRef.current.offsetWidth,
                    height: containerRef.current.offsetHeight,
                });
            }
        };
        checkSize();
        window.addEventListener('resize', checkSize);
        return () => window.removeEventListener('resize', checkSize);
    }, []);

    const checkDeselect = (e) => {
        const clickedOnEmpty = e.target === e.target.getStage();
        if (clickedOnEmpty) {
            selectShape(null);
        }
    };

    return (
        <div ref={containerRef} className="flex-1 flex items-center justify-center p-4 bg-black relative">
            <video
                className="absolute top-0 left-0 w-full h-full object-contain"
                src="/placeholder-video.mp4"
                loop
                muted
            />
            <Stage 
                width={containerSize.width} 
                height={containerSize.height}
                onMouseDown={checkDeselect}
                onTouchStart={checkDeselect}
            >
                <Layer>
                    {textOverlays.map((text, i) => (
                        <TextElement
                            key={text.id}
                            shapeProps={{...text, fill: 'white', fontSize: text.fontSize || 40}}
                            isSelected={text.id === selectedId}
                            onSelect={() => selectShape(text.id)}
                            onChange={(newAttrs) => {
                                updateTextOverlay(text.id, newAttrs);
                            }}
                        />
                    ))}
                </Layer>
            </Stage>
        </div>
    );
};

export default PreviewPanel;
