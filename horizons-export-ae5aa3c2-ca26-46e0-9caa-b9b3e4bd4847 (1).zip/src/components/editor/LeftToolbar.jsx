
import React from 'react';
import { useEditorStore } from '@/store/editorStore';
import { Scissors, Text, Music, Palette, Layers, Sparkles, Key, UploadCloud } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

const ToolButton = ({ icon, label, toolName, selectedTool, setSelectedTool }) => (
  <button
    onClick={() => setSelectedTool(toolName)}
    className={`flex flex-col items-center space-y-1 p-2 rounded-lg text-gray-300 w-full transition-colors ${
      selectedTool === toolName ? 'bg-purple-500/20 text-white' : 'hover:bg-purple-500/10 hover:text-white'
    }`}
  >
    {icon}
    <span className="text-xs">{label}</span>
  </button>
);

const tools = [
  { name: 'Split', icon: <Scissors size={24} />, toolName: 'split' },
  { name: 'Text', icon: <Text size={24} />, toolName: 'text' },
  { name: 'Audio', icon: <Music size={24} />, toolName: 'audio' },
  { name: 'Filters', icon: <Palette size={24} />, toolName: 'filters' },
  { name: 'Stickers', icon: <Layers size={24} />, toolName: 'stickers' },
  { name: 'Effects', icon: <Sparkles size={24} />, toolName: 'effects' },
  { name: 'Keyframes', icon: <Key size={24} />, toolName: 'keyframes' },
];

const LeftToolbar = () => {
  const { selectedTool, setSelectedTool } = useEditorStore();
  
  const handleUpload = () => {
    toast({ title: 'Upload clicked', description: 'This would open the asset tray upload.' });
  };
  
  return (
    <aside className="w-20 bg-gray-900/50 p-2 flex flex-col items-center justify-between">
      <div className="space-y-4 w-full">
        {tools.map(tool => (
          <ToolButton 
            key={tool.toolName}
            icon={tool.icon}
            label={tool.name}
            toolName={tool.toolName}
            selectedTool={selectedTool}
            setSelectedTool={setSelectedTool}
          />
        ))}
      </div>
       <div className="w-full">
         <ToolButton 
            icon={<UploadCloud size={24} />}
            label="Upload"
            toolName="upload"
            selectedTool={selectedTool}
            setSelectedTool={handleUpload}
          />
       </div>
    </aside>
  );
};

export default LeftToolbar;
