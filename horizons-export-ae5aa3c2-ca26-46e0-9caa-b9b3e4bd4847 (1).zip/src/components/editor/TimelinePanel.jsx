
import React from 'react';
import { useEditorStore } from '@/store/editorStore';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Play, Pause, ZoomIn, ZoomOut, Plus, Trash2 } from 'lucide-react';

const TimelinePanel = () => {
  const { timeline } = useEditorStore();
  const [isPlaying, setIsPlaying] = React.useState(false);

  return (
    <div className="h-64 bg-gray-900/70 border-t border-gray-800 flex flex-col p-2">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center space-x-2">
          <Button variant="ghost" size="icon" className="text-white" onClick={() => setIsPlaying(!isPlaying)}>
            {isPlaying ? <Pause size={20} /> : <Play size={20} />}
          </Button>
          <Button variant="ghost" size="sm"><ZoomIn size={16} /></Button>
          <Slider defaultValue={[50]} max={100} step={1} className="w-32" />
          <Button variant="ghost" size="sm"><ZoomOut size={16} /></Button>
        </div>
        <Button variant="outline" size="sm" className="text-green-300 border-green-500/50 hover:bg-green-500/10">
          <Plus size={16} className="mr-2" /> Add Track
        </Button>
      </div>
      <div className="flex-1 overflow-auto scrollbar-thin relative">
        <div className="h-full min-w-max flex flex-col space-y-1 py-1 pr-2">
          {Object.entries(timeline).map(([trackType, clips]) => (
            clips.length > 0 && (
              <div key={trackType} className="h-12 bg-gray-800/50 rounded-md flex items-center p-1 border border-gray-700/50 relative">
                {clips.map(clip => (
                  <div key={clip.id} className="h-full bg-purple-500 rounded flex items-center justify-center text-xs px-2 mx-1 whitespace-nowrap" style={{width: `${clip.duration * 20}px`}}>
                    {clip.content || `${trackType} Clip`}
                  </div>
                ))}
              </div>
            )
          ))}
        </div>
      </div>
    </div>
  );
};

export default TimelinePanel;
