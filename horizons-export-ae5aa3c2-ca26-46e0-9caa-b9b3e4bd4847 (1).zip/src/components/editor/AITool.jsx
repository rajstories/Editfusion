
import React from 'react';
import { motion } from 'framer-motion';
import { Lock } from 'lucide-react';
import { cn } from '@/lib/utils';

export const AITool = ({ tool, isActive, isPremiumUser, onSelect }) => {
  const isLocked = tool.premium && !isPremiumUser;

  return (
    <motion.button
      onClick={onSelect}
      disabled={isLocked && !isActive}
      className={cn(
        "w-full flex items-center justify-between p-2.5 rounded-lg text-left transition-colors duration-200",
        isActive ? 'bg-purple-600/30 text-white' : 'hover:bg-gray-700/50 text-gray-300',
        isLocked ? 'cursor-not-allowed opacity-60' : 'cursor-pointer'
      )}
      whileTap={{ scale: 0.98 }}
    >
      <div className="flex items-center space-x-3">
        {tool.icon}
        <span className="text-sm font-medium">{tool.name}</span>
      </div>
      {isLocked && <Lock size={14} className="text-yellow-400" />}
    </motion.button>
  );
};
