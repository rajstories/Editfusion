
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AITool } from '@/components/editor/AITool';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from '@/components/ui/use-toast';
import { useEditorStore } from '@/store/editorStore';
import {
  FileText,
  MessageSquare,
  VolumeX,
  UserSquare,
  PenSquare,
  Scissors,
  Clapperboard,
  Speaker,
  Languages,
  Wand2,
  Sparkles,
} from 'lucide-react';

const aiTools = [
    { name: "Text to Video", icon: <FileText size={20} /> },
    { name: "Text-Based Editing", icon: <MessageSquare size={20} /> },
    { name: "Silence Detection", icon: <VolumeX size={20} /> },
    { name: "AI Copywriting", icon: <PenSquare size={20} /> },
    { name: "Instant Cutter", icon: <Scissors size={20} /> },
    { name: "Long Video → Shorts", icon: <Clapperboard size={20} /> },
    { name: "Audio Enhancement", icon: <Speaker size={20} /> },
    { name: "Auto-Captions", icon: <Languages size={20} /> },
    { name: "Smart Suggestions", icon: <Wand2 size={20} /> },
    { name: "Avatar Presenter", icon: <UserSquare size={20} />, premium: true }, // Kept as premium for demo
];

const FusionAIPanel = ({ openProUpgradeModal }) => {
  const { addAsset, addTrack, addTextOverlay } = useEditorStore();
  const [activeTool, setActiveTool] = useState(aiTools[0].name);
  const [prompt, setPrompt] = useState('');

  const handleToolSelect = (tool) => {
      // Example of a premium-only tool for demonstration
      if (tool.premium) {
        openProUpgradeModal();
        return;
      }
      setActiveTool(tool.name);
  };

  const handleGenerate = () => {
    if(!prompt) {
        toast({ title: "Prompt is empty", description: "Please enter some text to generate.", variant: "destructive" });
        return;
    }

    toast({
        title: "🤖 Generating AI Content...",
        description: `Your request for "${activeTool}" is being processed (this is a demo).`
    });

    // Simulate different AI tool outputs
    switch(activeTool) {
        case "Text to Video":
            addAsset({ id: `vid_${Date.now()}`, type: 'video', name: `${prompt.substring(0, 15)}.mp4`, src: '/placeholder-video.mp4' });
            break;
        case "AI Copywriting":
            addAsset({ id: `doc_${Date.now()}`, type: 'document', name: `Copy for ${prompt.substring(0, 10)}.txt`, content: `Generated AI copy for: ${prompt}` });
            break;
        case "Auto-Captions":
            addTrack({ type: 'text', clips: [{ id: `sub_${Date.now()}`, start: 0, duration: 10, content: 'Auto-generated subtitles based on video audio.' }] });
            break;
        case "Audio Enhancement":
             addAsset({ id: `aud_${Date.now()}`, type: 'audio', name: `Enhanced_Audio.mp3`, src: '/placeholder-audio.mp3' });
            break;
        default:
            toast({ title: "Suggestion added", description: `A suggestion based on "${activeTool}" has been added to your timeline.` });
            addTextOverlay({ id: `sug_${Date.now()}`, text: `Suggestion: ${activeTool}`, x: 100, y: 100 });
            break;
    }
    setPrompt('');
  };

  const renderActiveToolContent = () => {
    const tool = aiTools.find(t => t.name === activeTool);
    if (!tool || tool.premium) return (
         <div className="p-4 text-center text-gray-400">
            <p>Select a tool to get started.</p>
         </div>
    );

    return (
      <div className="p-3 space-y-3">
          <h4 className="font-semibold text-white">{activeTool}</h4>
          <Textarea 
            placeholder={`Enter prompt for ${activeTool}...`}
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="bg-gray-800 border-gray-700 min-h-[100px]"
          />
          <Button onClick={handleGenerate} className="w-full bg-purple-600 hover:bg-purple-700 glow-effect">
            <Sparkles size={16} className="mr-2" />
            Generate
          </Button>
      </div>
    );
  };

  return (
    <div className="w-80 bg-gray-900/50 border-l border-gray-800 flex flex-col h-full">
      <div className="p-3 border-b border-gray-800 text-center">
        <h3 className="font-bold text-lg text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-500">Fusion AI</h3>
      </div>
      <div className="flex-grow overflow-y-auto scrollbar-thin">
        <div className="p-2 space-y-1">
          {aiTools.map((tool) => (
            <AITool
              key={tool.name}
              tool={tool}
              isActive={activeTool === tool.name}
              isPremiumUser={true} // For UI purposes, we assume premium to show all tools
              onSelect={() => handleToolSelect(tool)}
            />
          ))}
        </div>
      </div>
      <AnimatePresence mode="wait">
        <motion.div
            key={activeTool}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
            className="border-t border-gray-800 bg-black/20"
        >
            {renderActiveToolContent()}
        </motion.div>
      </AnimatePresence>
    </div>
  );
};

export default FusionAIPanel;
