
import React from 'react';
import { useEditorStore } from '@/store/editorStore';
import { Video, Music, Image, FileText, PlusCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const AssetIcon = ({ type }) => {
  switch (type) {
    case 'video': return <Video className="w-5 h-5 text-purple-400" />;
    case 'audio': return <Music className="w-5 h-5 text-blue-400" />;
    case 'image': return <Image className="w-5 h-5 text-green-400" />;
    case 'document': return <FileText className="w-5 h-5 text-gray-400" />;
    default: return <FileText className="w-5 h-5 text-gray-400" />;
  }
};

const AssetTray = () => {
  const { assets, addAsset } = useEditorStore();
  const fileInputRef = React.useRef(null);

  const handleUploadClick = () => {
    fileInputRef.current.click();
  };

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      const fileType = file.type.split('/')[0];
      addAsset({
        id: `asset_${Date.now()}`,
        type: fileType,
        name: file.name,
        src: URL.createObjectURL(file),
      });
      toast({ title: "Asset Uploaded", description: `${file.name} has been added to your library.` });
    }
    event.target.value = null; // Reset file input
  };

  return (
    <div className="w-64 bg-gray-900/50 p-2 flex flex-col">
      <div className="flex justify-between items-center mb-2">
        <h3 className="font-bold text-lg">Assets</h3>
        <Button variant="ghost" size="icon" onClick={handleUploadClick}>
          <PlusCircle className="h-5 w-5 text-purple-400" />
        </Button>
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          className="hidden"
          accept="video/*,audio/*,image/*"
        />
      </div>
      <div className="flex-grow overflow-y-auto scrollbar-thin pr-1">
        {assets.length === 0 ? (
          <div className="text-center text-gray-500 text-sm mt-8">
            <p>Your media library is empty.</p>
            <p>Click '+' to upload.</p>
          </div>
        ) : (
          <div className="space-y-2">
            {assets.map((asset) => (
              <div
                key={asset.id}
                className="flex items-center space-x-2 p-2 bg-gray-800/50 rounded-md cursor-pointer hover:bg-purple-500/10"
              >
                <AssetIcon type={asset.type} />
                <span className="text-sm truncate" title={asset.name}>{asset.name}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default AssetTray;
