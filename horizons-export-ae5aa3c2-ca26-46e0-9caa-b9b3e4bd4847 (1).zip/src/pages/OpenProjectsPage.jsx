
import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { Briefcase, DollarSign, Calendar, Search, Filter, ArrowRight } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const openProjectsData = [
  { id: 1, title: 'YouTube Documentary on Ancient Rome', description: 'Looking for an editor for a 3-part series. Must have experience with historical content and motion graphics.', budget: 2500, deadline: '2025-08-15', skills: ['Documentary', 'After Effects', 'Storytelling'] },
  { id: 2, title: 'Fast-Paced Gaming Montage', description: 'Need a skilled editor for a 10-minute Call of Duty montage. Syncing to music and high-energy cuts are key.', budget: 500, deadline: '2025-07-30', skills: ['Gaming', 'Montage', 'VFX'] },
  { id: 3, title: 'Corporate Training Video Series', description: 'A series of 5 professional training videos. Clean, corporate style required. Long-term project potential.', budget: 3000, deadline: '2025-09-01', skills: ['Corporate', 'Premiere Pro', 'Color Grading'] },
  { id: 4, title: 'Travel Vlog - Bali Adventure', description: 'Editing a 15-minute travel vlog. Needs cinematic color grading and engaging storytelling.', budget: 800, deadline: '2025-08-05', skills: ['Vlog', 'Travel', 'DaVinci Resolve'] },
  { id: 5, title: 'Real Estate Property Showcase', description: 'High-end video tour for a luxury property. Drone footage and smooth transitions are a must.', budget: 1200, deadline: '2025-08-10', skills: ['Real Estate', 'Drone', 'Final Cut Pro'] },
];

const ProjectCard = ({ project }) => {
  const handleApply = () => {
    toast({
      title: `🚀 Applied to "${project.title}"`,
      description: "This is a simulation. In a real app, your application would be sent to the creator!",
    });
  };

  return (
    <motion.div
      className="glass-effect rounded-xl p-6 border border-blue-500/20 card-hover flex flex-col"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <h3 className="text-xl font-bold text-white mb-2">{project.title}</h3>
      <p className="text-gray-400 text-sm leading-relaxed mb-4 flex-grow">{project.description}</p>
      <div className="flex flex-wrap gap-2 mb-4">
        {project.skills.map(skill => (
          <span key={skill} className="text-xs bg-blue-500/20 text-blue-300 px-2 py-1 rounded-full">{skill}</span>
        ))}
      </div>
      <div className="border-t border-blue-500/20 pt-4 mt-auto">
        <div className="flex justify-between items-center text-sm text-gray-300 mb-4">
          <span className="flex items-center"><DollarSign size={16} className="mr-1.5 text-green-400"/> Budget: ${project.budget.toLocaleString()}</span>
          <span className="flex items-center"><Calendar size={16} className="mr-1.5 text-purple-400"/> Deadline: {project.deadline}</span>
        </div>
        <Button onClick={handleApply} className="w-full bg-gradient-to-r from-blue-600 to-cyan-600 text-white glow-effect group">
          Apply to Project <ArrowRight className="ml-2 h-5 w-5 transform transition-transform duration-300 group-hover:translate-x-1" />
        </Button>
      </div>
    </motion.div>
  );
};

const OpenProjectsPage = () => {
  return (
    <div className="container mx-auto px-4 py-16 min-h-screen">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-12"
      >
        <h1 className="text-5xl md:text-7xl font-black mb-4">
          <span className="gradient-text" style={{'--tw-gradient-from': 'hsl(var(--secondary))', '--tw-gradient-to': 'hsl(180, 80%, 50%)'}}>Open Projects</span>
        </h1>
        <p className="text-xl text-gray-300 max-w-2xl mx-auto">
          Find your next creative challenge. Browse projects from top creators and apply to the ones that match your skills.
        </p>
      </motion.div>

      <div className="mb-8 p-4 glass-effect rounded-lg border border-blue-500/30 flex flex-col sm:flex-row gap-4">
        <div className="relative flex-grow">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
            <Input 
                type="text" 
                placeholder="Search by title or skill..." 
                className="pl-10 w-full input-glow bg-black/30 border-blue-500/30"
            />
        </div>
        <Select>
            <SelectTrigger className="w-full sm:w-[180px] input-glow bg-black/30 border-blue-500/30">
                <Filter size={16} className="mr-2 text-blue-400"/>
                <SelectValue placeholder="Filter by budget" />
            </SelectTrigger>
            <SelectContent className="glass-effect border-blue-500/50">
                <SelectItem value="all" className="hover:!bg-blue-500/20">All Budgets</SelectItem>
                <SelectItem value="low" className="hover:!bg-blue-500/20">&lt; $1000</SelectItem>
                <SelectItem value="medium" className="hover:!bg-blue-500/20">$1000 - $5000</SelectItem>
                <SelectItem value="high" className="hover:!bg-blue-500/20">&gt; $5000</SelectItem>
            </SelectContent>
        </Select>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {openProjectsData.map(project => (
          <ProjectCard key={project.id} project={project} />
        ))}
      </div>
    </div>
  );
};

export default OpenProjectsPage;
