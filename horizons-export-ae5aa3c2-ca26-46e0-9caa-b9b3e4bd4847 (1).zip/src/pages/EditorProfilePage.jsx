import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Star, Briefcase, MessageSquare, PlayCircle, Tag, Award, CheckCircle, Edit, Upload, Trash2 } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

// Placeholder data - replace with API call or localStorage
const getEditorById = (id) => {
  const editors = [
    { id: '1', name: 'Alice Wonderland', bio: 'VFX Wizard & Cinematic Storyteller with over 5 years of experience crafting visually stunning narratives for film, commercials, and high-end digital content. Expert in Adobe Creative Suite, DaVinci Resolve, and Nuke. Passionate about pushing creative boundaries and delivering impactful results.', skills: ['VFX', 'Storytelling', 'Color Grading', 'Motion Graphics', 'Compositing', 'Adobe After Effects', 'DaVinci Resolve'], rating: 4.9, deliveryTime: 'Fast', language: 'English', experience: 'Expert', hourlyRate: 75, isFeatured: true, avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cG9ydHJhaXR8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=200&q=80',
      portfolio: [
        { type: 'video', title: 'Epic Space Battle VFX', url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', thumbnail: 'https://images.unsplash.com/photo-1610916099920-880507934848?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8dnlieCUyMHNwYWNlfGVufDB8fDB8fHww&auto=format&fit=crop&w=300&h=200&q=60' },
        { type: 'image', title: 'Sci-Fi Character Concept', url: '#', thumbnail: 'https://images.unsplash.com/photo-1531410112791-690652049300?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8c2NpZmkrbmFlfGVufDB8fDB8fHww&auto=format&fit=crop&w=300&h=200&q=60' },
        { type: 'reel', title: 'VFX Demo Reel 2024', url: '#', thumbnail: 'https://images.unsplash.com/photo-1517672651691-24622a91b550?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8dnJpbWFnZXxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=300&h=200&q=60' },
        { type: 'video', title: 'Product Commercial', url: '#', thumbnail: 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTV8fHByb2R1Y3RzfGVufDB8fDB8fHww&auto=format&fit=crop&w=300&h=200&q=60' },
        { type: 'image', title: 'Fantasy Landscape Matte Painting', url: '#', thumbnail: 'https://images.unsplash.com/photo-1568667256549-094345857637?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8bWF0dGUrcGFpbnRpbmd8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=300&h=200&q=60' },
      ],
      reviews: [
        { clientName: 'Visionary Films', rating: 5, comment: 'Alice is a true genius! Transformed our project beyond expectations.'},
        { clientName: 'Ad Wizards Inc.', rating: 4.5, comment: 'Exceptional VFX work and very professional. Highly recommend.'},
      ]
    },
    // Add other editors similarly if needed for testing
  ];
  // Simulate fetching user data from localStorage to check if this is "their" profile
  const loggedInUser = JSON.parse(localStorage.getItem('editFusionUser'));
  const editor = editors.find(e => e.id === id);
  if (editor) {
    editor.isOwnProfile = loggedInUser && loggedInUser.userType === 'editor' && loggedInUser.name === editor.name; // Simplified check
  }
  return editor;
};

const PortfolioItem = ({ item }) => {
  const [isHovered, setIsHovered] = useState(false);
  return (
    <motion.div 
      className="relative aspect-video rounded-lg overflow-hidden shadow-lg cursor-pointer group glass-effect border border-purple-500/20"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      whileHover={{ scale: 1.05, zIndex: 10 }}
      transition={{ type: 'spring', stiffness: 300 }}
      onClick={() => toast({ title: item.title, description: "Viewing media is not yet implemented. 🚀"})}
    >
      <img-replace src={item.thumbnail} alt={item.title} class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110" />
      <div className="absolute inset-0 bg-black/30 group-hover:bg-black/50 transition-all duration-300 flex items-center justify-center">
        <motion.div
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: isHovered ? 1 : 0.8, opacity: isHovered ? 1 : 0.7 }}
          transition={{ type: 'spring', stiffness: 200, damping: 10 }}
          className="p-3 bg-white/20 rounded-full backdrop-blur-sm"
        >
          <PlayCircle size={32} className="text-white" />
        </motion.div>
      </div>
      <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/70 to-transparent">
        <h4 className="text-white font-semibold text-sm truncate">{item.title}</h4>
        <span className="text-xs text-purple-300 capitalize">{item.type}</span>
      </div>
    </motion.div>
  );
};

const ReviewItem = ({ review }) => (
  <div className="glass-effect p-4 rounded-lg border border-purple-500/20 min-w-[280px] snap-center">
    <div className="flex items-center mb-2">
      {[...Array(Math.floor(review.rating))].map((_, i) => <Star key={`full-${i}`} size={16} fill="currentColor" className="text-yellow-400" />)}
      {review.rating % 1 !== 0 && <Star key="half" size={16} fill="currentColor" className="text-yellow-400" style={{ clipPath: 'polygon(0 0, 50% 0, 50% 100%, 0% 100%)' }} />}
      {[...Array(5 - Math.ceil(review.rating))].map((_, i) => <Star key={`empty-${i}`} size={16} className="text-yellow-400/50" />)}
      <span className="ml-2 text-sm font-semibold text-purple-300">{review.clientName}</span>
    </div>
    <p className="text-sm text-gray-300 italic">"{review.comment}"</p>
  </div>
);


const EditorProfilePage = ({ openProUpgradeModal }) => {
  const { editorId } = useParams();
  const [editor, setEditor] = useState(null);
  // For "own profile" editing
  const [isEditingBio, setIsEditingBio] = useState(false);
  const [bioContent, setBioContent] = useState("");
  const [portfolioItems, setPortfolioItems] = useState([]);


  useEffect(() => {
    const fetchedEditor = getEditorById(editorId);
    setEditor(fetchedEditor);
    if (fetchedEditor) {
      setBioContent(fetchedEditor.bio);
      setPortfolioItems(fetchedEditor.portfolio);
    }
  }, [editorId]);

  if (!editor) {
    return <div className="min-h-screen flex items-center justify-center text-xl">Editor profile not found. <Link to="/find-editors" className="ml-2 text-purple-400 hover:underline">Go back</Link></div>;
  }

  const handleMessageClick = () => {
    openProUpgradeModal();
    toast({
      title: '🔒 Messaging is a Pro feature.',
      description: 'Upgrade to Pro for instant access or wait for editor notification.',
    });
  };

  const handleSaveBio = () => {
    // Here you would typically save to backend or localStorage
    // For now, just update local state and toast.
    // In a real app, this would involve an API call.
    localStorage.setItem(`editorBio_${editor.id}`, bioContent); // Example localStorage save
    setEditor(prev => ({ ...prev, bio: bioContent }));
    setIsEditingBio(false);
    toast({ title: "✅ Bio Updated", description: "Your bio has been saved." });
  };

  const handlePortfolioUpload = (event) => {
    const files = Array.from(event.target.files);
    if (portfolioItems.length + files.length > 5) {
        toast({ title: "Limit Reached", description: "Maximum 5 portfolio items allowed.", variant: "destructive" });
        return;
    }
    const newItems = files.map(file => ({
        type: file.type.startsWith('video') ? 'video' : 'image',
        title: file.name,
        url: '#', // Placeholder URL
        thumbnail: URL.createObjectURL(file) // Temporary local thumbnail
    }));
    setPortfolioItems(prev => [...prev, ...newItems].slice(0,5));
    toast({ title: "🚀 Uploading...", description: `${files.length} item(s) added to portfolio queue.` });
    // In a real app, you'd upload to a server and get back URLs.
    // For now, we use local object URLs for thumbnails.
};

const removePortfolioItem = (index) => {
    setPortfolioItems(prev => prev.filter((_, i) => i !== index));
    toast({ title: "🗑️ Item Removed", description: "Portfolio item has been removed." });
};


  return (
    <div className="min-h-screen container mx-auto px-4 py-12">
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        {/* Header Section */}
        <div className="relative glass-effect rounded-2xl p-8 mb-12 border border-purple-500/20">
          <div className="absolute -top-4 -left-4 w-20 h-20 bg-purple-600/30 rounded-full filter blur-2xl opacity-70 animate-pulse"></div>
          <div className="absolute -bottom-4 -right-4 w-20 h-20 bg-blue-600/30 rounded-full filter blur-2xl opacity-70 animate-pulse"></div>
          
          <div className="flex flex-col md:flex-row items-center md:items-start gap-8 relative z-10">
            <img-replace src={editor.avatar} alt={editor.name} class="w-40 h-40 rounded-full object-cover border-4 border-purple-500 shadow-lg" />
            <div className="flex-1 text-center md:text-left">
              <div className="flex items-center justify-center md:justify-start mb-2">
                <h1 className="text-4xl font-black gradient-text">{editor.name}</h1>
                {editor.isFeatured && <Award size={28} className="ml-3 text-yellow-400" title="Featured Editor"/>}
              </div>
              <div className="flex items-center justify-center md:justify-start text-yellow-400 mb-3">
                {[...Array(Math.floor(editor.rating))].map((_, i) => <Star key={`full-${i}`} size={20} fill="currentColor" />)}
                {editor.rating % 1 !== 0 && <Star key="half" size={20} fill="currentColor" style={{ clipPath: 'polygon(0 0, 50% 0, 50% 100%, 0% 100%)' }} />}
                {[...Array(5 - Math.ceil(editor.rating))].map((_, i) => <Star key={`empty-${i}`} size={20} />)}
                <span className="ml-2 text-lg text-gray-300">({editor.rating.toFixed(1)})</span>
              </div>
              <p className="text-gray-400 text-sm mb-4 max-w-xl">
                {editor.experience} Editor | {editor.language} | Avg. Rate: ${editor.hourlyRate}/hr
              </p>
              {!editor.isOwnProfile && (
                <div className="flex flex-col sm:flex-row gap-3 justify-center md:justify-start">
                  <Button className="bg-gradient-to-r from-purple-600 to-blue-600 text-white magnetic-hover glow-effect" onClick={handleMessageClick}>
                    <MessageSquare size={18} className="mr-2" /> Message {editor.name.split(' ')[0]}
                  </Button>
                  <Button variant="outline" className="border-purple-500/60 hover:bg-purple-500/10 text-purple-300 hover:text-purple-200 magnetic-hover" onClick={() => toast({title: "🚧 Feature Coming Soon!"})}>
                    <Briefcase size={18} className="mr-2" /> Request a Quote
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Bio Section */}
        <motion.div className="mb-12" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }}>
          <div className="flex justify-between items-center mb-3">
            <h2 className="text-3xl font-bold text-purple-300">About Me</h2>
            {editor.isOwnProfile && !isEditingBio && (
              <Button variant="outline" size="sm" onClick={() => setIsEditingBio(true)} className="text-purple-300 border-purple-500/50 hover:bg-purple-500/10">
                <Edit size={14} className="mr-2" /> Edit Bio
              </Button>
            )}
          </div>
          {isEditingBio ? (
            <div className="glass-effect p-4 rounded-lg border border-purple-500/30">
              <textarea
                value={bioContent}
                onChange={(e) => setBioContent(e.target.value)}
                className="w-full h-40 p-3 bg-black/30 rounded-md border border-purple-500/50 focus:ring-purple-500 focus:border-purple-500 text-gray-200 input-glow"
                placeholder="Tell us about your skills and experience..."
              />
              <div className="mt-3 flex gap-2">
                <Button onClick={handleSaveBio} className="bg-purple-600 hover:bg-purple-700">Save Bio</Button>
                <Button variant="ghost" onClick={() => {setIsEditingBio(false); setBioContent(editor.bio);}}>Cancel</Button>
              </div>
            </div>
          ) : (
            <p className="text-gray-300 leading-relaxed whitespace-pre-line">{bioContent || "This editor hasn't added a bio yet."}</p>
          )}
        </motion.div>

        {/* Skills Section */}
        <motion.div className="mb-12" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }}>
          <h2 className="text-3xl font-bold text-purple-300 mb-4">Skills</h2>
          <div className="flex flex-wrap gap-3">
            {editor.skills.map(skill => (
              <span key={skill} className="text-sm bg-gray-700/60 text-purple-300 px-4 py-2 rounded-full flex items-center shadow-md">
                <Tag size={14} className="mr-2 opacity-70" /> {skill}
              </span>
            ))}
          </div>
        </motion.div>

        {/* Portfolio Section */}
        <motion.div className="mb-12" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }}>
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-3xl font-bold text-purple-300">Portfolio ({portfolioItems.length}/5)</h2>
            {editor.isOwnProfile && portfolioItems.length < 5 && (
              <Button asChild variant="outline" className="text-purple-300 border-purple-500/50 hover:bg-purple-500/10">
                <label htmlFor="portfolio-file-upload" className="cursor-pointer">
                  <Upload size={16} className="mr-2" /> Add Work
                  <input id="portfolio-file-upload" type="file" multiple className="hidden" onChange={handlePortfolioUpload} accept="video/*,image/*"/>
                </label>
              </Button>
            )}
          </div>
          {portfolioItems.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {portfolioItems.map((item, index) => (
                <div key={index} className="relative group">
                  <PortfolioItem item={item} />
                  {editor.isOwnProfile && (
                    <Button
                      variant="destructive"
                      size="icon"
                      className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity z-20 h-8 w-8"
                      onClick={() => removePortfolioItem(index)}
                    >
                      <Trash2 size={16} />
                    </Button>
                  )}
                </div>
              ))}
            </div>
          ) : (
             <p className="text-gray-400 text-center py-8 glass-effect rounded-lg border border-dashed border-purple-500/30">
                {editor.isOwnProfile ? "Your portfolio is empty. Add your best work!" : "This editor hasn't added any portfolio items yet."}
             </p>
          )}
        </motion.div>

        {/* Client Reviews Section */}
        {editor.reviews && editor.reviews.length > 0 && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }}>
            <h2 className="text-3xl font-bold text-purple-300 mb-6">Client Reviews</h2>
            <div className="flex overflow-x-auto space-x-6 pb-4 scrollbar-thin scrollbar-thumb-purple-600 scrollbar-track-black/30">
              {editor.reviews.map((review, index) => (
                <ReviewItem key={index} review={review} />
              ))}
            </div>
          </motion.div>
        )}

      </motion.div>
    </div>
  );
};

export default EditorProfilePage;