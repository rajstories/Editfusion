
import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { Users, Gift, Share2, ArrowRight, Percent, Briefcase, Coins, Link as LinkIcon } from 'lucide-react';
import TopReferrersSection from '@/components/sections/TopReferrersSection';
import ReferralLinkSection from '@/components/sections/ReferralLinkSection';
import { Link } from 'react-router-dom';


const ReferEarnPage = ({ user, openAuthModal }) => {
  const steps = [
    {
      icon: <Share2 className="w-12 h-12 text-purple-400" />,
      title: "Share Your Link",
      description: "Invite friends to join EditFusion using your unique referral link.",
    },
    {
      icon: <Users className="w-12 h-12 text-blue-400" />,
      title: "Friend Joins as Editor",
      description: "Your friend signs up as an editor and gets approved on the platform.",
    },
    {
      icon: <Briefcase className="w-12 h-12 text-cyan-400" />,
      title: "Friend Completes a Job",
      description: "Your referred editor successfully completes their first paid project.",
    },
    {
      icon: <Gift className="w-12 h-12 text-green-400" />,
      title: "You Get Rewarded!",
      description: "Receive 2000 Coins + 2% lifetime commission on their earnings!",
    },
  ];

  const handleCopyLink = () => {
    if (!user) {
        toast({ title: "Login Required", description: "Please login to get your referral link.", variant:"destructive" });
        openAuthModal('login');
        return;
    }
    const referralLink = `${window.location.origin}/refer-earn?ref=${user.id}`; // Example link
    navigator.clipboard.writeText(referralLink);
    toast({ title: "🔗 Link Copied!", description: "Your referral link is copied to clipboard. Start sharing!" });
  };
  
  return (
    <div className="container mx-auto px-4 py-16 min-h-screen">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-center mb-16"
      >
        <h1 className="text-5xl md:text-7xl font-black mb-4">
          <span className="gradient-text">Refer & Earn</span>
        </h1>
        <p className="text-xl text-gray-300 max-w-3xl mx-auto">
          Share EditFusion with talented editors and earn massive rewards! Get bonus coins and a lifetime commission on their earnings.
        </p>
      </motion.div>

      <motion.div 
        className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16 section-reveal"
        initial="hidden"
        whileInView="visible"
        variants={{
          visible: { transition: { staggerChildren: 0.2 } }
        }}
      >
        {steps.map((step, index) => (
          <motion.div
            key={index}
            className="glass-effect rounded-2xl p-8 text-center card-hover"
            variants={{
              hidden: { opacity: 0, y: 50 },
              visible: { opacity: 1, y: 0 }
            }}
          >
            <div className="w-20 h-20 bg-gray-800/50 rounded-full flex items-center justify-center mx-auto mb-6 border-2 border-purple-500/30">
              {step.icon}
            </div>
            <h3 className="text-2xl font-bold mb-3 text-white">{step.title}</h3>
            <p className="text-gray-400 leading-relaxed">{step.description}</p>
            {index < steps.length - 1 && (
              <ArrowRight className="w-8 h-8 text-purple-500 mx-auto mt-6 hidden lg:block opacity-50" />
            )}
          </motion.div>
        ))}
      </motion.div>

      <motion.div 
        className="glass-effect rounded-3xl p-8 md:p-12 max-w-4xl mx-auto text-center section-reveal"
        initial={{ opacity: 0, scale: 0.9 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5, delay: 0.3 }}
      >
        <h2 className="text-4xl font-bold mb-6 gradient-text">Your Rewards Summary</h2>
        <div className="flex flex-col md:flex-row justify-around items-center space-y-6 md:space-y-0 md:space-x-6 mb-8">
          <div className="flex items-center text-3xl font-semibold">
            <Coins className="w-10 h-10 mr-3 text-yellow-400" />
            2000 Bonus Coins
          </div>
          <div className="text-gray-400 text-2xl">+</div>
          <div className="flex items-center text-3xl font-semibold">
            <Percent className="w-10 h-10 mr-3 text-green-400" />
            2% Lifetime Commission
          </div>
        </div>
        <p className="text-gray-300 mb-8 text-lg">
          For every friend who joins as an editor and completes their first job, you unlock these amazing rewards. The more you refer, the more you earn!
        </p>
        <Button
          size="lg"
          className="magnetic-hover bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white px-10 py-4 text-lg font-semibold glow-effect"
          onClick={handleCopyLink}
        >
          <LinkIcon className="mr-2 h-5 w-5" />
          Get Your Referral Link
        </Button>
      </motion.div>
      
      <TopReferrersSection />
      <ReferralLinkSection user={user} />

      <motion.div 
        className="mt-16 text-center section-reveal"
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5, delay: 0.5 }}
      >
        <p className="text-gray-400 mb-4">
          Want to manage your referrals in detail or request referrals from clients?
        </p>
        <Link to="/referrals">
          <Button variant="outline" className="loom-cta-button border-purple-400 text-purple-300 hover:bg-purple-500/10">
            Go to Full Referral Management
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </Link>
      </motion.div>
    </div>
  );
};

export default ReferEarnPage;
