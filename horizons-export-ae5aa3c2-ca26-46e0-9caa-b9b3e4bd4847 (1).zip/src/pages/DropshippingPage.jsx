import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { Package, ShoppingCart, Users, DollarSign, ArrowRightCircle, CheckCircle } from 'lucide-react';

const dropshippingSteps = [
  {
    id: 1,
    icon: <ShoppingCart className="w-10 h-10 text-purple-400" />,
    title: "Customer Places Order",
    description: "A customer purchases a product from your online store, which is integrated with EditFusion's dropshipping service.",
    image: "https://images.unsplash.com/photo-1580974928075-00a1107e0557?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8b25saW5lJTIwc2hvcHBpbmd8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60"
  },
  {
    id: 2,
    icon: <Package className="w-10 h-10 text-blue-400" />,
    title: "Order Sent to EditFusion",
    description: "The order details are automatically (or manually) forwarded to EditFusion or your partnered supplier.",
    image: "https://images.unsplash.com/photo-1578575437130-527eed3abbec?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8cGFja2FnZXxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60"
  },
  {
    id: 3,
    icon: <Users className="w-10 h-10 text-cyan-400" />,
    title: "Supplier Ships Product",
    description: "The EditFusion supplier packages and ships the product directly to your customer under your brand.",
    image: "https://images.unsplash.com/photo-1590701900300-85a1e9a3e033?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fHNoaXBwaW5nfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60"
  },
  {
    id: 4,
    icon: <DollarSign className="w-10 h-10 text-green-400" />,
    title: "You Keep the Profit",
    description: "You pay the supplier the wholesale price and keep the difference (your profit margin) from the customer's payment.",
    image: "https://images.unsplash.com/photo-1579621970795-87facc2f976d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8bW9uZXl8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60"
  }
];

const DropshippingPage = () => {
  const [hoveredStep, setHoveredStep] = useState(dropshippingSteps[0].id);

  const handleFeatureRequest = () => {
     toast({ title: "🚧 Feature Request", description: "This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀" });
  }

  return (
    <div className="container mx-auto px-4 py-16 min-h-screen">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-center mb-16"
      >
        <h1 className="text-5xl md:text-7xl font-black mb-4">
          <span className="gradient-text">EditFusion Dropshipping</span>
        </h1>
        <p className="text-xl text-gray-300 max-w-3xl mx-auto">
          Seamlessly sell high-quality edited video products without holding inventory. We handle the fulfillment, you focus on sales.
        </p>
      </motion.div>

      <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
        <motion.div className="relative section-reveal">
          {dropshippingSteps.map(step => (
            <motion.div
              key={step.id}
              initial={{ opacity: 0 }}
              animate={{ opacity: hoveredStep === step.id ? 1 : 0 }}
              transition={{ duration: 0.5 }}
              className="absolute inset-0 w-full h-full"
            >
              <img  
                src={step.image} 
                alt={step.title} 
                class="w-full h-full object-cover rounded-3xl shadow-2xl" 
               src="https://images.unsplash.com/photo-1667844049125-4be3b67611dc" />
              <div className="absolute inset-0 bg-black/50 rounded-3xl"></div>
            </motion.div>
          ))}
           <div className="relative glass-effect rounded-3xl p-8 min-h-[400px] md:min-h-[500px] flex flex-col justify-end">
             {dropshippingSteps.map(step => hoveredStep === step.id && (
                <motion.div 
                    key={`text-${step.id}`}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ duration: 0.3 }}
                    className="text-white"
                >
                    <h2 className="text-3xl font-bold mb-2">{step.title}</h2>
                    <p className="text-lg text-gray-200">{step.description}</p>
                </motion.div>
             ))}
           </div>
        </motion.div>

        <motion.div className="space-y-6 section-reveal">
          {dropshippingSteps.map((step, index) => (
            <motion.div
              key={step.id}
              className={`p-6 rounded-2xl cursor-pointer transition-all duration-300 ease-in-out
                ${hoveredStep === step.id ? 'glass-effect border-2 border-purple-500 scale-105 shadow-xl' : 'bg-gray-800/40 border border-gray-700 hover:bg-gray-800/70'}`}
              onMouseEnter={() => setHoveredStep(step.id)}
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <div className="flex items-center">
                <div className={`p-3 rounded-full mr-4 ${hoveredStep === step.id ? 'bg-purple-600/30' : 'bg-gray-700/50'}`}>
                  {step.icon}
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-white">{step.title}</h3>
                  {hoveredStep !== step.id && <p className="text-sm text-gray-400 truncate">{step.description}</p>}
                </div>
                {hoveredStep === step.id && <CheckCircle className="w-6 h-6 text-green-400 ml-auto" />}
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>

      <motion.div 
        className="text-center section-reveal"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
      >
        <h2 className="text-3xl font-bold mb-6 gradient-text">Ready to Start Dropshipping?</h2>
        <p className="text-gray-300 mb-8 max-w-xl mx-auto">
          Integrate with EditFusion's dropshipping program and unlock a new revenue stream for your creative business.
        </p>
        <Button
          size="lg"
          className="magnetic-hover bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white px-10 py-4 text-lg font-semibold glow-effect"
          onClick={handleFeatureRequest}
        >
          <ArrowRightCircle className="mr-2 h-5 w-5" />
          Learn More & Get Started
        </Button>
      </motion.div>
    </div>
  );
};

export default DropshippingPage;