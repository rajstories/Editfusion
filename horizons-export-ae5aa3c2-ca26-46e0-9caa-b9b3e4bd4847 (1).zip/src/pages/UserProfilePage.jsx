
import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { User, Mail, Briefcase, Edit3, LogOut, ListChecks, Users2, Settings, ShieldCheck, GraduationCap } from 'lucide-react';
import { useNavigate, Link } from 'react-router-dom';
import { toast } from '@/components/ui/use-toast';

const UserProfilePage = ({ user, logout }) => {
  const navigate = useNavigate();

  if (!user) {
    // This should ideally be handled by ProtectedRoute, but as a fallback:
    navigate('/');
    return null;
  }
  
  const getInitials = (name) => {
    if (!name) return "?";
    const names = name.split(' ');
    if (names.length === 1) return names[0].charAt(0).toUpperCase();
    return names[0].charAt(0).toUpperCase() + names[names.length - 1].charAt(0).toUpperCase();
  };

  const handleLogout = () => {
    logout();
    toast({ title: "Logged Out", description: "You have been successfully logged out." });
    navigate('/');
  };

  const roleIcon = (role) => {
    if (role === 'editor') return <Briefcase className="w-5 h-5 text-blue-400" />;
    if (role === 'creator') return <User className="w-5 h-5 text-purple-400" />;
    if (role === 'student') return <GraduationCap className="w-5 h-5 text-green-400" />;
    return <User className="w-5 h-5 text-gray-400" />;
  };

  // Placeholder data for active tasks/referrals
  const activeTasksCount = user.role === 'editor' ? 5 : (user.role === 'creator' ? 3 : 0);
  const referralsSentCount = 12;
  const projectsCount = user.role === 'creator' ? 2 : (user.role === 'editor' ? 7 : 0);

  return (
    <div className="container mx-auto px-4 py-12 min-h-screen">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="max-w-3xl mx-auto"
      >
        <div className="glass-effect rounded-2xl p-8 mb-8 border border-purple-500/20 shadow-xl">
          <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6">
            <Avatar className="w-28 h-28 border-4 border-primary shadow-lg">
              <AvatarImage src={user.avatar || `https://avatar.vercel.sh/${user.email}.png`} alt={user.name} />
              <AvatarFallback className="text-4xl bg-primary/80 text-primary-foreground">{getInitials(user.name)}</AvatarFallback>
            </Avatar>
            <div className="flex-1 text-center sm:text-left">
              <h1 className="text-4xl font-black gradient-text mb-1">{user.name || 'User Name'}</h1>
              <div className="flex items-center justify-center sm:justify-start text-gray-400 mb-3">
                {roleIcon(user.role)}
                <span className="ml-2 capitalize">{user.role || 'User Role'}</span>
              </div>
              <p className="text-gray-300 flex items-center justify-center sm:justify-start mb-4">
                <Mail size={16} className="mr-2 text-purple-300" /> {user.email || 'user@example.com'}
              </p>
              <div className="flex gap-3 justify-center sm:justify-start">
                <Button 
                  variant="outline" 
                  className="border-purple-500/60 hover:bg-purple-500/10 text-purple-300 hover:text-purple-200"
                  onClick={() => toast({ title: "🚧 Edit Profile", description: "This feature is coming soon!"})}
                >
                  <Edit3 size={16} className="mr-2" /> Edit Profile
                </Button>
                <Button 
                  variant="destructive" 
                  onClick={handleLogout}
                  className="bg-red-600/80 hover:bg-red-600 text-white"
                >
                  <LogOut size={16} className="mr-2" /> Logout
                </Button>
              </div>
            </div>
          </div>
        </div>

        <motion.div 
          className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2, staggerChildren: 0.1 }}
        >
          <InfoCard icon={<ListChecks size={24} className="text-green-400"/>} title="Active Tasks" value={activeTasksCount} />
          <InfoCard icon={<Users2 size={24} className="text-blue-400"/>} title="Referrals Sent" value={referralsSentCount} />
          <InfoCard icon={<Briefcase size={24} className="text-yellow-400"/>} title="Projects" value={projectsCount} />
        </motion.div>
        
        <div className="space-y-4">
          <Link to={user.role === 'editor' ? '/tasks' : '/find-editors'}>
            <Button size="lg" className="w-full bg-gradient-to-r from-primary to-secondary text-white glow-effect">
              {user.role === 'editor' ? 'Go to My Tasks' : 'Find Editors / Start Project'}
            </Button>
          </Link>
          {user.role === 'student' && (
             <Link to="/student-earn">
                <Button size="lg" className="w-full bg-gradient-to-r from-green-500 to-teal-500 text-white glow-effect">
                  Go to Student Earning Zone
                </Button>
            </Link>
          )}
          <Link to="/settings">
            <Button 
              variant="outline" 
              size="lg" 
              className="w-full border-purple-500/60 hover:bg-purple-500/10 text-purple-300 hover:text-purple-200"
              onClick={() => toast({ title: "🚧 Settings", description: "Account settings page is under development."})}
            >
              <Settings size={18} className="mr-2"/> Account Settings
            </Button>
          </Link>
           <Link to="/privacy">
            <Button 
              variant="outline" 
              size="lg" 
              className="w-full border-gray-600 hover:bg-gray-700/30 text-gray-400 hover:text-gray-300"
              onClick={() => toast({ title: "🚧 Privacy & Security", description: "This feature is coming soon!"})}
            >
              <ShieldCheck size={18} className="mr-2"/> Privacy & Security
            </Button>
          </Link>
        </div>
      </motion.div>
    </div>
  );
};

const InfoCard = ({ icon, title, value }) => (
  <motion.div 
    className="glass-effect p-6 rounded-xl border border-purple-500/20 text-center card-hover"
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
  >
    <div className="w-12 h-12 bg-gray-700/50 rounded-full flex items-center justify-center mx-auto mb-3 border border-purple-400/30">
      {icon}
    </div>
    <p className="text-3xl font-bold text-white mb-1">{value}</p>
    <p className="text-sm text-gray-400">{title}</p>
  </motion.div>
);

export default UserProfilePage;
