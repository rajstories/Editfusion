
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea.jsx'; 
import { Progress } from '@/components/ui/progress.jsx'; 
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from '@/components/ui/use-toast';
import { PlusCircle, ListChecks, Upload, MessageSquare, Link2, Copy, Filter, Search } from 'lucide-react';


const initialTasks = [
  { id: 'task001', title: 'VFX for "Cosmic Journey" Trailer', progress: 75, status: 'In Review', client: 'Galaxy Films', deadline: '2025-07-15', deliverables: [{name: 'trailer_vfx_v3.mp4', url: '#'}], feedback: [{user: 'Client', text: 'Looks great! Just one minor tweak on the ship explosion.'}] },
  { id: 'task002', title: 'Color Grade "Sunset Romance" Short Film', progress: 40, status: 'Pending', client: 'Indie Shorts Co.', deadline: '2025-07-22', deliverables: [], feedback: [] },
  { id: 'task003', title: 'Edit 5 Social Media Teaser Clips', progress: 100, status: 'Done', client: 'BrandSpark', deadline: '2025-07-01', deliverables: [{name: 'teasers_final.zip', url: '#'}], feedback: [{user: 'Client', text: 'Perfect! Approved.'}] },
];

const TaskCard = ({ task, onUpdateTask, onShareTask }) => {
  const [showFeedbackInput, setShowFeedbackInput] = useState(false);
  const [newFeedback, setNewFeedback] = useState('');

  const handleStatusChange = (newStatus) => {
    onUpdateTask(task.id, { status: newStatus });
  };

  const handleProgressChange = (e) => {
    const newProgress = parseInt(e.target.value, 10);
    if (!isNaN(newProgress) && newProgress >= 0 && newProgress <= 100) {
      onUpdateTask(task.id, { progress: newProgress });
    }
  };
  
  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
        onUpdateTask(task.id, { deliverables: [...task.deliverables, { name: file.name, url: '#' }] });
        toast({ title: "File Uploaded", description: `${file.name} added to deliverables.` });
    }
  };

  const submitFeedback = () => {
    if (newFeedback.trim()) {
      onUpdateTask(task.id, { feedback: [...task.feedback, { user: 'Editor Note', text: newFeedback }] });
      setNewFeedback('');
      setShowFeedbackInput(false);
    }
  };

  const getStatusColor = (status) => {
    if (status === 'Done') return 'bg-green-500/20 text-green-300 border-green-500/50';
    if (status === 'In Review') return 'bg-yellow-500/20 text-yellow-300 border-yellow-500/50';
    if (status === 'Pending') return 'bg-blue-500/20 text-blue-300 border-blue-500/50';
    return 'bg-gray-500/20 text-gray-300 border-gray-500/50';
  };

  return (
    <motion.div 
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="glass-effect p-6 rounded-xl border border-purple-500/20 mb-6"
    >
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-3">
        <h3 className="text-xl font-bold text-white mb-2 sm:mb-0">{task.title} <span className="text-xs text-gray-500">(ID: {task.id})</span></h3>
        <div className={`px-3 py-1 rounded-full text-xs font-semibold ${getStatusColor(task.status)}`}>
          {task.status}
        </div>
      </div>
      <p className="text-sm text-gray-400 mb-1">Client: {task.client}</p>
      <p className="text-sm text-gray-400 mb-4">Deadline: {task.deadline}</p>

      <div className="mb-4">
        <div className="flex justify-between items-center mb-1">
          <label htmlFor={`progress-${task.id}`} className="text-sm text-gray-300">Progress: {task.progress}%</label>
          <input 
            type="range" 
            id={`progress-${task.id}`} 
            min="0" max="100" 
            value={task.progress} 
            onChange={handleProgressChange} 
            className="w-24 accent-purple-500"
          />
        </div>
        <Progress value={task.progress} className="h-2.5"/>
      </div>
      
      <div className="mb-4">
        <label className="text-sm font-medium text-gray-300 block mb-1">Status Update:</label>
        <Select value={task.status} onValueChange={handleStatusChange}>
          <SelectTrigger className="w-full input-glow bg-black/30 border-purple-500/30">
            <SelectValue placeholder="Update Status" />
          </SelectTrigger>
          <SelectContent className="glass-effect border-purple-500/50">
            <SelectItem value="Pending" className="hover:!bg-purple-500/20">Pending</SelectItem>
            <SelectItem value="In Progress" className="hover:!bg-purple-500/20">In Progress</SelectItem>
            <SelectItem value="In Review" className="hover:!bg-purple-500/20">In Review</SelectItem>
            <SelectItem value="Done" className="hover:!bg-purple-500/20">Done</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="mb-4">
        <h4 className="text-sm font-medium text-gray-300 mb-1">Deliverables ({task.deliverables.length}):</h4>
        {task.deliverables.map((file, idx) => (
            <div key={idx} className="text-xs text-blue-300 bg-blue-500/10 p-1.5 rounded mb-1">{file.name}</div>
        ))}
        <label htmlFor={`file-upload-${task.id}`} className="mt-1 inline-flex items-center px-3 py-1.5 text-xs bg-purple-600 hover:bg-purple-700 text-white rounded-md cursor-pointer">
            <Upload size={14} className="mr-1.5" /> Upload File
        </label>
        <input type="file" id={`file-upload-${task.id}`} className="hidden" onChange={handleFileUpload} />
      </div>

      <div className="mb-4">
        <h4 className="text-sm font-medium text-gray-300 mb-2">Feedback/Notes ({task.feedback.length}):</h4>
        {task.feedback.map((fb, idx) => (
          <div key={idx} className="text-xs p-2 rounded bg-gray-700/40 mb-1.5">
            <span className="font-semibold text-purple-300">{fb.user}: </span>
            <span className="text-gray-300">{fb.text}</span>
          </div>
        ))}
        <Button variant="link" size="sm" className="text-xs text-purple-300 px-0" onClick={() => setShowFeedbackInput(!showFeedbackInput)}>
          {showFeedbackInput ? 'Cancel Note' : 'Add Note'}
        </Button>
        {showFeedbackInput && (
          <div className="mt-2">
            <Textarea 
                placeholder="Type your note..." 
                value={newFeedback} 
                onChange={(e) => setNewFeedback(e.target.value)}
                className="bg-black/30 border-purple-500/30 input-glow text-sm"
            />
            <Button size="sm" onClick={submitFeedback} className="mt-1.5 bg-purple-600 hover:bg-purple-700">Save Note</Button>
          </div>
        )}
      </div>

      <Button 
        variant="outline" 
        className="w-full border-green-500/50 hover:bg-green-500/10 text-green-300"
        onClick={() => onShareTask(task.id)}
      >
        <Link2 size={16} className="mr-2"/> Share Task Link with Client
      </Button>
    </motion.div>
  );
};


const TaskTrackerPage = ({ user }) => {
  const [tasks, setTasks] = useState(initialTasks);
  const [showNewTaskModal, setShowNewTaskModal] = useState(false); 
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [filterStatus, setFilterStatus] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');

  const handleUpdateTask = (taskId, updates) => {
    setTasks(prevTasks => prevTasks.map(task => task.id === taskId ? { ...task, ...updates } : task));
  };

  const handleAddNewTask = (e) => {
    e.preventDefault();
    if (!newTaskTitle.trim()) {
      toast({ title: "Task title required", variant: "destructive" });
      return;
    }
    const newTask = {
      id: `task${Date.now().toString().slice(-3)}`,
      title: newTaskTitle,
      progress: 0,
      status: 'Pending',
      client: 'To be assigned', 
      deadline: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], 
      deliverables: [],
      feedback: []
    };
    setTasks(prevTasks => [newTask, ...prevTasks]);
    setNewTaskTitle('');
    toast({ title: "New Task Added!", description: `Task "${newTask.title}" created.`});
  };

  const handleShareTask = (taskId) => {
    const taskLink = `${window.location.origin}/task/${taskId}`;
    navigator.clipboard.writeText(taskLink);
    toast({ title: "🔗 Link Copied!", description: `Client view link for task ${taskId} copied to clipboard.` });
  };

  const filteredTasks = tasks.filter(task => {
    const matchesStatus = filterStatus === 'All' || task.status === filterStatus;
    const matchesSearch = task.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          task.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          task.client.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  return (
    <div className="container mx-auto px-4 py-12 min-h-screen">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col sm:flex-row justify-between items-center mb-8"
      >
        <h1 className="text-4xl font-black gradient-text mb-4 sm:mb-0">My Tasks</h1>
        <Button onClick={() => toast({ title: "🚧 New Task Form", description: "Adding tasks directly here for demo. A modal form would be ideal!" })} className="bg-gradient-to-r from-primary to-secondary text-white glow-effect">
          <PlusCircle size={20} className="mr-2"/> Add New Task
        </Button>
      </motion.div>

      
      <form onSubmit={handleAddNewTask} className="mb-8 p-4 glass-effect rounded-lg border border-purple-500/30 space-y-3">
        <Input 
            type="text" 
            placeholder="Enter new task title..." 
            value={newTaskTitle}
            onChange={(e) => setNewTaskTitle(e.target.value)}
            className="input-glow bg-black/30 border-purple-500/30"
        />
        <Button type="submit" className="w-full sm:w-auto bg-purple-600 hover:bg-purple-700">Quick Add Task</Button>
      </form>


      <div className="mb-6 p-4 glass-effect rounded-lg border border-purple-500/30 flex flex-col sm:flex-row gap-4">
        <div className="relative flex-grow">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
            <Input 
                type="text" 
                placeholder="Search tasks by title, ID, or client..." 
                className="pl-10 w-full input-glow bg-black/30 border-purple-500/30"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
            />
        </div>
        <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-full sm:w-[180px] input-glow bg-black/30 border-purple-500/30">
                <Filter size={16} className="mr-2 text-purple-400"/>
                <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent className="glass-effect border-purple-500/50">
                <SelectItem value="All" className="hover:!bg-purple-500/20">All Statuses</SelectItem>
                <SelectItem value="Pending" className="hover:!bg-purple-500/20">Pending</SelectItem>
                <SelectItem value="In Progress" className="hover:!bg-purple-500/20">In Progress</SelectItem>
                <SelectItem value="In Review" className="hover:!bg-purple-500/20">In Review</SelectItem>
                <SelectItem value="Done" className="hover:!bg-purple-500/20">Done</SelectItem>
            </SelectContent>
        </Select>
      </div>


      {filteredTasks.length > 0 ? (
        <motion.div layout className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredTasks.map(task => (
            <TaskCard 
              key={task.id} 
              task={task} 
              onUpdateTask={handleUpdateTask}
              onShareTask={handleShareTask}
            />
          ))}
        </motion.div>
      ) : (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-16 glass-effect rounded-xl border border-dashed border-gray-700"
        >
          <ListChecks size={48} className="mx-auto text-gray-600 mb-4" />
          <h2 className="text-2xl font-semibold text-gray-400">No tasks match your filters.</h2>
          <p className="text-gray-500">Try adjusting search or filter, or add a new task!</p>
        </motion.div>
      )}
    </div>
  );
};

export default TaskTrackerPage;
