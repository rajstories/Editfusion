
import React from 'react';
import { motion } from 'framer-motion';
import { useEditorStore } from '@/store/editorStore';
import { useAuthStore } from '@/store/authStore';
import { useNavigate, useParams } from 'react-router-dom';
import LeftToolbar from '@/components/editor/LeftToolbar';
import PreviewPanel from '@/components/editor/PreviewPanel';
import TimelinePanel from '@/components/editor/TimelinePanel';
import RightPanel from '@/components/editor/RightPanel';
import AssetTray from '@/components/editor/AssetTray';
import { Button } from '@/components/ui/button';
import { Download, Film, Share2 } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import ProUpgradeModal from '@/components/modals/ProUpgradeModal';

const VideoEditorPage = () => {
    const { projectName, setProjectName } = useEditorStore();
    const { projectId } = useParams();
    const [isProModalOpen, setIsProModalOpen] = React.useState(false);

    React.useEffect(() => {
      setProjectName(projectId === 'new' || !projectId ? 'Untitled Project' : `Project ${projectId}`);
    }, [projectId, setProjectName]);
    
    const handleExport = () => {
      toast({
        title: "🚀 Exporting Project...",
        description: "Your video is being rendered. This is a demo, so no file will be downloaded.",
      });
    };

    return (
        <div className="flex flex-col h-[calc(100vh-64px)] pt-0 bg-black text-white overflow-hidden">
            <header className="flex items-center justify-between p-2 border-b border-gray-800 bg-gray-900/50 flex-shrink-0">
                <div className="flex items-center space-x-2">
                    <Film className="w-6 h-6 text-purple-400" />
                    <input
                        type="text"
                        value={projectName}
                        onChange={(e) => setProjectName(e.target.value)}
                        className="bg-transparent text-white font-semibold focus:ring-1 focus:ring-purple-500 rounded px-2 py-1"
                    />
                </div>
                <div className="flex items-center space-x-2">
                    <Button variant="ghost" size="sm"><Share2 size={16} className="mr-2" /> Share</Button>
                    <Button size="sm" className="bg-purple-600 hover:bg-purple-700 glow-effect" onClick={handleExport}>
                        <Download size={16} className="mr-2" /> Export
                    </Button>
                </div>
            </header>

            <div className="flex flex-grow overflow-hidden">
                <LeftToolbar />
                <AssetTray />
                <main className="flex-1 flex flex-col overflow-hidden">
                    <PreviewPanel />
                    <TimelinePanel />
                </main>
                <RightPanel openProUpgradeModal={() => setIsProModalOpen(true)} />
            </div>

            <ProUpgradeModal isOpen={isProModalOpen} setIsOpen={setIsProModalOpen} />
        </div>
    );
};

export default VideoEditorPage;
