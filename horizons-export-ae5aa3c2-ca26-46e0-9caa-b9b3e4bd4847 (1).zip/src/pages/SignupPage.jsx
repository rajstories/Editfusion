
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from '@/components/ui/use-toast';
import { UserPlus } from 'lucide-react';
import { useAuthStore } from '@/store/authStore';

const SignupPage = () => {
    const navigate = useNavigate();
    const { login } = useAuthStore();
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const handleSignup = (e) => {
        e.preventDefault();
        if (!name || !email || !password) {
            toast({ title: "Error", description: "Please fill in all fields.", variant: "destructive" });
            return;
        }
        if (password.length < 8 || !/\d/.test(password) || !/\W/.test(password)) {
             toast({ title: "Weak Password", description: "Password must be 8+ chars with at least 1 number and 1 symbol.", variant: "destructive" });
            return;
        }

        toast({ title: "Account Created!", description: `Welcome to EditFusion, ${name}!` });
        login({ email: email, name: name });
        navigate('/profile');
    };
    
    const handleGoogleSignup = () => {
        toast({ title: "Signing up with Google...", description: "You will be redirected shortly (demo)." });
        setTimeout(() => {
            login({ email: 'new.google.user@gmail.com', name: 'Google User' });
            navigate('/profile');
        }, 1500);
    };

    return (
        <div className="min-h-screen flex items-center justify-center bg-grid-purple-500/10 p-4">
            <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="w-full max-w-md glass-effect p-8 rounded-2xl border border-purple-500/30 shadow-2xl shadow-purple-500/10"
            >
                <div className="text-center mb-8">
                    <h1 className="text-4xl font-black gradient-text">Create Account</h1>
                    <p className="text-gray-400 mt-2">Join EditFusion and start creating.</p>
                </div>
                
                <form onSubmit={handleSignup} className="space-y-4">
                    <div>
                        <Label htmlFor="name">Full Name</Label>
                        <Input id="name" type="text" placeholder="Alex Chen" value={name} onChange={(e) => setName(e.target.value)} className="bg-gray-900/50" />
                    </div>
                    <div>
                        <Label htmlFor="email">Email</Label>
                        <Input id="email" type="email" placeholder="you@example.com" value={email} onChange={(e) => setEmail(e.target.value)} className="bg-gray-900/50" />
                    </div>
                    <div>
                        <Label htmlFor="password">Password</Label>
                        <Input id="password" type="password" placeholder="••••••••" value={password} onChange={(e) => setPassword(e.target.value)} className="bg-gray-900/50" />
                        <p className="text-xs text-gray-500 mt-1">8+ characters with a number & symbol.</p>
                    </div>
                    <Button type="submit" className="w-full glow-effect"><UserPlus className="mr-2 h-4 w-4" /> Sign Up</Button>
                </form>

                <div className="relative my-6">
                    <div className="absolute inset-0 flex items-center"><span className="w-full border-t border-gray-700" /></div>
                    <div className="relative flex justify-center text-xs uppercase"><span className="bg-gray-900/50 px-2 text-gray-400">Or sign up with</span></div>
                </div>

                <Button variant="outline" className="w-full" onClick={handleGoogleSignup}>
                    <svg className="mr-2 h-4 w-4" aria-hidden="true" focusable="false" data-prefix="fab" data-icon="google" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 488 512"><path fill="currentColor" d="M488 261.8C488 403.3 391.1 504 248 504 110.8 504 0 393.2 0 256S110.8 8 248 8c66.8 0 126 21.2 177.2 62.2l-61.2 61.2c-27.8-26.2-68.2-41.8-116-41.8-93 0-169.3 76.3-169.3 169.3s76.3 169.3 169.3 169.3c104.5 0 142.8-82.3 149.7-123.3H248.1v-78.3h236.1c2.3 12.7 3.9 26.9 3.9 41.4z"></path></svg>
                    Sign up with Google
                </Button>

                <p className="mt-8 text-center text-sm text-gray-400">
                    Already have an account?{' '}
                    <Link to="/login" className="font-semibold text-purple-400 hover:text-purple-300">
                        Log in
                    </Link>
                </p>
            </motion.div>
        </div>
    );
};

export default SignupPage;
