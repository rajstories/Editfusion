
import React from 'react';
import { motion } from 'framer-motion';
import { Bell, AlertTriangle, CheckCircle, MessageSquare, Gift, Users, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const notificationsData = [
  { id: 1, type: 'project_update', title: 'Project "Neon Dreams" Updated', description: 'Client added new footage and comments.', time: '2 hours ago', icon: <MessageSquare className="text-blue-400" />, read: false },
  { id: 2, type: 'feedback', title: 'Feedback Received for "Alpha Reel"', description: 'Client "Visionary Vids" left feedback. Revisions requested.', time: '5 hours ago', icon: <AlertTriangle className="text-yellow-400" />, read: false },
  { id: 3, type: 'payment', title: 'Payment Processed!', description: 'You received $250 for "Quick Cut Gig".', time: '1 day ago', icon: <CheckCircle className="text-green-400" />, read: true },
  { id: 4, type: 'referral_new', title: 'New Referral Joined!', description: 'Your friend "Jane Doe" signed up as an editor.', time: '2 days ago', icon: <Users className="text-purple-400" />, read: true },
  { id: 5, type: 'reward', title: 'Daily Reward Available', description: 'Claim your daily login bonus now!', time: 'Now', icon: <Gift className="text-pink-400" />, read: false },
];

const NotificationCard = ({ notification, onDismiss, onMarkAsRead }) => {
  const cardVariants = {
    initial: { opacity: 0, x: -50 },
    animate: { opacity: 1, x: 0, transition: { type: 'spring', stiffness: 300, damping: 30 } },
    exit: { opacity: 0, x: 50, transition: { duration: 0.3 } }
  };

  return (
    <motion.div
      variants={cardVariants}
      initial="initial"
      animate="animate"
      exit="exit"
      layout
      className={`glass-effect p-5 rounded-xl border flex items-start space-x-4 mb-4 transition-all duration-300 ${
        notification.read ? 'border-gray-700/50 opacity-70 hover:opacity-100' : 'border-purple-500/50 hover:shadow-purple-500/20 hover:shadow-lg'
      }`}
    >
      <div className="flex-shrink-0 w-10 h-10 bg-gray-800/60 rounded-full flex items-center justify-center border border-purple-500/30">
        {notification.icon}
      </div>
      <div className="flex-grow">
        <div className="flex justify-between items-center">
          <h3 className={`font-semibold ${notification.read ? 'text-gray-300' : 'text-white'}`}>{notification.title}</h3>
          <span className="text-xs text-gray-500">{notification.time}</span>
        </div>
        <p className={`text-sm mt-1 ${notification.read ? 'text-gray-400' : 'text-gray-300'}`}>{notification.description}</p>
        {!notification.read && (
          <Button 
            variant="link" 
            size="sm" 
            className="mt-2 px-0 text-purple-300 hover:text-purple-200"
            onClick={() => onMarkAsRead(notification.id)}
          >
            Mark as Read
          </Button>
        )}
      </div>
      <Button variant="ghost" size="icon" className="text-gray-500 hover:text-red-400 h-8 w-8" onClick={() => onDismiss(notification.id)}>
        <X size={18} />
      </Button>
    </motion.div>
  );
};

const NotificationsPage = () => {
  const [notifications, setNotifications] = React.useState(notificationsData);

  const handleDismiss = (id) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
    toast({ title: "Notification Dismissed" });
  };

  const handleMarkAsRead = (id) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };
  
  const handleMarkAllAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    toast({ title: "All notifications marked as read." });
  };

  const handleClearAll = () => {
    setNotifications([]);
    toast({ title: "All notifications cleared." });
  };


  return (
    <div className="container mx-auto px-4 py-12 min-h-screen">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="mb-8"
      >
        <div className="flex flex-col sm:flex-row justify-between items-center mb-6">
          <h1 className="text-4xl font-black gradient-text mb-4 sm:mb-0">Notifications</h1>
          <div className="flex space-x-3">
            <Button variant="outline" onClick={handleMarkAllAsRead} className="border-purple-500/60 text-purple-300 hover:bg-purple-500/10">Mark All Read</Button>
            <Button variant="destructive" onClick={handleClearAll} className="bg-red-600/80 hover:bg-red-600">Clear All</Button>
          </div>
        </div>
        <p className="text-lg text-gray-400">Stay updated with your latest activities and alerts.</p>
      </motion.div>

      {notifications.length > 0 ? (
        <motion.div layout className="space-y-4">
          {notifications.map(notification => (
            <NotificationCard 
              key={notification.id} 
              notification={notification}
              onDismiss={handleDismiss}
              onMarkAsRead={handleMarkAsRead}
            />
          ))}
        </motion.div>
      ) : (
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center py-16 glass-effect rounded-xl border border-dashed border-gray-700"
        >
          <Bell size={48} className="mx-auto text-gray-600 mb-4" />
          <h2 className="text-2xl font-semibold text-gray-400">No New Notifications</h2>
          <p className="text-gray-500">You're all caught up!</p>
        </motion.div>
      )}
    </div>
  );
};

export default NotificationsPage;
