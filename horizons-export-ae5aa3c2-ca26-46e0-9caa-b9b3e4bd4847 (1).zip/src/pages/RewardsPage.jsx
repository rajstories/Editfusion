import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { Award, CalendarDays, CheckCircle, Coins, Gift, Zap } from 'lucide-react';

const dailyRewards = [
  { day: 1, coins: 1, milestone: false }, { day: 2, coins: 2, milestone: false }, { day: 3, coins: 4, milestone: false }, { day: 4, coins: 8, milestone: false }, { day: 5, coins: 16, milestone: true, badge: "5-Day Streak!" },
  { day: 6, coins: 32, milestone: false }, { day: 7, coins: 64, milestone: false }, { day: 8, coins: 128, milestone: false }, { day: 9, coins: 150, milestone: false }, { day: 10, coins: 180, milestone: true, badge: "10-Day Power!" },
  { day: 11, coins: 190, milestone: false }, { day: 12, coins: 200, milestone: false }, { day: 13, coins: 210, milestone: false }, { day: 14, coins: 220, milestone: false }, { day: 15, coins: 200, milestone: true, badge: "15-Day Epic!" },
  { day: 16, coins: 250, milestone: false }, { day: 17, coins: 300, milestone: false }, { day: 18, coins: 350, milestone: false }, { day: 19, coins: 400, milestone: false }, { day: 20, coins: 450, milestone: true, badge: "20-Day Legend!" },
  { day: 21, coins: 500, milestone: false }, { day: 22, coins: 550, milestone: false }, { day: 23, coins: 600, milestone: false }, { day: 24, coins: 650, milestone: false }, { day: 25, coins: 700, milestone: true, badge: "25-Day Master!" },
  { day: 26, coins: 750, milestone: false }, { day: 27, coins: 800, milestone: false }, { day: 28, coins: 850, milestone: false }, { day: 29, coins: 900, milestone: false }, { day: 30, coins: 1000, milestone: true, badge: "30-Day GOAT!" },
];

const RewardsPage = () => {
  const [currentStreak, setCurrentStreak] = useState(0);
  const [totalCoins, setTotalCoins] = useState(0);
  const [lastClaimedDate, setLastClaimedDate] = useState(null);
  const [canClaim, setCanClaim] = useState(false);

  useEffect(() => {
    const storedStreak = parseInt(localStorage.getItem('editFusionStreak') || '0');
    const storedCoins = parseInt(localStorage.getItem('editFusionCoins') || '0');
    const storedLastClaimed = localStorage.getItem('editFusionLastClaimed');
    
    setCurrentStreak(storedStreak);
    setTotalCoins(storedCoins);
    if (storedLastClaimed) {
      setLastClaimedDate(new Date(storedLastClaimed));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('editFusionStreak', currentStreak.toString());
    localStorage.setItem('editFusionCoins', totalCoins.toString());
    if (lastClaimedDate) {
      localStorage.setItem('editFusionLastClaimed', lastClaimedDate.toISOString());
    }
  }, [currentStreak, totalCoins, lastClaimedDate]);

  useEffect(() => {
    const today = new Date();
    if (!lastClaimedDate || lastClaimedDate.toDateString() !== today.toDateString()) {
      setCanClaim(true);
    } else {
      setCanClaim(false);
    }
  }, [lastClaimedDate]);

  const handleClaimReward = () => {
    if (!canClaim) {
      toast({ title: "Already Claimed!", description: "You've already claimed your reward for today. Come back tomorrow!", variant: "destructive" });
      return;
    }

    const today = new Date();
    let newStreak = currentStreak;

    if (lastClaimedDate) {
      const diffTime = Math.abs(today - lastClaimedDate);
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      if (diffDays === 1) {
        newStreak += 1;
      } else if (diffDays > 1) {
        newStreak = 1; // Reset streak if missed a day
      }
    } else {
      newStreak = 1; // First claim
    }
    
    if (newStreak > 30) newStreak = 1; // Reset after 30 days cycle

    const rewardInfo = dailyRewards.find(r => r.day === newStreak) || dailyRewards[0];
    
    setCurrentStreak(newStreak);
    setTotalCoins(prevCoins => prevCoins + rewardInfo.coins);
    setLastClaimedDate(today);
    setCanClaim(false);

    toast({ 
      title: `🎉 Day ${newStreak} Reward Claimed!`, 
      description: `You earned ${rewardInfo.coins} coins! Total: ${totalCoins + rewardInfo.coins} coins. ${rewardInfo.milestone ? `Badge Unlocked: ${rewardInfo.badge}` : ''}`
    });
  };

  const progressPercentage = (currentStreak / 30) * 100;

  return (
    <div className="container mx-auto px-4 py-16 min-h-screen">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-center mb-12"
      >
        <h1 className="text-5xl md:text-7xl font-black mb-4">
          <span className="gradient-text">Daily Rewards</span>
        </h1>
        <p className="text-xl text-gray-300 max-w-2xl mx-auto">
          Log in daily to build your streak and earn coins! Unlock milestone badges and exclusive perks.
        </p>
      </motion.div>

      <motion.div 
        className="glass-effect rounded-3xl p-8 md:p-12 max-w-3xl mx-auto mb-12 section-reveal"
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <div className="flex flex-col md:flex-row justify-between items-center mb-8">
          <div className="text-center md:text-left mb-4 md:mb-0">
            <p className="text-2xl font-semibold text-purple-400">Current Streak</p>
            <p className="text-6xl font-bold">{currentStreak} <span className="text-2xl">Days</span></p>
          </div>
          <div className="text-center md:text-right">
            <p className="text-2xl font-semibold text-blue-400">Total Coins</p>
            <p className="text-6xl font-bold flex items-center justify-center md:justify-end">
              <Coins className="w-12 h-12 mr-2 text-yellow-400" /> {totalCoins}
            </p>
          </div>
        </div>

        <div className="mb-8">
          <div className="flex justify-between text-sm text-gray-400 mb-1">
            <span>Day 1</span>
            <span>Day 30</span>
          </div>
          <div className="w-full bg-gray-700 rounded-full h-6">
            <motion.div
              className="bg-gradient-to-r from-purple-600 to-blue-600 h-6 rounded-full flex items-center justify-center text-xs font-medium text-white"
              initial={{ width: 0 }}
              animate={{ width: `${progressPercentage}%` }}
              transition={{ duration: 1, ease: "easeInOut" }}
            >
              {currentStreak > 0 && `${currentStreak}/30 Days`}
            </motion.div>
          </div>
        </div>
        
        <Button
          size="lg"
          className={`w-full magnetic-hover text-white py-4 text-lg font-semibold glow-effect ${
            canClaim ? 'bg-gradient-to-r from-green-500 to-teal-500 hover:from-green-600 hover:to-teal-600' : 'bg-gray-600 cursor-not-allowed'
          }`}
          onClick={handleClaimReward}
          disabled={!canClaim}
        >
          {canClaim ? (
            <> <CalendarDays className="mr-2 h-6 w-6" /> Claim Today's Reward </>
          ) : (
            <> <CheckCircle className="mr-2 h-6 w-6" /> Claimed Today! Come Back Tomorrow </>
          )}
        </Button>
        {currentStreak > 0 && dailyRewards.find(r => r.day === currentStreak)?.milestone && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.5, type: "spring", stiffness: 300 }}
            className="mt-6 text-center p-4 bg-yellow-500/20 border border-yellow-500 rounded-lg text-yellow-300 font-semibold flex items-center justify-center"
          >
            <Award className="w-6 h-6 mr-2"/> {dailyRewards.find(r => r.day === currentStreak)?.badge} Unlocked!
          </motion.div>
        )}
      </motion.div>

      <motion.div 
        className="section-reveal"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4 }}
      >
        <h2 className="text-3xl font-bold text-center mb-8 gradient-text">Upcoming Rewards</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {dailyRewards.map((reward) => (
            <motion.div
              key={reward.day}
              className={`p-4 rounded-xl text-center transition-all duration-300
                ${reward.day === currentStreak + 1 && canClaim ? 'glass-effect border-2 border-purple-500 scale-105 shadow-lg' : 'bg-gray-800/50 border border-gray-700'}
                ${reward.day <= currentStreak && !canClaim ? 'opacity-50 bg-green-500/20 border-green-500' : ''}
              `}
              whileHover={reward.day > currentStreak || (reward.day === currentStreak + 1 && canClaim) ? { scale: 1.05, y: -5 } : {}}
            >
              <p className={`text-sm font-semibold ${reward.day <= currentStreak && !canClaim ? 'text-green-300' : 'text-gray-400'}`}>Day {reward.day}</p>
              <Coins className={`w-8 h-8 mx-auto my-2 ${reward.milestone ? 'text-yellow-400' : 'text-purple-400'}`} />
              <p className={`font-bold text-lg ${reward.milestone ? 'text-yellow-300' : 'text-white'}`}>{reward.coins} Coins</p>
              {reward.milestone && <p className="text-xs text-yellow-400 mt-1 flex items-center justify-center"><Zap className="w-3 h-3 mr-1"/>{reward.badge}</p>}
               {reward.day <= currentStreak && !canClaim && <CheckCircle className="w-5 h-5 mx-auto text-green-400 mt-1" />}
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
};

export default RewardsPage;