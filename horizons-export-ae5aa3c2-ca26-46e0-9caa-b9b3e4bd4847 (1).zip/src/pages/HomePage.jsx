import React from 'react';
import HeroSection from '@/components/sections/HeroSection';
import AboutSection from '@/components/sections/AboutSection';
import ConnectSection from '@/components/sections/ConnectSection';
import CreateSection from '@/components/sections/CreateSection';
import CollaborateSection from '@/components/sections/CollaborateSection';
import WhyEditFusionSection from '@/components/sections/WhyEditFusionSection';
import SplitSection from '@/components/sections/SplitSection';
import BottomCtaSection from '@/components/sections/BottomCtaSection';
import WaitlistSection from '@/components/sections/WaitlistSection';

const HomePage = ({ 
  onOpenConnectModal, 
  onOpenCreateModal, 
  onOpenCollaborateModal,
  onOpenCreatorApplyModal,
  onOpenEditorApplyModal,
  openAuthModal,
  whyModalSetters
}) => {
  return (
    <>
      <HeroSection />
      <AboutSection />
      <ConnectSection onOpenModal={onOpenConnectModal} />
      <CreateSection onOpenModal={onOpenCreateModal} />
      <CollaborateSection onOpenModal={onOpenCollaborateModal} />
      <WhyEditFusionSection whyModalSetters={whyModalSetters} />
      <SplitSection 
        onOpenCreatorApplyModal={onOpenCreatorApplyModal}
        onOpenEditorApplyModal={onOpenEditorApplyModal}
      />
      <BottomCtaSection openAuthModal={openAuthModal} />
      <WaitlistSection />
    </>
  );
};

export default HomePage;