
import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea.jsx'; 
import { Progress } from '@/components/ui/progress.jsx'; 
import { toast } from '@/components/ui/use-toast';
import { Eye, MessageSquare, CheckCircle, Clock, Download, Send } from 'lucide-react';


// Mock task data fetching function (replace with actual API call or localStorage)
const getTaskById = (taskId) => {
  const mockTasks = [
    { id: 'task001', title: 'VFX for "Cosmic Journey" Trailer', progress: 75, status: 'In Review', client: 'Galaxy Films', editor: 'Alice W.', deadline: '2025-07-15', description: 'Create stunning visual effects for the upcoming sci-fi movie trailer. Focus on ship battles and planetary explosions. Ensure final delivery in 4K ProRes.', deliverables: [{ name: 'trailer_vfx_v3.mp4', url: '#', size: '1.2GB', type: 'video' }], feedback: [{user: 'Client (Galaxy Films)', text: 'Looks great! Just one minor tweak on the ship explosion.'}, {user: 'Editor (Alice W.)', text: 'Noted! Will update by EOD.'}] },
    { id: 'task002', title: 'Color Grade "Sunset Romance" Short Film', progress: 40, status: 'Pending', client: 'Indie Shorts Co.', editor: 'Bob B.', deadline: '2025-07-22', description: 'Apply a warm, romantic color grade to the 15-minute short film. Mood board and reference shots provided.', deliverables: [], feedback: [] },
  ];
  return mockTasks.find(task => task.id === taskId);
};

const TaskViewPage = () => {
  const { taskId } = useParams();
  const [task, setTask] = useState(null);
  const [newComment, setNewComment] = useState('');

  useEffect(() => {
    // Simulate fetching task data
    const fetchedTask = getTaskById(taskId);
    if (fetchedTask) {
      setTask(fetchedTask);
    } else {
      toast({ title: "Task Not Found", description: `Could not find task with ID: ${taskId}`, variant: "destructive" });
    }
  }, [taskId]);

  const handleAddComment = () => {
    if (!newComment.trim()) return;
    // In a real app, send this comment to the backend
    const comment = { user: 'Client (You)', text: newComment }; // Assuming client is viewing
    setTask(prevTask => ({
      ...prevTask,
      feedback: [...(prevTask.feedback || []), comment]
    }));
    setNewComment('');
    toast({ title: "Comment Added", description: "Your feedback has been submitted." });
  };

  if (!task) {
    return (
      <div className="container mx-auto px-4 py-12 min-h-screen flex flex-col items-center justify-center">
        <Eye size={64} className="text-purple-500/50 mb-6" />
        <h1 className="text-3xl font-bold text-gray-300 mb-4">Loading Task Details...</h1>
        <p className="text-gray-500">If the task doesn't load, it might not exist or the link is incorrect.</p>
        <Link to="/"><Button variant="link" className="mt-4 text-purple-400">Go to Homepage</Button></Link>
      </div>
    );
  }
  
  const getStatusColorChip = (status) => {
    if (status === 'Done') return 'bg-green-500/20 text-green-300 border-green-500/50';
    if (status === 'In Review') return 'bg-yellow-500/20 text-yellow-300 border-yellow-500/50';
    if (status === 'Pending') return 'bg-blue-500/20 text-blue-300 border-blue-500/50';
    return 'bg-gray-500/20 text-gray-300 border-gray-500/50';
  };


  return (
    <div className="container mx-auto px-4 py-12 min-h-screen">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-4xl mx-auto"
      >
        <div className="glass-effect rounded-2xl p-8 mb-8 border border-purple-500/20 shadow-xl">
          <div className="flex flex-col sm:flex-row justify-between items-start mb-4">
            <div>
              <h1 className="text-4xl font-black gradient-text mb-1">{task.title}</h1>
              <p className="text-sm text-gray-500 mb-2">Task ID: {task.id} | For: {task.client}</p>
            </div>
            <div className={`px-4 py-2 rounded-full text-sm font-semibold self-start mt-2 sm:mt-0 ${getStatusColorChip(task.status)}`}>
              {task.status}
            </div>
          </div>
          
          <div className="mb-6">
            <p className="text-gray-300 leading-relaxed">{task.description || "No description provided for this task."}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <InfoItem icon={<CheckCircle size={18} className="text-purple-400"/>} label="Assigned Editor" value={task.editor} />
            <InfoItem icon={<Clock size={18} className="text-purple-400"/>} label="Deadline" value={task.deadline} />
          </div>
          
          <div className="mb-6">
            <label className="text-lg font-semibold text-purple-300 block mb-2">Progress: {task.progress}%</label>
            <Progress value={task.progress} className="h-3"/>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="glass-effect rounded-2xl p-6 border border-blue-500/20"
          >
            <h2 className="text-2xl font-bold text-blue-300 mb-4">Deliverables</h2>
            {task.deliverables && task.deliverables.length > 0 ? (
              <ul className="space-y-3">
                {task.deliverables.map((file, index) => (
                  <li key={index} className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg border border-gray-700/50">
                    <div>
                      <p className="text-white font-medium">{file.name}</p>
                      <p className="text-xs text-gray-400">{file.size || 'N/A'} - {file.type || 'File'}</p>
                    </div>
                    <Button variant="ghost" size="icon" className="text-blue-300 hover:text-blue-200" onClick={() => toast({title: `Download ${file.name}`, description:"Download feature coming soon!"})}>
                      <Download size={20} />
                    </Button>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-gray-400">No deliverables uploaded yet.</p>
            )}
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="glass-effect rounded-2xl p-6 border border-green-500/20"
          >
            <h2 className="text-2xl font-bold text-green-300 mb-4">Feedback & Comments</h2>
            <div className="space-y-4 max-h-60 overflow-y-auto mb-4 pr-2 scrollbar-thin">
              {task.feedback && task.feedback.length > 0 ? (
                task.feedback.map((fb, index) => (
                  <div key={index} className="p-3 bg-gray-800/50 rounded-lg border border-gray-700/50">
                    <p className="text-sm font-semibold text-purple-300">{fb.user}</p>
                    <p className="text-sm text-gray-200 whitespace-pre-line">{fb.text}</p>
                  </div>
                ))
              ) : (
                <p className="text-gray-400">No feedback or comments yet.</p>
              )}
            </div>
            <div className="mt-auto">
              <Textarea
                placeholder="Add your comment or feedback here..."
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                className="bg-black/30 border-green-500/30 input-glow text-sm mb-2"
                rows="3"
              />
              <Button onClick={handleAddComment} className="w-full bg-gradient-to-r from-green-500 to-teal-500 text-white glow-effect">
                <Send size={16} className="mr-2"/> Submit Feedback
              </Button>
            </div>
          </motion.div>
        </div>
         <div className="mt-12 text-center">
            <Link to="/"><Button variant="outline" className="loom-cta-button">Back to Homepage</Button></Link>
         </div>
      </motion.div>
    </div>
  );
};

const InfoItem = ({ icon, label, value }) => (
  <div className="flex items-center space-x-3 p-3 bg-gray-800/40 rounded-lg border border-gray-700/40">
    {icon}
    <div>
      <p className="text-xs text-gray-400">{label}</p>
      <p className="text-md font-semibold text-white">{value}</p>
    </div>
  </div>
);

export default TaskViewPage;
