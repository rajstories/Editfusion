
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea.jsx'; 
import { toast } from '@/components/ui/use-toast';
import { Users, Send, Gift, FileText, Clock, CheckCircle, Search, Mail, UserPlus, Link as LinkIcon } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link } from 'react-router-dom';


const initialSentReferrals = [
  { id: 'refS001', referredName: 'John Creative', referredEmail: 'john@example.com', status: 'Pending', date: '2025-06-15', message: 'Hey John, check out EditFusion!' },
  { id: 'refS002', referredName: 'Sarah Editor', referredEmail: 'sarah@example.com', status: 'Joined', date: '2025-06-10', reward: '2000 Coins + 2% Comm.' },
];

const initialReceivedRequests = [
  { id: 'refR001', requesterName: 'Visionary Studios', requesterEmail: 'ceo@visionary.com', requestMessage: 'Heard great things about your work. Could you refer a skilled motion graphics artist?', date: '2025-06-18', status: 'New' },
];

const ReferralsPage = ({user, openAuthModal}) => {
  const [activeTab, setActiveTab] = useState('myReferrals'); 
  const [sentReferrals, setSentReferrals] = useState(initialSentReferrals);
  const [receivedRequests, setReceivedRequests] = useState(initialReceivedRequests);

  
  const [referralTargetName, setReferralTargetName] = useState('');
  const [referralTargetEmail, setReferralTargetEmail] = useState('');
  const [referralMessage, setReferralMessage] = useState('');
  const [attachedDoc, setAttachedDoc] = useState(null);

  
  const [clientToRequest, setClientToRequest] = useState('');
  const [requestNote, setRequestNote] = useState('');
  
  const handleFeatureRequest = (feature) => {
     toast({ title: "🚧 Feature Coming Soon!", description: `${feature} functionality is under development.` });
  };

  const handleCopyReferralLink = () => {
    if (!user) {
        toast({ title: "Login Required", description: "Please login to get your referral link.", variant:"destructive" });
        openAuthModal('login');
        return;
    }
    const referralLink = `${window.location.origin}/refer-earn?ref=${user.id}`; 
    navigator.clipboard.writeText(referralLink);
    toast({ title: "🔗 Link Copied!", description: "Your personal referral link is copied." });
  };

  const handleSubmitReferralRequest = (e) => { 
    e.preventDefault();
    if (!referralTargetName || !referralTargetEmail) {
        toast({ title: "Missing Info", description: "Please provide name and email of person you're referring.", variant:"destructive"});
        return;
    }
    
    toast({ title: "💌 Referral Submitted!", description: `Thank you for referring ${referralTargetName}. This is a demo.` });
    setReferralTargetName('');
    setReferralTargetEmail('');
    setReferralMessage('');
    setAttachedDoc(null);
  };
  
  const handleEditorRequestReferral = (e) => { 
    e.preventDefault();
    if (!clientToRequest) {
        toast({ title: "Client Not Specified", description: "Please specify which client you'd like a referral from.", variant:"destructive"});
        return;
    }
    toast({ title: "📬 Request Sent!", description: `Your referral request to ${clientToRequest} has been noted (Demo).` });
    setClientToRequest('');
    setRequestNote('');
  };

  return (
    <div className="container mx-auto px-4 py-12 min-h-screen">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-12"
      >
        <h1 className="text-5xl font-black gradient-text mb-4">Manage Your Referrals</h1>
        <p className="text-xl text-gray-300 max-w-2xl mx-auto">
          Track your referred friends, request testimonials from clients, and see your referral earnings grow.
        </p>
         <Button onClick={handleCopyReferralLink} size="lg" className="mt-6 bg-gradient-to-r from-primary to-secondary text-white glow-effect">
            <LinkIcon size={18} className="mr-2"/> Get Your Referral Link
        </Button>
      </motion.div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2 md:grid-cols-3 gap-2 bg-black/20 p-2 rounded-lg h-auto mb-8">
          <TabsTrigger value="myReferrals" className="py-3 data-[state=active]:bg-purple-600 data-[state=active]:text-white data-[state=active]:shadow-lg">My Sent Referrals</TabsTrigger>
          <TabsTrigger value="requestReferrals" className="py-3 data-[state=active]:bg-blue-600 data-[state=active]:text-white data-[state=active]:shadow-lg">Request a Referral</TabsTrigger>
          <TabsTrigger value="history" className="py-3 data-[state=active]:bg-green-600 data-[state=active]:text-white data-[state=active]:shadow-lg col-span-2 md:col-span-1">Referral History</TabsTrigger>
        </TabsList>

        <TabsContent value="myReferrals">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="glass-effect p-6 rounded-xl border border-purple-500/20">
                <h2 className="text-2xl font-bold text-purple-300 mb-6">Track Your Sent Referrals</h2>
                {sentReferrals.length > 0 ? (
                    sentReferrals.map(ref => (
                        <div key={ref.id} className="mb-4 p-4 bg-gray-800/50 rounded-lg border border-gray-700/50">
                            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
                               <div>
                                  <p className="font-semibold text-white text-lg">{ref.referredName} <span className="text-sm text-gray-400">({ref.referredEmail})</span></p>
                                  <p className="text-xs text-gray-500">Sent: {ref.date}</p>
                               </div>
                               <span className={`px-3 py-1 mt-2 sm:mt-0 rounded-full text-xs font-semibold ${ref.status === 'Joined' ? 'bg-green-500/20 text-green-300' : 'bg-yellow-500/20 text-yellow-300'}`}>
                                  {ref.status}
                               </span>
                            </div>
                            {ref.message && <p className="text-sm text-gray-300 mt-2 italic">"{ref.message}"</p>}
                            {ref.status === 'Joined' && ref.reward && <p className="text-sm text-green-400 mt-1 font-semibold">Reward: {ref.reward}</p>}
                        </div>
                    ))
                ) : <p className="text-gray-400">You haven't sent any referrals yet. <Link to="/refer-earn" className="text-purple-400 hover:underline">Start referring now!</Link></p>}
            </motion.div>
        </TabsContent>

        <TabsContent value="requestReferrals">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="grid md:grid-cols-2 gap-8">
                <div className="glass-effect p-6 rounded-xl border border-blue-500/20">
                    <h2 className="text-2xl font-bold text-blue-300 mb-2">Editors: Request a Referral from a Client</h2>
                    <p className="text-sm text-gray-400 mb-4">Ask past clients to recommend you to their network.</p>
                    <form onSubmit={handleEditorRequestReferral} className="space-y-4">
                        <div>
                            <label htmlFor="clientName" className="block text-sm font-medium text-gray-300 mb-1">Client's Name or Company</label>
                            <Input type="text" id="clientName" placeholder="E.g., Visionary Studios" value={clientToRequest} onChange={(e) => setClientToRequest(e.target.value)} required className="input-glow bg-black/30 border-blue-500/30"/>
                        </div>
                        <div>
                            <label htmlFor="requestNote" className="block text-sm font-medium text-gray-300 mb-1">Personalized Note (Optional)</label>
                            <Textarea id="requestNote" placeholder="E.g., Hope you were happy with the project! A referral would be amazing..." value={requestNote} onChange={(e) => setRequestNote(e.target.value)} className="input-glow bg-black/30 border-blue-500/30"/>
                        </div>
                        <Button type="submit" className="w-full bg-gradient-to-r from-blue-600 to-cyan-600 text-white glow-effect">
                            <Send size={16} className="mr-2"/> Send Referral Request
                        </Button>
                    </form>
                </div>

                <div className="glass-effect p-6 rounded-xl border border-green-500/20">
                    <h2 className="text-2xl font-bold text-green-300 mb-2">Clients: Submit a Referral for an Editor</h2>
                    <p className="text-sm text-gray-400 mb-4">Recommend a talented editor to someone in your network.</p>
                     <form onSubmit={handleSubmitReferralRequest} className="space-y-4">
                        <div>
                            <label htmlFor="refTargetName" className="block text-sm font-medium text-gray-300 mb-1">Person/Brand You're Referring To</label>
                            <Input type="text" id="refTargetName" placeholder="Contact's Full Name" value={referralTargetName} onChange={e => setReferralTargetName(e.target.value)} required className="input-glow bg-black/30 border-green-500/30"/>
                        </div>
                        <div>
                            <label htmlFor="refTargetEmail" className="block text-sm font-medium text-gray-300 mb-1">Their Email Address</label>
                            <Input type="email" id="refTargetEmail" placeholder="contact@email.com" value={referralTargetEmail} onChange={e => setReferralTargetEmail(e.target.value)} required className="input-glow bg-black/30 border-green-500/30"/>
                        </div>
                        <div>
                            <label htmlFor="refMessage" className="block text-sm font-medium text-gray-300 mb-1">Short Recommendation Message</label>
                            <Textarea id="refMessage" placeholder="E.g., Highly recommend this editor for your project..." value={referralMessage} onChange={e => setReferralMessage(e.target.value)} required className="input-glow bg-black/30 border-green-500/30"/>
                        </div>
                         <div>
                            <label htmlFor="refDoc" className="block text-sm font-medium text-gray-300 mb-1">Attach Recommendation (Optional)</label>
                            <Input type="file" id="refDoc" onChange={e => setAttachedDoc(e.target.files[0])} className="input-glow bg-black/30 border-green-500/30 file:text-sm file:font-medium file:bg-green-600/20 file:text-green-300 file:border-0 file:rounded-md file:py-1.5 file:px-3 file:mr-3 hover:file:bg-green-600/30 cursor-pointer"/>
                            {attachedDoc && <p className="text-xs text-green-400 mt-1">Selected: {attachedDoc.name}</p>}
                        </div>
                        <Button type="submit" className="w-full bg-gradient-to-r from-green-500 to-teal-500 text-white glow-effect">
                            <UserPlus size={16} className="mr-2"/> Submit This Referral
                        </Button>
                    </form>
                </div>
            </motion.div>
        </TabsContent>

        <TabsContent value="history">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="glass-effect p-6 rounded-xl border border-green-500/20">
                <h2 className="text-2xl font-bold text-green-300 mb-6">Referral History & Received Requests</h2>
                 <div className="mb-6">
                    <h3 className="text-xl font-semibold text-gray-200 mb-3">Referral Requests Received (From Clients)</h3>
                    {receivedRequests.length > 0 ? (
                        receivedRequests.map(req => (
                            <div key={req.id} className="mb-3 p-3 bg-gray-800/50 rounded-lg border border-gray-700/50">
                                <p className="font-semibold text-white">{req.requesterName} <span className="text-xs text-gray-400">({req.requesterEmail})</span></p>
                                <p className="text-sm text-gray-300 italic my-1">"{req.requestMessage}"</p>
                                <p className="text-xs text-gray-500">Received: {req.date}</p>
                                <Button size="sm" className="mt-2 bg-blue-600 hover:bg-blue-700 text-xs" onClick={() => handleFeatureRequest(`Responding to ${req.requesterName}`)}>Respond to Request</Button>
                            </div>
                        ))
                    ) : <p className="text-gray-400">No pending referral requests from clients.</p>}
                </div>
                <p className="text-gray-400">A more detailed history of all referral activities, including earnings and statuses, will be available here soon.</p>
                <Button variant="outline" className="mt-4 border-green-500/50 text-green-300 hover:bg-green-500/10" onClick={() => handleFeatureRequest('Full Referral History')}>
                    <Clock size={16} className="mr-2"/> View Full History
                </Button>
            </motion.div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ReferralsPage;
