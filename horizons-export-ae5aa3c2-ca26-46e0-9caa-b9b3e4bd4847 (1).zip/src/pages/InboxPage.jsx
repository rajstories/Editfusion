import React, { useState, useEffect, useRef } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Search, Send, Paperclip, Smile, Check, CheckCheck, UserPlus, ArrowLeft, MessageSquare, Lock } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

// Placeholder data
const initialContacts = [
  { id: '1', name: 'Alice Wonderland', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=50&h=50&fit=crop', lastMessage: 'Hey, how is the project going?', unread: 2, lastMessageTime: '10:30 AM', isTyping: false },
  { id: '2', name: 'Bob The Builder', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=50&h=50&fit=crop', lastMessage: 'Sure, I can do that by tomorrow.', unread: 0, lastMessageTime: 'Yesterday', isTyping: true },
  { id: '3', name: 'Carol Danvers', avatar: 'https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=50&h=50&fit=crop', lastMessage: 'Thanks for the update!', unread: 0, lastMessageTime: 'Mon', isTyping: false },
];

const initialMessages = {
  '1': [
    { id: 'm1', text: 'Hey Alice, checking in on the VFX sequence.', sender: 'me', time: '10:25 AM', status: 'seen' },
    { id: 'm2', text: 'Hey, how is the project going?', sender: 'Alice Wonderland', time: '10:30 AM', status: 'delivered' },
    { id: 'm3', text: 'It\'s going well! Should have a draft for you by EOD.', sender: 'me', time: '10:32 AM', status: 'sent' },
  ],
  '2': [
    { id: 'm4', text: 'Hi Bob, can you adjust the intro music?', sender: 'me', time: 'Yesterday', status: 'seen' },
    { id: 'm5', text: 'Sure, I can do that by tomorrow.', sender: 'Bob The Builder', time: 'Yesterday', status: 'delivered' },
  ],
   '3': [
    { id: 'm6', text: 'Project files uploaded.', sender: 'me', time: 'Mon', status: 'seen' },
    { id: 'm7', text: 'Thanks for the update!', sender: 'Carol Danvers', time: 'Mon', status: 'delivered' },
  ],
};

const ChatMessage = ({ message, isOwn }) => {
  const bubbleColor = isOwn ? 'bg-purple-600' : 'bg-gray-700/70';
  const alignment = isOwn ? 'ml-auto' : 'mr-auto';
  const slideDirection = isOwn ? { x: 20 } : { x: -20 };

  const StatusIcon = () => {
    if (!isOwn) return null;
    if (message.status === 'seen') return <CheckCheck size={16} className="text-blue-300 ml-1" />;
    if (message.status === 'delivered') return <CheckCheck size={16} className="text-gray-400 ml-1" />;
    if (message.status === 'sent') return <Check size={16} className="text-gray-400 ml-1" />;
    return null;
  };

  return (
    <motion.div
      className={`flex mb-3 ${isOwn ? 'justify-end' : 'justify-start'}`}
      initial={{ opacity: 0, ...slideDirection }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ type: 'spring', stiffness: 200, damping: 20, duration: 0.3 }}
    >
      <div className={`p-3 rounded-xl max-w-xs md:max-w-md ${bubbleColor} ${alignment}`}>
        <p className="text-sm text-white">{message.text}</p>
        <div className="text-xs text-gray-300/70 mt-1 flex items-center justify-end">
          {message.time} <StatusIcon />
        </div>
      </div>
    </motion.div>
  );
};

const InboxPage = ({ user, openProUpgradeModal }) => {
  const { chatId } = useParams();
  const navigate = useNavigate();
  const [contacts, setContacts] = useState(initialContacts);
  const [messages, setMessages] = useState(initialMessages);
  const [currentChat, setCurrentChat] = useState(null);
  const [newMessage, setNewMessage] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const messagesEndRef = useRef(null);

  const isPremium = user?.isPremium || false;

  useEffect(() => {
    if (chatId) {
      const contact = contacts.find(c => c.id === chatId);
      setCurrentChat(contact);
      setContacts(prev => prev.map(c => c.id === chatId ? {...c, unread: 0} : c));
    } else {
      setCurrentChat(null);
    }
  }, [chatId, contacts]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, currentChat]);

  const handleSendMessage = () => {
    if (!isPremium) {
      openProUpgradeModal();
      return;
    }
    if (!newMessage.trim() || !currentChat) return;

    const newMsg = {
      id: `m${Date.now()}`,
      text: newMessage,
      sender: 'me',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      status: 'sent',
    };
    setMessages(prev => ({ ...prev, [currentChat.id]: [...(prev[currentChat.id] || []), newMsg] }));
    setNewMessage('');

    setTimeout(() => {
        setMessages(prev => ({
            ...prev,
            [currentChat.id]: prev[currentChat.id].map(m => m.id === newMsg.id ? {...m, status: 'delivered'} : m)
        }));
    }, 1000);
     setTimeout(() => {
        setMessages(prev => ({
            ...prev,
            [currentChat.id]: prev[currentChat.id].map(m => m.id === newMsg.id ? {...m, status: 'seen'} : m)
        }));
    }, 2500);
  };

  const filteredContacts = contacts.filter(contact =>
    contact.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const TypingIndicator = () => (
    <motion.div 
      className="flex items-center space-x-1"
      initial={{ opacity: 0, y:5 }}
      animate={{ opacity:1, y:0 }}
      transition={{ duration: 0.3 }}
    >
      <span className="text-xs text-purple-300 italic">{currentChat?.name} is typing</span>
      <motion.div className="w-1.5 h-1.5 bg-purple-400 rounded-full" animate={{ scale: [1, 1.3, 1], opacity: [0.5,1,0.5] }} transition={{ duration: 0.8, repeat: Infinity, delay: 0 }} />
      <motion.div className="w-1.5 h-1.5 bg-purple-400 rounded-full" animate={{ scale: [1, 1.3, 1], opacity: [0.5,1,0.5] }} transition={{ duration: 0.8, repeat: Infinity, delay: 0.2 }} />
      <motion.div className="w-1.5 h-1.5 bg-purple-400 rounded-full" animate={{ scale: [1, 1.3, 1], opacity: [0.5,1,0.5] }} transition={{ duration: 0.8, repeat: Infinity, delay: 0.4 }} />
    </motion.div>
  );

  return (
    <div className="h-[calc(100vh-80px)] md:h-[calc(100vh-96px)] flex glass-effect border-t border-purple-500/20 overflow-hidden">
      <div className={`w-full md:w-1/3 lg:w-1/4 border-r border-purple-500/20 flex flex-col bg-black/20 transition-all duration-300 ${chatId && 'hidden md:flex'}`}>
        <div className="p-4 border-b border-purple-500/20">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
            <Input 
              type="text" 
              placeholder="Search contacts..." 
              className="pl-10 input-glow bg-black/30 border-purple-500/30"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <Button variant="outline" className="w-full mt-3 text-purple-300 border-purple-500/50 hover:bg-purple-500/10" onClick={() => toast({title: "🚧 Feature coming soon", description:"Finding new contacts will be available soon!"})}>
             <UserPlus size={16} className="mr-2"/> New Chat / Request
          </Button>
        </div>
        <div className="flex-grow overflow-y-auto scrollbar-thin">
          {filteredContacts.map(contact => (
            <Link key={contact.id} to={`/inbox/${contact.id}`}>
              <motion.div 
                className={`p-4 flex items-center space-x-3 hover:bg-purple-500/10 cursor-pointer border-b border-gray-700/30 ${currentChat?.id === contact.id ? 'bg-purple-500/20' : ''}`}
                whileHover={{ x: 2 }}
              >
                <Avatar>
                  <AvatarImage src={contact.avatar} alt={contact.name} />
                  <AvatarFallback>{contact.name.substring(0,1)}</AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-center">
                    <h4 className="font-semibold text-white truncate">{contact.name}</h4>
                    <span className="text-xs text-gray-400">{contact.lastMessageTime}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <p className="text-sm text-gray-400 truncate">{contact.isTyping ? <TypingIndicator/> : contact.lastMessage}</p>
                    {contact.unread > 0 && (
                      <span className="bg-purple-500 text-white text-xs w-5 h-5 flex items-center justify-center rounded-full">{contact.unread}</span>
                    )}
                  </div>
                </div>
              </motion.div>
            </Link>
          ))}
           {filteredContacts.length === 0 && (
            <p className="text-center text-gray-400 p-4">No contacts found.</p>
          )}
        </div>
      </div>

      <div className={`flex-1 flex flex-col bg-black/50 relative ${!chatId && 'hidden md:flex'}`}>
        {currentChat ? (
          <>
            <header className="p-4 border-b border-purple-500/20 flex items-center space-x-3 bg-black/30 sticky top-0 z-10">
               <Button variant="ghost" size="icon" className="md:hidden text-purple-300" onClick={() => navigate('/inbox')}>
                  <ArrowLeft size={20} />
               </Button>
              <Avatar>
                <AvatarImage src={currentChat.avatar} alt={currentChat.name} />
                <AvatarFallback>{currentChat.name.substring(0,1)}</AvatarFallback>
              </Avatar>
              <div>
                <h3 className="font-semibold text-white">{currentChat.name}</h3>
                <p className="text-xs text-green-400">Online</p>
              </div>
            </header>
            <AnimatePresence>
              <motion.div 
                className="flex-grow p-6 space-y-4 overflow-y-auto scrollbar-thin"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
              >
                {(messages[currentChat.id] || []).map(msg => (
                  <ChatMessage key={msg.id} message={msg} isOwn={msg.sender === 'me'} />
                ))}
                 {currentChat.isTyping && messages[currentChat.id]?.slice(-1)[0]?.sender !== 'me' && <TypingIndicator />}
                 <div ref={messagesEndRef} />
              </motion.div>
            </AnimatePresence>
            <footer className="p-4 border-t border-purple-500/20 bg-black/30 sticky bottom-0 z-10">
              {isPremium ? (
                <div className="flex items-center space-x-3">
                  <Button variant="ghost" size="icon" className="text-gray-400 hover:text-purple-300" onClick={() => toast({title:"🚧 Attachments coming soon!"})}>
                    <Paperclip size={20} />
                  </Button>
                  <Input
                    type="text"
                    placeholder="Type your message..."
                    className="flex-1 input-glow bg-gray-800/50 border-purple-500/30 text-white"
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  />
                  <Button variant="ghost" size="icon" className="text-gray-400 hover:text-purple-300" onClick={() => toast({title:"🚧 Emojis coming soon!"})}>
                    <Smile size={20} />
                  </Button>
                  <Button className="bg-purple-600 hover:bg-purple-700 text-white glow-effect" onClick={handleSendMessage}>
                    <Send size={18} />
                  </Button>
                </div>
              ) : (
                <div 
                  className="relative flex items-center space-x-3 p-3 rounded-lg bg-gray-800/50 border border-dashed border-purple-500/30 cursor-pointer hover:bg-gray-800/80 transition-all"
                  onClick={openProUpgradeModal}
                >
                  <Lock className="h-5 w-5 text-purple-400" />
                  <p className="text-gray-400 text-sm flex-1">Sending messages and attachments is a Pro feature.</p>
                  <Button size="sm" className="bg-purple-600 hover:bg-purple-700 text-white glow-effect">Upgrade to Pro</Button>
                </div>
              )}
            </footer>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-center p-8">
            <MessageSquare size={64} className="text-purple-500/50 mb-6" />
            <h2 className="text-2xl font-semibold text-gray-300 mb-2">Select a chat to start messaging</h2>
            <p className="text-gray-500">Or find new creators and editors to connect with.</p>
            <Button variant="link" className="mt-4 text-purple-400" onClick={() => navigate('/find-editors')}>
                Discover Connections
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default InboxPage;