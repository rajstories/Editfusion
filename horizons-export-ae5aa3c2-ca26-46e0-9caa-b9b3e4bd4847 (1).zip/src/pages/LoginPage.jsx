
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from '@/components/ui/use-toast';
import { LogIn, Mail, Key, Phone, MessageSquare } from 'lucide-react';
import { useAuthStore } from '@/store/authStore';

const LoginPage = () => {
    const navigate = useNavigate();
    const { login } = useAuthStore();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [phone, setPhone] = useState('');
    const [otp, setOtp] = useState('');
    const [loginMethod, setLoginMethod] = useState('email');
    const [otpSent, setOtpSent] = useState(false);

    const handleEmailLogin = (e) => {
        e.preventDefault();
        if (!email || !password) {
            toast({ title: "Error", description: "Please enter both email and password.", variant: "destructive" });
            return;
        }
        toast({ title: "Login Successful!", description: `Welcome back, ${email}!` });
        login({ email: email, name: email.split('@')[0] });
        navigate('/profile');
    };

    const handleSendOtp = (e) => {
        e.preventDefault();
        if (phone.length < 10) {
            toast({ title: "Error", description: "Please enter a valid phone number.", variant: "destructive" });
            return;
        }
        setOtpSent(true);
        toast({ title: "OTP Sent!", description: "An OTP has been sent to your phone (use 123456)." });
    };
    
    const handlePhoneLogin = (e) => {
        e.preventDefault();
        if (otp !== '123456') {
            toast({ title: "Error", description: "Invalid OTP.", variant: "destructive" });
            return;
        }
        toast({ title: "Login Successful!", description: "Welcome back!" });
        login({ email: `${phone}@phone.local`, name: 'Phone User' });
        navigate('/profile');
    };
    
    const handleGoogleLogin = () => {
        toast({ title: "Signing in with Google...", description: "You will be redirected shortly (demo)." });
        setTimeout(() => {
            login({ email: 'google.user@gmail.com', name: 'Google User' });
            navigate('/profile');
        }, 1500);
    };

    return (
        <div className="min-h-screen flex items-center justify-center bg-grid-purple-500/10 p-4">
            <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="w-full max-w-md glass-effect p-8 rounded-2xl border border-purple-500/30 shadow-2xl shadow-purple-500/10"
            >
                <div className="text-center mb-8">
                    <h1 className="text-4xl font-black gradient-text">Welcome Back</h1>
                    <p className="text-gray-400 mt-2">Log in to continue your journey with EditFusion.</p>
                </div>

                <div className="grid grid-cols-2 gap-2 mb-6">
                    <Button variant={loginMethod === 'email' ? 'default' : 'outline'} onClick={() => setLoginMethod('email')}>Email</Button>
                    <Button variant={loginMethod === 'phone' ? 'default' : 'outline'} onClick={() => setLoginMethod('phone')}>Phone</Button>
                </div>

                {loginMethod === 'email' && (
                    <form onSubmit={handleEmailLogin} className="space-y-4">
                        <div>
                            <Label htmlFor="email">Email</Label>
                            <Input id="email" type="email" placeholder="you@example.com" value={email} onChange={(e) => setEmail(e.target.value)} className="bg-gray-900/50" />
                        </div>
                        <div>
                            <Label htmlFor="password">Password</Label>
                            <Input id="password" type="password" placeholder="••••••••" value={password} onChange={(e) => setPassword(e.target.value)} className="bg-gray-900/50" />
                        </div>
                        <Button type="submit" className="w-full glow-effect"><LogIn className="mr-2 h-4 w-4" /> Log In</Button>
                    </form>
                )}

                {loginMethod === 'phone' && !otpSent && (
                    <form onSubmit={handleSendOtp} className="space-y-4">
                        <div>
                            <Label htmlFor="phone">Phone Number</Label>
                            <Input id="phone" type="tel" placeholder="+1 (555) 123-4567" value={phone} onChange={(e) => setPhone(e.target.value)} className="bg-gray-900/50" />
                        </div>
                        <Button type="submit" className="w-full glow-effect"><Phone className="mr-2 h-4 w-4" /> Send OTP</Button>
                    </form>
                )}
                
                {loginMethod === 'phone' && otpSent && (
                    <form onSubmit={handlePhoneLogin} className="space-y-4">
                        <div>
                            <Label htmlFor="otp">6-Digit OTP</Label>
                            <Input id="otp" type="text" placeholder="123456" value={otp} onChange={(e) => setOtp(e.target.value)} className="bg-gray-900/50" />
                        </div>
                        <Button type="submit" className="w-full glow-effect"><MessageSquare className="mr-2 h-4 w-4" /> Verify & Log In</Button>
                    </form>
                )}
                
                <div className="relative my-6">
                    <div className="absolute inset-0 flex items-center"><span className="w-full border-t border-gray-700" /></div>
                    <div className="relative flex justify-center text-xs uppercase"><span className="bg-gray-900/50 px-2 text-gray-400">Or continue with</span></div>
                </div>

                <Button variant="outline" className="w-full" onClick={handleGoogleLogin}>
                    <svg className="mr-2 h-4 w-4" aria-hidden="true" focusable="false" data-prefix="fab" data-icon="google" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 488 512"><path fill="currentColor" d="M488 261.8C488 403.3 391.1 504 248 504 110.8 504 0 393.2 0 256S110.8 8 248 8c66.8 0 126 21.2 177.2 62.2l-61.2 61.2c-27.8-26.2-68.2-41.8-116-41.8-93 0-169.3 76.3-169.3 169.3s76.3 169.3 169.3 169.3c104.5 0 142.8-82.3 149.7-123.3H248.1v-78.3h236.1c2.3 12.7 3.9 26.9 3.9 41.4z"></path></svg>
                    Sign in with Google
                </Button>

                <p className="mt-8 text-center text-sm text-gray-400">
                    Don't have an account?{' '}
                    <Link to="/signup" className="font-semibold text-purple-400 hover:text-purple-300">
                        Sign up
                    </Link>
                </p>
            </motion.div>
        </div>
    );
};

export default LoginPage;
