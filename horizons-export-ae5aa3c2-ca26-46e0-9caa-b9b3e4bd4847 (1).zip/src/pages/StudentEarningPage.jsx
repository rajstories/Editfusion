import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { Coins, Zap, Brain, BookOpen, Award, Users, TrendingUp, PlayCircle, HelpCircle, Gift, Link as LinkIcon, Package, ClipboardList } from 'lucide-react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion.jsx" 
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Link } from 'react-router-dom';


const microTasks = [
  { id: 1, title: 'Write 10 Engaging Video Captions', category: 'Writing', reward: 50, icon: <Zap className="text-yellow-400"/>, difficulty: 'Easy', timeEst: '30 mins' },
  { id: 2, title: 'Breakdown a 5-min Reel into Key Scenes', category: 'Analysis', reward: 75, icon: <Brain className="text-purple-400"/>, difficulty: 'Medium', timeEst: '45 mins' },
  { id: 3, title: 'Source 5 Royalty-Free Stock Videos for Travel Niche', category: 'Research', reward: 100, icon: <PlayCircle className="text-blue-400"/>, difficulty: 'Medium', timeEst: '1 hour' },
  { id: 4, title: 'Transcribe 3-min Audio to Text', category: 'Transcription', reward: 60, icon: <Zap className="text-yellow-400"/>, difficulty: 'Easy', timeEst: '25 mins' },
  { id: 5, title: 'Identify 10 Trending Sounds on TikTok', category: 'Research', reward: 80, icon: <TrendingUp className="text-green-400"/>, difficulty: 'Medium', timeEst: '1 hour' },
];

const leaderboardData = [
  { rank: 1, name: 'Student Pro', earnings: 12500, avatarSeed: 'pro' },
  { rank: 2, name: 'Learner Ace', earnings: 9800, avatarSeed: 'ace' },
  { rank: 3, name: 'Caption King', earnings: 7500, avatarSeed: 'king' },
  { rank: 4, name: 'Reel Runner', earnings: 6200, avatarSeed: 'runner' },
  { rank: 5, name: 'Stock Star', earnings: 5100, avatarSeed: 'star' },
];

const faqData = [
    {
        question: "How do I get started?",
        answer: "Simply browse the available micro-tasks, pick one that interests you, and follow the instructions to complete it. Once verified, you'll earn coins!"
    },
    {
        question: "What are coins and how can I use them?",
        answer: "Coins are rewards you earn for completing tasks. You can redeem them for various perks, platform credits, or even real-world rewards (details coming soon!)."
    },
    {
        question: "Is there a limit to how many tasks I can do?",
        answer: "No, you can complete as many tasks as you like! The more tasks you complete, the more you earn and the higher you climb on the leaderboard."
    },
    {
        question: "How long does it take to get tasks verified?",
        answer: "Verification times can vary depending on the task complexity, but we aim to verify tasks within 24-48 hours."
    }
];

const earningOpportunities = [
    {
        icon: <Gift className="h-8 w-8 text-purple-400" />,
        title: "Referral Earnings",
        description: "Earn 2000 coins + 2% lifetime earnings from each referred editor.",
        cta: "Get Started",
        link: "/refer-earn"
    },
    {
        icon: <LinkIcon className="h-8 w-8 text-blue-400" />,
        title: "Affiliate Program",
        description: "Get affiliate links for editing tools or SaaS and earn up to 20% commission.",
        cta: "Get Started",
        link: "#",
        disabled: true
    },
    {
        icon: <Package className="h-8 w-8 text-cyan-400" />,
        title: "Dropshipping Panel",
        description: "Sell LUTs, transitions, presets & digital goods with 0 investment.",
        cta: "Get Started",
        link: "/dropshipping"
    },
    {
        icon: <ClipboardList className="h-8 w-8 text-green-400" />,
        title: "Micro Tasks for Students",
        description: "Earn coins for posting, sharing, inviting friends — exchange for services or payouts.",
        cta: "Get Started",
        link: "#micro-tasks"
    }
];

const StudentEarningPage = ({ openAuthModal }) => {
  const [selectedTask, setSelectedTask] = useState(null);

  const handleStartTask = (task) => {
    setSelectedTask(task);
    
    const user = JSON.parse(localStorage.getItem('editFusionUser'));
    if (!user) {
        toast({ title: "Login Required", description: "Please login or sign up to start earning.", variant:"destructive" });
        openAuthModal('signup'); 
        return;
    }
    if (user.role !== 'student') {
        toast({ title: "Student Account Required", description: "This zone is for student accounts. Please ensure your profile is set to 'student'.", variant:"destructive" });
        
        return;
    }
    toast({ title: `🚀 Task "${task.title}" Started!`, description: "Follow the instructions to complete and earn rewards." });
  };
  
  const getInitials = (name) => name.split(' ').map(n => n[0]).join('').toUpperCase();

  const handleOpportunityClick = (opportunity) => {
    if (opportunity.disabled) {
        toast({ title: "Coming Soon!", description: `${opportunity.title} is currently under development.` });
    } else if (opportunity.link.startsWith('#')) {
        document.querySelector(opportunity.link)?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="container mx-auto px-4 py-16 min-h-screen">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-16"
      >
        <h1 className="text-5xl md:text-7xl font-black mb-4">
          <span className="gradient-text">Earning Center</span>
        </h1>
        <p className="text-xl text-gray-300 max-w-3xl mx-auto">
          Complete micro-tasks, gain experience, and earn rewards. Level up your skills while contributing to real projects!
        </p>
      </motion.div>

      <section className="mb-20">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {earningOpportunities.map((opp, index) => (
                <motion.div
                    key={index}
                    className="glass-effect rounded-xl p-6 border border-purple-500/20 card-hover flex flex-col text-center"
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, amount: 0.3 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                    <div className="w-16 h-16 bg-gray-800/50 rounded-full flex items-center justify-center mx-auto mb-4 border border-purple-400/30">
                        {opp.icon}
                    </div>
                    <h3 className="text-xl font-bold text-white mb-2 flex-grow">{opp.title}</h3>
                    <p className="text-sm text-gray-400 mb-4 flex-grow">{opp.description}</p>
                    <Link to={opp.link} onClick={() => handleOpportunityClick(opp)}>
                        <Button className="w-full mt-auto bg-purple-600 hover:bg-purple-700" disabled={opp.disabled}>
                            {opp.cta}
                        </Button>
                    </Link>
                </motion.div>
            ))}
        </div>
      </section>
      
      <section className="mb-16" id="micro-tasks">
        <h2 className="text-3xl font-bold text-center mb-10 text-purple-300">Available Micro-Tasks</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {microTasks.map((task) => (
            <motion.div
              key={task.id}
              className="glass-effect rounded-xl p-6 border border-purple-500/20 card-hover flex flex-col justify-between"
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.4 }}
            >
              <div>
                <div className="flex items-center mb-3">
                  <span className="p-2 bg-gray-700/50 rounded-full mr-3 border border-purple-400/30">{task.icon}</span>
                  <h3 className="text-xl font-semibold text-white">{task.title}</h3>
                </div>
                <p className="text-sm text-gray-400 mb-1">Category: {task.category}</p>
                <p className="text-sm text-gray-400 mb-1">Difficulty: {task.difficulty} | Est. Time: {task.timeEst}</p>
                <div className="flex items-center text-yellow-400 font-bold text-lg my-3">
                  <Coins size={20} className="mr-2"/> {task.reward} Coins
                </div>
              </div>
              <Button 
                className="w-full mt-4 bg-purple-600 hover:bg-purple-700"
                onClick={() => handleStartTask(task)}
              >
                Start Task
              </Button>
            </motion.div>
          ))}
        </div>
      </section>

      
      <section className="mb-16">
        <h2 className="text-3xl font-bold text-center mb-10 text-blue-300">Weekly Earning Leaderboard</h2>
        <div className="max-w-2xl mx-auto glass-effect rounded-xl p-6 border border-blue-500/20">
          {leaderboardData.map((player, index) => (
            <motion.div
              key={player.rank}
              className={`flex items-center p-3 rounded-lg mb-2 transition-all duration-300 ${
                index === 0 ? 'bg-yellow-500/20 border-2 border-yellow-400 shadow-lg' : 
                index === 1 ? 'bg-gray-400/20 border border-gray-500' : 
                index === 2 ? 'bg-orange-600/20 border border-orange-700' : 'bg-gray-800/40 border border-gray-700/50'
              } hover:bg-purple-500/10`}
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{ duration: 0.4, delay: index * 0.1 }}
            >
              <span className={`text-xl font-bold w-8 text-center ${
                index === 0 ? 'text-yellow-400' : 
                index === 1 ? 'text-gray-300' : 
                index === 2 ? 'text-orange-400' : 'text-purple-300'
              }`}>{player.rank}</span>
              <Avatar className="w-10 h-10 mx-3 border-2 border-purple-400">
                <AvatarImage src={`https://avatar.vercel.sh/${player.avatarSeed}.png?size=40`} />
                <AvatarFallback className="bg-purple-500 text-white">{getInitials(player.name)}</AvatarFallback>
              </Avatar>
              <span className="flex-grow font-semibold text-white">{player.name}</span>
              <span className="text-yellow-400 font-bold flex items-center">
                <Coins size={16} className="mr-1"/> {player.earnings.toLocaleString()}
              </span>
            </motion.div>
          ))}
        </div>
      </section>
      
      
      <section>
        <h2 className="text-3xl font-bold text-center mb-10 text-green-300">Tutorials & FAQs</h2>
        <div className="max-w-3xl mx-auto glass-effect rounded-xl p-6 border border-green-500/20">
            <Accordion type="single" collapsible className="w-full">
                {faqData.map((faq, index) => (
                    <AccordionItem key={index} value={`item-${index}`} className="border-b-gray-700/50">
                        <AccordionTrigger className="text-lg text-white hover:text-green-300 hover:no-underline text-left">
                            <HelpCircle size={20} className="mr-3 text-green-400 flex-shrink-0"/>{faq.question}
                        </AccordionTrigger>
                        <AccordionContent className="text-gray-300 pt-2 pb-4 text-base">
                            {faq.answer}
                        </AccordionContent>
                    </AccordionItem>
                ))}
            </Accordion>
            <div className="mt-8 text-center">
                <Button variant="outline" className="border-green-500/60 hover:bg-green-500/10 text-green-300 hover:text-green-200" onClick={() => toast({title: "🚧 More Tutorials Coming Soon!"})}>
                    <BookOpen size={18} className="mr-2"/> View All Tutorials
                </Button>
            </div>
        </div>
      </section>
    </div>
  );
};

export default StudentEarningPage;