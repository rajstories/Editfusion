import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Star, Search, Filter, Briefcase, Languages, Clock, ShieldCheck, MessageSquare } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

// Placeholder data - replace with API call or localStorage
const allEditors = [
  { id: '1', name: 'Alice Wonderland', bio: 'VFX Wizard & Cinematic Storyteller. 5+ years experience.', skills: ['VFX', 'Storytelling', 'Color Grading'], rating: 4.9, deliveryTime: 'Fast', language: 'English', experience: 'Expert', works: 5, hourlyRate: 75, isFeatured: true, avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cG9ydHJhaXR8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=100&q=60' },
  { id: '2', name: 'Bob The Builder', bio: 'Quick turnarounds for social media content. Engaging edits.', skills: ['Social Media', 'Motion Graphics', 'Fast Editing'], rating: 4.7, deliveryTime: 'Standard', language: 'English, Spanish', experience: 'Intermediate', works: 12, hourlyRate: 50, isFeatured: false, avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8cG9ydHJhaXR8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=100&q=60' },
  { id: '3', name: 'Carol Danvers', bio: 'Specializing in documentary and corporate videos. Clean and professional.', skills: ['Documentary', 'Corporate', 'Audio Editing'], rating: 4.8, deliveryTime: 'Standard', language: 'English', experience: 'Expert', works: 8, hourlyRate: 65, isFeatured: false, avatar: 'https://images.unsplash.com/photo-1531123897727-8f129e1688ce?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fHBvcnRyYWl0fGVufDB8fHwwfHx8MA%3D%3D&auto=format&fit=crop&w=100&q=60' },
  { id: '4', name: 'David Copperfield', bio: 'Magic touch for wedding videos and event highlights.', skills: ['Wedding', 'Events', 'Color Correction'], rating: 4.6, deliveryTime: 'Flexible', language: 'English', experience: 'Intermediate', works: 20, hourlyRate: 40, isFeatured: true, avatar: 'https://images.unsplash.com/photo-1521119989659-a83eee488004?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8N3x8cG9ydHJhaXR8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=100&q=60' },
];

const skillTags = [...new Set(allEditors.flatMap(editor => editor.skills))];
const ratings = ["Any", "4.5+", "4.0+", "3.5+"];
const deliveryTimes = ["Any", "Fast", "Standard", "Flexible"];
const languages = ["Any", ...new Set(allEditors.flatMap(editor => editor.language.split(', ')))];
const experiences = ["Any", "Beginner", "Intermediate", "Expert"];


const EditorCard = ({ editor, openProUpgradeModal }) => {
  const handleMessageClick = () => {
    // Simulate free client restriction
    openProUpgradeModal();
    toast({
      title: '🔒 Messaging is a Pro feature.',
      description: 'Upgrade to Pro for instant access or wait for editor notification.',
      variant: 'default',
    });
  };

  return (
    <motion.div
      className="glass-effect rounded-2xl p-6 flex flex-col transition-all duration-300 hover:shadow-purple-500/30 hover:shadow-xl border border-purple-500/20 hover:border-purple-500/50"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      layout
    >
      <div className="flex items-start space-x-4 mb-4">
        <img-replace src={editor.avatar} alt={editor.name} class="w-20 h-20 rounded-full object-cover border-2 border-purple-500" />
        <div className="flex-1">
          <div className="flex justify-between items-start">
            <h3 className="text-2xl font-bold text-purple-300">{editor.name}</h3>
            {editor.isFeatured && (
              <span className="bg-yellow-500/20 text-yellow-400 text-xs px-2 py-0.5 rounded-full flex items-center">
                <Star size={12} className="mr-1" /> Featured
              </span>
            )}
          </div>
          <div className="flex items-center text-yellow-400 mt-1">
            {[...Array(Math.floor(editor.rating))].map((_, i) => <Star key={`full-${i}`} size={16} fill="currentColor" />)}
            {editor.rating % 1 !== 0 && <Star key="half" size={16} fill="currentColor" style={{ clipPath: 'polygon(0 0, 50% 0, 50% 100%, 0% 100%)' }} />}
            {[...Array(5 - Math.ceil(editor.rating))].map((_, i) => <Star key={`empty-${i}`} size={16} />)}
            <span className="ml-2 text-sm text-gray-400">({editor.rating.toFixed(1)} - {editor.works} works)</span>
          </div>
        </div>
      </div>
      <p className="text-gray-300 text-sm mb-3 h-12 overflow-hidden text-ellipsis">{editor.bio}</p>
      <div className="flex flex-wrap gap-2 mb-4">
        {editor.skills.slice(0, 3).map(skill => (
          <span key={skill} className="text-xs bg-gray-700/50 text-purple-300 px-2 py-1 rounded-full">{skill}</span>
        ))}
        {editor.skills.length > 3 && <span className="text-xs bg-gray-700/50 text-purple-300 px-2 py-1 rounded-full">+{editor.skills.length - 3} more</span>}
      </div>
      <div className="mt-auto space-y-3">
        <Button asChild variant="outline" className="w-full border-purple-500/60 hover:bg-purple-500/10 text-purple-300 hover:text-purple-200 magnetic-hover">
          <Link to={`/editor/${editor.id}`}>
            <Briefcase size={16} className="mr-2" /> View Portfolio
          </Link>
        </Button>
        <Button className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:opacity-90 text-white magnetic-hover glow-effect" onClick={handleMessageClick}>
          <MessageSquare size={16} className="mr-2" /> Message Editor
        </Button>
      </div>
    </motion.div>
  );
};


const FindEditorsPage = ({ openProUpgradeModal }) => {
  const [filters, setFilters] = useState({
    searchTerm: '',
    skill: 'Any',
    rating: 'Any',
    deliveryTime: 'Any',
    language: 'Any',
    experience: 'Any',
  });
  const [filteredEditors, setFilteredEditors] = useState(allEditors);
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    let editors = [...allEditors];
    if (filters.searchTerm) {
      editors = editors.filter(editor =>
        editor.name.toLowerCase().includes(filters.searchTerm.toLowerCase()) ||
        editor.skills.some(skill => skill.toLowerCase().includes(filters.searchTerm.toLowerCase()))
      );
    }
    if (filters.skill !== 'Any') {
      editors = editors.filter(editor => editor.skills.includes(filters.skill));
    }
    if (filters.rating !== 'Any') {
      const minRating = parseFloat(filters.rating.replace('+', ''));
      editors = editors.filter(editor => editor.rating >= minRating);
    }
    if (filters.deliveryTime !== 'Any') {
      editors = editors.filter(editor => editor.deliveryTime === filters.deliveryTime);
    }
    if (filters.language !== 'Any') {
      editors = editors.filter(editor => editor.language.includes(filters.language));
    }
    if (filters.experience !== 'Any') {
      editors = editors.filter(editor => editor.experience === filters.experience);
    }
    
    // Sort by featured, then by rating
    editors.sort((a, b) => {
      if (a.isFeatured && !b.isFeatured) return -1;
      if (!a.isFeatured && b.isFeatured) return 1;
      return b.rating - a.rating;
    });

    setFilteredEditors(editors);
  }, [filters]);

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const FilterSelect = ({ value, onValueChange, placeholder, items, icon: Icon }) => (
    <div className="flex-1 min-w-[150px]">
      <Select value={value} onValueChange={onValueChange}>
        <SelectTrigger className="w-full bg-black/30 border-purple-500/30 input-glow">
          <div className="flex items-center">
            {Icon && <Icon size={16} className="mr-2 text-purple-400" />}
            <SelectValue placeholder={placeholder} />
          </div>
        </SelectTrigger>
        <SelectContent className="glass-effect border-purple-500/50">
          {items.map(item => <SelectItem key={item} value={item} className="hover:bg-purple-500/20">{item}</SelectItem>)}
        </SelectContent>
      </Select>
    </div>
  );

  return (
    <div className="container mx-auto px-4 py-12 min-h-screen">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-center mb-12"
      >
        <h1 className="text-5xl font-black gradient-text mb-4">Find Your Perfect Editor</h1>
        <p className="text-xl text-gray-300 max-w-2xl mx-auto">
          Browse our curated list of top-tier video editors and VFX artists.
        </p>
      </motion.div>

      <div className="mb-8 p-6 glass-effect rounded-xl border border-purple-500/30">
        <div className="flex flex-col md:flex-row gap-4 items-center mb-4">
          <div className="relative flex-grow w-full md:w-auto">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
            <Input
              type="text"
              placeholder="Search by name or skill..."
              className="pl-10 w-full input-glow bg-black/30 border-purple-500/30"
              value={filters.searchTerm}
              onChange={(e) => handleFilterChange('searchTerm', e.target.value)}
            />
          </div>
          <Button onClick={() => setShowFilters(!showFilters)} variant="outline" className="w-full md:w-auto border-purple-500/60 hover:bg-purple-500/10 text-purple-300">
            <Filter size={16} className="mr-2" /> {showFilters ? 'Hide' : 'Show'} Filters
          </Button>
        </div>
        
        {showFilters && (
          <motion.div 
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 pt-4 border-t border-purple-500/20"
            initial={{ opacity:0, height: 0 }}
            animate={{ opacity:1, height: 'auto' }}
            exit={{ opacity:0, height: 0 }}
            transition={{ duration: 0.3 }}
          >
            <FilterSelect value={filters.skill} onValueChange={(val) => handleFilterChange('skill', val)} placeholder="Filter by Skill" items={skillTags} icon={Briefcase} />
            <FilterSelect value={filters.rating} onValueChange={(val) => handleFilterChange('rating', val)} placeholder="Min. Rating" items={ratings} icon={Star} />
            <FilterSelect value={filters.deliveryTime} onValueChange={(val) => handleFilterChange('deliveryTime', val)} placeholder="Delivery Time" items={deliveryTimes} icon={Clock} />
            <FilterSelect value={filters.language} onValueChange={(val) => handleFilterChange('language', val)} placeholder="Language" items={languages} icon={Languages} />
            <FilterSelect value={filters.experience} onValueChange={(val) => handleFilterChange('experience', val)} placeholder="Experience" items={experiences} icon={ShieldCheck} />
          </motion.div>
        )}
      </div>

      {filteredEditors.length > 0 ? (
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          layout
        >
          {filteredEditors.map(editor => (
            <EditorCard key={editor.id} editor={editor} openProUpgradeModal={openProUpgradeModal} />
          ))}
        </motion.div>
      ) : (
        <motion.p 
          className="text-center text-gray-400 text-lg py-10"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          No editors found matching your criteria. Try adjusting your filters!
        </motion.p>
      )}
    </div>
  );
};

export default FindEditorsPage;