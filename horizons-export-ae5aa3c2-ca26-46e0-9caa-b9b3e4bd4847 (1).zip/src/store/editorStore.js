
import { create } from 'zustand';

export const useEditorStore = create((set) => ({
  projectName: 'Untitled Project',
  assets: [],
  timeline: {
    video: [],
    audio: [],
    text: [],
  },
  selectedTool: null,
  selectedClip: null,
  textOverlays: [],

  setProjectName: (name) => set({ projectName: name }),
  
  addAsset: (asset) => set((state) => ({ assets: [...state.assets, asset] })),
  
  addTrack: (trackData) => set(state => {
    const newTimeline = { ...state.timeline };
    if(newTimeline[trackData.type]) {
        newTimeline[trackData.type] = [...newTimeline[trackData.type], ...trackData.clips];
    }
    return { timeline: newTimeline };
  }),

  addTextOverlay: (textData) => set(state => ({
    textOverlays: [...state.textOverlays, { ...textData, id: `text_${Date.now()}` }]
  })),
  
  updateTextOverlay: (id, newProps) => set(state => ({
    textOverlays: state.textOverlays.map(text => 
      text.id === id ? { ...text, ...newProps } : text
    )
  })),

  setSelectedTool: (tool) => set({ selectedTool: tool }),
  setSelectedClip: (clip) => set({ selectedClip: clip }),

  // More actions to manipulate timeline, clips, etc. will go here
}));
