
import { create } from 'zustand';

export const useAuthStore = create((set, get) => ({
  user: null,
  
  checkUser: () => {
    const storedUser = localStorage.getItem('editFusionUser');
    if (storedUser) {
      try {
        const parsedUser = JSON.parse(storedUser);
        set({ user: parsedUser });
      } catch (error) {
        console.error("Failed to parse user from localStorage", error);
        localStorage.removeItem('editFusionUser');
        set({ user: null });
      }
    }
  },

  login: (userData) => {
    const fullUserData = {
      ...userData,
      avatar: `https://avatar.vercel.sh/${userData.email}.png`,
      role: userData.role || 'creator',
      subscriptionTier: userData.subscriptionTier || null,
      isPremium: !!userData.subscriptionTier,
    };
    localStorage.setItem('editFusionUser', JSON.stringify(fullUserData));
    set({ user: fullUserData });
  },

  logout: () => {
    localStorage.removeItem('editFusionUser');
    set({ user: null });
  },

  updateProfile: (updates) => {
    const currentUser = get().user;
    if (currentUser) {
      const updatedUser = { ...currentUser, ...updates };
      localStorage.setItem('editFusionUser', JSON.stringify(updatedUser));
      set({ user: updatedUser });
    }
  },
}));
