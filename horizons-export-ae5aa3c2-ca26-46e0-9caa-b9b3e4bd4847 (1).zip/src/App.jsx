
import React, { useState, useEffect } from 'react';
import { Routes, Route, useLocation, Navigate, useNavigate } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { Toaster } from '@/components/ui/toaster';

import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import FloatingParticles from '@/components/effects/FloatingParticles';
import CustomCursor from '@/components/effects/CustomCursor';
import Chatbot from '@/components/layout/Chatbot';
import useScrollReveal from '@/hooks/useScrollReveal';

import HomePage from '@/pages/HomePage';
import RewardsPage from '@/pages/RewardsPage';
import ReferEarnPage from '@/pages/ReferEarnPage';
import DropshippingPage from '@/pages/DropshippingPage';
import FindEditorsPage from '@/pages/FindEditorsPage';
import EditorProfilePage from '@/pages/EditorProfilePage';
import UserProfilePage from '@/pages/UserProfilePage';
import NotificationsPage from '@/pages/NotificationsPage';
import TaskTrackerPage from '@/pages/TaskTrackerPage';
import TaskViewPage from '@/pages/TaskViewPage';
import StudentEarningPage from '@/pages/StudentEarningPage';
import InboxPage from '@/pages/InboxPage';
import OpenProjectsPage from '@/pages/OpenProjectsPage';
import VideoEditorPage from '@/pages/VideoEditorPage';
import LoginPage from '@/pages/LoginPage';
import SignupPage from '@/pages/SignupPage';

import ConnectModal from '@/components/modals/ConnectModal';
import CreateModal from '@/components/modals/CreateModal';
import CollaborateModal from '@/components/modals/CollaborateModal';
import CreatorApplyModal from '@/components/modals/CreatorApplyModal';
import EditorApplyModal from '@/components/modals/EditorApplyModal';
import ProUpgradeModal from '@/components/modals/ProUpgradeModal';
import WhyConnectModal from '@/components/modals/WhyConnectModal';
import WhyCreateModal from '@/components/modals/WhyCreateModal';
import WhyRewardModal from '@/components/modals/WhyRewardModal';
import WhyEarnModal from '@/components/modals/WhyEarnModal';
import { useAuthStore } from '@/store/authStore';

const pageVariants = {
  initial: { opacity: 0, y: 20 },
  in: { opacity: 1, y: 0 },
  out: { opacity: 0, y: -20 },
};

const pageTransition = {
  type: 'tween',
  ease: 'anticipate',
  duration: 0.5,
};

function App() {
  useScrollReveal();
  const location = useLocation();
  const { user, login, logout, checkUser } = useAuthStore();

  useEffect(() => {
    checkUser();
  }, [checkUser]);

  const [isConnectModalOpen, setIsConnectModalOpen] = useState(false);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isCollaborateModalOpen, setIsCollaborateModalOpen] = useState(false);
  const [isCreatorApplyModalOpen, setIsCreatorApplyModalOpen] = useState(false);
  const [isEditorApplyModalOpen, setIsEditorApplyModalOpen] = useState(false);
  const [isProUpgradeModalOpen, setIsProUpgradeModalOpen] = useState(false);
  const [isWhyConnectModalOpen, setIsWhyConnectModalOpen] = useState(false);
  const [isWhyCreateModalOpen, setIsWhyCreateModalOpen] = useState(false);
  const [isWhyRewardModalOpen, setIsWhyRewardModalOpen] = useState(false);
  const [isWhyEarnModalOpen, setIsWhyEarnModalOpen] = useState(false);

  const openProUpgradeModal = () => setIsProUpgradeModalOpen(true);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location.pathname]);

  const whyModalSetters = {
    connect: setIsWhyConnectModalOpen,
    create: setIsWhyCreateModalOpen,
    reward: setIsWhyRewardModalOpen,
    earn: setIsWhyEarnModalOpen,
  };

  const ProtectedRoute = ({ children }) => {
    const navigate = useNavigate();
    useEffect(() => {
      if (!user) {
        navigate('/login', { replace: true });
      }
    }, [user, navigate]);
  
    return user ? children : null;
  };

  return (
    <div className="min-h-screen bg-black text-white relative">
      <CustomCursor />
      <FloatingParticles />
      <Header user={user} onLogout={logout} />
      
      <AnimatePresence mode="wait">
        <motion.main
          key={location.pathname}
          initial="initial"
          animate="in"
          exit="out"
          variants={pageVariants}
          transition={pageTransition}
          className="pt-20 md:pt-16"
        >
          <Routes location={location}>
            <Route path="/" element={<HomePage 
              onOpenConnectModal={() => setIsConnectModalOpen(true)}
              onOpenCreateModal={() => setIsCreateModalOpen(true)}
              onOpenCollaborateModal={() => setIsCollaborateModalOpen(true)}
              onOpenCreatorApplyModal={() => setIsCreatorApplyModalOpen(true)}
              onOpenEditorApplyModal={() => setIsEditorApplyModalOpen(true)}
              whyModalSetters={whyModalSetters}
            />} />
            <Route path="/login" element={<LoginPage onLoginSuccess={login} />} />
            <Route path="/signup" element={<SignupPage onSignupSuccess={login} />} />
            <Route path="/rewards" element={<RewardsPage />} />
            <Route path="/refer-earn" element={<ReferEarnPage user={user} />} />
            <Route path="/dropshipping" element={<DropshippingPage />} />
            <Route path="/find-editors" element={<FindEditorsPage openProUpgradeModal={openProUpgradeModal} />} />
            <Route path="/editor/:editorId" element={<EditorProfilePage openProUpgradeModal={openProUpgradeModal} user={user} />} />
            <Route path="/student-earn" element={<StudentEarningPage />} />
            <Route path="/open-projects" element={<OpenProjectsPage />} />
            
            <Route path="/profile" element={<ProtectedRoute><UserProfilePage /></ProtectedRoute>} />
            <Route path="/notifications" element={<ProtectedRoute><NotificationsPage /></ProtectedRoute>} />
            <Route path="/tasks" element={<ProtectedRoute><TaskTrackerPage user={user} /></ProtectedRoute>} />
            <Route path="/task/:taskId" element={<TaskViewPage />} />
            <Route path="/inbox" element={<ProtectedRoute><InboxPage user={user} openProUpgradeModal={openProUpgradeModal}/></ProtectedRoute>} />
            <Route path="/inbox/:chatId" element={<ProtectedRoute><InboxPage user={user} openProUpgradeModal={openProUpgradeModal}/></ProtectedRoute>} />
            <Route path="/editor" element={<ProtectedRoute><VideoEditorPage /></ProtectedRoute>} />
            <Route path="/editor/:projectId" element={<ProtectedRoute><VideoEditorPage /></ProtectedRoute>} />

          </Routes>
        </motion.main>
      </AnimatePresence>
      
      <Footer />
      <Toaster />
      <Chatbot />
      
      <ConnectModal 
        isOpen={isConnectModalOpen} 
        setIsOpen={setIsConnectModalOpen}
        onOpenCreatorApplyModal={() => { setIsConnectModalOpen(false); setTimeout(() => setIsCreatorApplyModalOpen(true), 200); }}
        onOpenEditorApplyModal={() => { setIsConnectModalOpen(false); setTimeout(() => setIsEditorApplyModalOpen(true), 200); }}
      />
      <CreateModal isOpen={isCreateModalOpen} setIsOpen={setIsCreateModalOpen} />
      <CollaborateModal isOpen={isCollaborateModalOpen} setIsOpen={setIsCollaborateModalOpen} />
      <CreatorApplyModal isOpen={isCreatorApplyModalOpen} setIsOpen={setIsCreatorApplyModalOpen} />
      <EditorApplyModal isOpen={isEditorApplyModalOpen} setIsOpen={setIsEditorApplyModalOpen} />
      <ProUpgradeModal isOpen={isProUpgradeModalOpen} setIsOpen={setIsProUpgradeModalOpen} />

      <WhyConnectModal isOpen={isWhyConnectModalOpen} setIsOpen={setIsWhyConnectModalOpen} />
      <WhyCreateModal isOpen={isWhyCreateModalOpen} setIsOpen={setIsWhyCreateModalOpen} />
      <WhyRewardModal isOpen={isWhyRewardModalOpen} setIsOpen={setIsWhyRewardModalOpen} />
      <WhyEarnModal isOpen={isWhyEarnModalOpen} setIsOpen={setIsWhyEarnModalOpen} />
    </div>
  );
}

export default App;
